# Smart Parking API Reference

All endpoints return JSON unless the route explicitly returns a CSV export. Authenticated endpoints require a valid session cookie. Mutating requests require the `x-csrf-token` header received from login or `/api/auth/me`.

## Authentication

| Method | Route | Purpose |
|---|---|---|
| POST | `/api/auth/register` | Create a citizen account |
| POST | `/api/auth/login` | Start an authenticated session |
| POST | `/api/auth/logout` | Revoke the current session |
| GET | `/api/auth/me` | Return the current user and CSRF token |

Police and administrator accounts are not created through public registration.

## Parking inventory

| Method | Route | Purpose |
|---|---|---|
| GET | `/api/slots` | List bays |
| POST | `/api/slots/:id/status` | Update a bay state |
| GET | `/api/v2/parking/zones` | Summarize inventory by zone |
| GET | `/api/v2/parking/recommendations` | Rank bays using preferences |
| GET | `/api/v2/analytics/stale-slots` | Flag stale bay records |

Supported states are `available`, `occupied`, `reserved`, and `maintenance`.

## Reservations

| Method | Route | Purpose |
|---|---|---|
| POST | `/api/reservations` | Create a reservation |
| GET | `/api/reservations` | List permitted reservations |
| POST | `/api/reservations/:id/cancel` | Cancel a reservation |

Reservation creation checks time ordering, the maximum reservation window, bay availability and overlapping active reservations.

## Reports and violations

| Method | Route | Purpose |
|---|---|---|
| POST | `/api/reports` | Submit a citizen report |
| GET | `/api/reports` | List permitted reports |
| PATCH | `/api/reports/:id` | Update report status |
| POST | `/api/violations` | Submit a parking violation report |
| GET | `/api/violations` | Police/admin violation queue |
| PATCH | `/api/violations/:id` | Update violation status |
| GET | `/api/v2/police/violations/priority` | Suggest queue priority |

Priority is only a triage suggestion. It must not trigger automatic penalties.

## Analytics and decision support

| Method | Route | Purpose |
|---|---|---|
| GET | `/api/dashboard` | Operations counters |
| GET | `/api/summary` | Basic inventory summary |
| GET | `/api/v2/analytics/overview` | Expanded dashboard analytics |
| GET | `/api/v2/analytics/zone-utilization` | Zone utilization |
| POST | `/api/v2/ai/classify-report` | Suggest a report category |
| POST | `/api/v2/ai/rank-parking` | Rank available bays |
| GET | `/api/ai/tools` | List local decision-support tools |
| POST | `/api/ai/:tool` | Run a named decision-support tool |

The current algorithms are transparent rules and heuristics, not trained machine-learning models. Accuracy depends on correct, current inventory data.

## Notifications and preferences

| Method | Route | Purpose |
|---|---|---|
| GET | `/api/v2/notifications` | List current user's notifications |
| POST | `/api/v2/notifications/:id/read` | Mark one notification read |
| POST | `/api/v2/notifications/read-all` | Mark all notifications read |
| DELETE | `/api/v2/notifications/:id` | Delete one notification |
| GET | `/api/v2/me/preferences` | Read account display preferences |
| PUT | `/api/v2/me/preferences` | Update account display preferences |
| GET | `/api/v2/me/summary` | Read the current user's summary |

## Export and operations

| Method | Route | Purpose |
|---|---|---|
| GET | `/api/v2/export/slots.csv` | Export parking inventory |
| GET | `/api/v2/export/reservations.csv` | Export reservations |
| GET | `/api/v2/export/reports.csv` | Export reports |
| POST | `/api/v2/sensors/parking/:id` | Accept a demo sensor update |
| GET | `/api/v2/health` | Health and database status |
| GET | `/api/audit` | Administrator audit history |

CSV values beginning with formula characters are escaped to reduce spreadsheet formula injection risk.

## Error shape

Validation errors typically return status `400`; unauthenticated requests return `401`; unauthorized roles return `403`; conflicting reservations return `409`; missing records return `404`; rate limits return `429`. A typical error body is:

```json
{
  "error": "A short explanation suitable for the client."
}
```

## Data protection notes

The server can read report descriptions and reservation records. The application is not end-to-end encrypted. Use TLS in deployment, secure secret management, least-privilege database access, documented retention rules, access reviews and a third-party security review before any real police or public deployment.
