# Security and Privacy Model

## Included controls

- Password hashing with bcrypt.
- Opaque session cookies with HttpOnly and SameSite settings.
- CSRF tokens for state-changing authenticated requests.
- Role checks for police and administrator endpoints.
- Input validation and bounded JSON request bodies.
- Rate limiting and security response headers.
- Parameterized SQL queries.
- Audit records for selected operations.
- CSV formula-character escaping.
- Explicit user-facing warnings that decision-support tools require human review.

## Security boundaries

The browser receives the user's permitted data. The backend owns authorization decisions and must not trust role claims supplied by the browser. The database should only be reachable by the backend process. Police and administrator accounts should be provisioned out of band and protected with multifactor authentication in a real deployment.

## End-to-end encryption limitation

This version is not end-to-end encrypted. HTTPS encrypts transport between client and server; it does not prevent the server from reading data. Password hashing protects password verification storage but does not encrypt reports or reservations. A server-side AI feature cannot inspect truly end-to-end encrypted text unless a user decrypts it on their device or a separate privacy-preserving design is implemented.

## Production checklist

- Deploy behind HTTPS and set secure cookies.
- Set a random `SESSION_SECRET` using a secrets manager.
- Disable demo seeding and remove all demo accounts.
- Replace local SQLite with a managed database if multiple instances are required.
- Add MFA for police and administrators.
- Add monitoring, alerting, tested backups and restore procedures.
- Define report retention and deletion rules.
- Add account recovery with abuse-resistant workflows.
- Add dependency scanning and patch cadence.
- Perform authorization, CSRF, XSS, injection and session tests.
- Conduct an independent penetration test.
- Do not use AI suggestions as the sole basis for a fine or enforcement action.
- Add verified sensor identity, message signing and replay protection before connecting physical hardware.
