"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const rules = require("../src/domain/parkingRules");
const privacy = require("../src/domain/privacy");
const analytics = require("../src/domain/analytics");
const validation = require("../src/domain/validation");
const pagination = require("../src/services/pagination");
const search = require("../src/services/searchService");
const exporter = require("../src/services/exportService");

const fixture = [
  { id: 1, label: "P-001", zone: "White Town", status: "available", accessible: 1, ev_charging: 0, hourly_rate: 25, updated_at: new Date().toISOString() },
  { id: 2, label: "P-002", zone: "Beach Road", status: "occupied", accessible: 0, ev_charging: 1, hourly_rate: 35, updated_at: new Date().toISOString() },
  { id: 3, label: "P-003", zone: "White Town", status: "maintenance", accessible: 1, ev_charging: 1, hourly_rate: 20, updated_at: new Date(Date.now() - 72 * 3600000).toISOString() }
];

test("slot status validation accepts only declared statuses", () => {
  assert.equal(rules.isValidStatus("available"), true);
  assert.equal(rules.isValidStatus("occupied"), true);
  assert.equal(rules.isValidStatus("deleted"), false);
  assert.equal(rules.isValidStatus(""), false);
});

test("reservation windows reject invalid and reversed times", () => {
  assert.equal(rules.validateReservationWindow("invalid", "invalid").valid, false);
  assert.equal(rules.validateReservationWindow("2030-01-01T10:00:00Z", "2030-01-01T09:00:00Z").valid, false);
});

test("reservation windows accept a valid future window", () => {
  const result = rules.validateReservationWindow("2035-01-01T10:00:00Z", "2035-01-01T11:00:00Z");
  assert.equal(result.valid, true);
  assert.ok(result.startsAt);
});

test("reservation conflicts detect overlapping time ranges", () => {
  const existing = [{ status: "active", starts_at: "2035-01-01T10:00:00Z", ends_at: "2035-01-01T11:00:00Z" }];
  assert.equal(rules.hasReservationConflict(existing, { startsAt: "2035-01-01T10:30:00Z", endsAt: "2035-01-01T11:30:00Z" }), true);
  assert.equal(rules.hasReservationConflict(existing, { startsAt: "2035-01-01T11:00:00Z", endsAt: "2035-01-01T12:00:00Z" }), false);
});

test("preference filter excludes occupied bays", () => {
  assert.equal(rules.isAvailableForPreferences(fixture[0], {}), true);
  assert.equal(rules.isAvailableForPreferences(fixture[1], {}), false);
});

test("accessible preference requires an accessible bay", () => {
  assert.equal(rules.isAvailableForPreferences(fixture[0], { accessible: true }), true);
  assert.equal(rules.isAvailableForPreferences({ ...fixture[0], accessible: 0 }, { accessible: true }), false);
});

test("slot summary counts inventory by state and zone", () => {
  const summary = rules.summarizeSlots(fixture);
  assert.equal(summary.total, 3);
  assert.equal(summary.available, 1);
  assert.equal(summary.occupied, 1);
  assert.equal(summary.maintenance, 1);
  assert.equal(summary.zones["White Town"].total, 2);
});

test("priority detection elevates accessibility and emergency wording", () => {
  assert.equal(rules.reportPriority("other", "Emergency driveway blocked"), "high");
  assert.equal(rules.reportPriority("other", "Car is not straight"), "normal");
});

test("status transitions require police or admin role", () => {
  assert.equal(rules.canTransitionStatus("available", "occupied", "police"), true);
  assert.equal(rules.canTransitionStatus("available", "occupied", "citizen"), false);
  assert.equal(rules.canTransitionStatus("maintenance", "occupied", "admin"), false);
});

test("token hashing is deterministic", () => {
  assert.equal(privacy.sha256("sample"), privacy.sha256("sample"));
  assert.notEqual(privacy.sha256("sample"), privacy.sha256("different"));
});

test("opaque token generator returns distinct values", () => {
  assert.notEqual(privacy.makeOpaqueToken(), privacy.makeOpaqueToken());
});

test("constant-time comparator handles equality and inequality", () => {
  assert.equal(privacy.constantTimeEqual("token", "token"), true);
  assert.equal(privacy.constantTimeEqual("token", "other"), false);
  assert.equal(privacy.constantTimeEqual("short", "longer"), false);
});

test("email redaction hides most local characters", () => {
  assert.equal(privacy.redactEmail("alice@example.com"), "a****@example.com");
  assert.equal(privacy.redactEmail("invalid"), "[redacted]");
});

test("registration validation rejects short passwords", () => {
  const result = validation.validateRegistration({ name: "Alice", email: "alice@example.com", password: "Short1" });
  assert.equal(result.valid, false);
  assert.ok(result.errors.length > 0);
});

test("registration validation accepts a strong password", () => {
  const result = validation.validateRegistration({ name: "Alice Doe", email: "alice@example.com", password: "SecurePass2026!" });
  assert.equal(result.valid, true);
});

test("pagination clamps limits", () => {
  assert.deepEqual(pagination.normalizePagination({ page: "-3", limit: "9999" }), { page: 1, limit: 100, offset: 0 });
});

test("array pagination returns navigation metadata", () => {
  const result = pagination.paginateArray([1, 2, 3, 4, 5], { page: 2, limit: 2 });
  assert.deepEqual(result.items, [3, 4]);
  assert.equal(result.hasPreviousPage, true);
  assert.equal(result.hasNextPage, true);
});

test("search filtering supports zone, status and accessibility", () => {
  const results = search.filterSlots(fixture, { zone: "White Town", status: "available" });
  assert.equal(results.length, 1);
  assert.equal(results[0].id, 1);
});

test("search sorting supports hourly rate", () => {
  const results = search.sortSlots(fixture, "rate_asc");
  assert.equal(results[0].hourly_rate, 20);
});

test("CSV formula injection is neutralized", () => {
  const csv = exporter.toCsv([{ value: "=HYPERLINK(1)" }], [{ key: "value", label: "Value" }]);
  assert.ok(csv.includes("'=HYPERLINK(1)"));
});

test("report classification returns a bounded suggestion", () => {
  const result = analytics.classifyReport("The driveway is blocked by a parked car");
  assert.equal(result.category, "blocked_access");
  assert.ok(["low", "medium"].includes(result.confidence));
});

test("utilization calculation returns a percentage", () => {
  assert.equal(analytics.utilizationRate(fixture), 33.3);
});

test("zone utilization includes every zone", () => {
  const zones = analytics.zoneUtilization(fixture);
  assert.equal(zones.length, 2);
  assert.ok(zones.every(zone => zone.utilizationPercent >= 0 && zone.utilizationPercent <= 100));
});

test("availability band responds to low supply", () => {
  const result = analytics.availabilityBands([{ status: "occupied" }, { status: "occupied" }, { status: "available" }]);
  assert.equal(result.level, "moderate");
});

test("stale slot detection returns old and missing timestamps", () => {
  const stale = analytics.staleSlots(fixture, 24);
  assert.equal(stale.length, 1);
  assert.equal(stale[0].label, "P-003");
});

test("CSV export escapes quotes and commas", () => {
  const csv = exporter.toCsv([{ value: 'North, "West"' }], [{ key: "value", label: "Zone" }]);
  assert.ok(csv.includes('"North, ""West"""'));
});
