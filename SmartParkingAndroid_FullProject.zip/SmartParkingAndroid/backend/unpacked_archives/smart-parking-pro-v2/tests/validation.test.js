"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const validation = require("../src/domain/validation");
const rules = require("../src/domain/parkingRules");

test("coordinates accept valid geographic values", () => {
  assert.equal(validation.validateCoordinates(11.93, 79.83).valid, true);
});

test("coordinates reject out-of-range latitude", () => {
  assert.equal(validation.validateCoordinates(100, 79.83).valid, false);
});

test("coordinates reject out-of-range longitude", () => {
  assert.equal(validation.validateCoordinates(11.93, 190).valid, false);
});

test("money validation rounds to cents", () => {
  assert.equal(validation.validateMoney(12.345).value, 12.35);
});

test("money validation rejects negative values", () => {
  assert.equal(validation.validateMoney(-1).valid, false);
});

test("description validation strips null characters", () => {
  const result = validation.validateDescription("Blocked\u0000 bay", 4, 100);
  assert.equal(result.valid, true);
  assert.equal(result.value.includes("\u0000"), false);
});

test("identifier validation accepts positive integers", () => {
  assert.equal(validation.validateIdentifier("12").value, 12);
});

test("identifier validation rejects fractional identifiers", () => {
  assert.equal(validation.validateIdentifier("1.2").valid, false);
});

test("search validation normalizes whitespace", () => {
  assert.equal(validation.validateSearch(" White   Town ").value, "White Town");
});

test("report categories are strict", () => {
  assert.equal(rules.isValidReportCategory("blocked_access"), true);
  assert.equal(rules.isValidReportCategory("fine_waived"), false);
});

test("violation categories are strict", () => {
  assert.equal(rules.isValidViolationCategory("double_parking"), true);
  assert.equal(rules.isValidViolationCategory("unknown"), false);
});

test("description normalization bounds size", () => {
  assert.equal(rules.normalizeDescription("x".repeat(2000)).length, 1500);
});

test("zone normalization collapses whitespace", () => {
  assert.equal(rules.normalizeZone("  White    Town "), "White Town");
});
