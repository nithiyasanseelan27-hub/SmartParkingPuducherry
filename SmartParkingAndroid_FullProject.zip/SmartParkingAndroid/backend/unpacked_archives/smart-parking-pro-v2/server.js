require("dotenv").config();
const express = require("express");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const cookieParser = require("cookie-parser");
const bcrypt = require("bcryptjs");
const Database = require("better-sqlite3");
const { randomBytes, createHash, timingSafeEqual } = require("crypto");
const path = require("path");
const fs = require("fs");
const { z } = require("zod");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const SESSION_SECRET = process.env.SESSION_SECRET || "";
if (SESSION_SECRET.length < 32 && process.env.NODE_ENV === "production") {
  throw new Error("SESSION_SECRET must be at least 32 characters in production.");
}
const dbFile = path.resolve(process.env.DB_FILE || "./data/parking.sqlite");
fs.mkdirSync(path.dirname(dbFile), { recursive: true });
const db = new Database(dbFile);
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");
db.exec(`
CREATE TABLE IF NOT EXISTS users(
 id INTEGER PRIMARY KEY, name TEXT NOT NULL, email TEXT UNIQUE NOT NULL,
 password_hash TEXT NOT NULL, role TEXT NOT NULL CHECK(role IN ('citizen','police','admin')),
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, disabled INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS sessions(
 token_hash TEXT PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 csrf TEXT NOT NULL, expires_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS parking_slots(
 id INTEGER PRIMARY KEY, label TEXT NOT NULL, zone TEXT NOT NULL, latitude REAL, longitude REAL,
 accessible INTEGER NOT NULL DEFAULT 0, ev_charging INTEGER NOT NULL DEFAULT 0,
 hourly_rate REAL NOT NULL DEFAULT 20, status TEXT NOT NULL DEFAULT 'available'
 CHECK(status IN ('available','occupied','reserved','maintenance')),
 updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS reservations(
 id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id), slot_id INTEGER NOT NULL REFERENCES parking_slots(id),
 starts_at TEXT NOT NULL, ends_at TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'active'
 CHECK(status IN ('active','cancelled','completed')), created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS reports(
 id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id), slot_id INTEGER REFERENCES parking_slots(id),
 category TEXT NOT NULL, description TEXT NOT NULL, encrypted_details TEXT, status TEXT NOT NULL DEFAULT 'submitted'
 CHECK(status IN ('submitted','reviewing','resolved','rejected')),
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS violations(
 id INTEGER PRIMARY KEY, reporter_id INTEGER REFERENCES users(id), slot_id INTEGER REFERENCES parking_slots(id),
 category TEXT NOT NULL, description TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'open'
 CHECK(status IN ('open','reviewing','resolved','dismissed')), created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS audit_log(
 id INTEGER PRIMARY KEY, actor_id INTEGER REFERENCES users(id), action TEXT NOT NULL,
 entity_type TEXT NOT NULL, entity_id INTEGER, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_slots_zone_status ON parking_slots(zone,status);
CREATE INDEX IF NOT EXISTS idx_reservations_user ON reservations(user_id,status);
CREATE INDEX IF NOT EXISTS idx_reports_status ON reports(status);
`);
const q = {
 userByEmail: db.prepare("SELECT * FROM users WHERE email=?"),
 userById: db.prepare("SELECT id,name,email,role,created_at FROM users WHERE id=?"),
 addUser: db.prepare("INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,?)"),
 addSession: db.prepare("INSERT INTO sessions(token_hash,user_id,csrf,expires_at) VALUES(?,?,?,?)"),
 getSession: db.prepare("SELECT s.*,u.id,u.name,u.email,u.role,u.disabled FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=?"),
 delSession: db.prepare("DELETE FROM sessions WHERE token_hash=?"),
 audit: db.prepare("INSERT INTO audit_log(actor_id,action,entity_type,entity_id) VALUES(?,?,?,?)")
};
function hashToken(v) { return createHash("sha256").update(v).digest("hex"); }
function audit(user, action, type, id=null) { q.audit.run(user?.id || null, action, type, id); }
function cleanUser(u) { return {id:u.id,name:u.name,email:u.email,role:u.role}; }
function auth(req,res,next) {
  const raw = req.cookies?.sp_session;
  if (!raw) return res.status(401).json({error:"Please sign in."});
  const s = q.getSession.get(hashToken(raw));
  if (!s || s.expires_at < Date.now() || s.disabled) {
    if (s) q.delSession.run(s.token_hash);
    res.clearCookie("sp_session"); return res.status(401).json({error:"Session expired. Sign in again."});
  }
  req.user = {id:s.id,name:s.name,email:s.email,role:s.role};
  req.csrf = s.csrf;
  next();
}
function role(...roles) { return (req,res,next) => roles.includes(req.user.role) ? next() : res.status(403).json({error:"Not permitted for this role."}); }
function csrf(req,res,next) {
  if (["GET","HEAD","OPTIONS"].includes(req.method)) return next();
  const got = req.get("x-csrf-token") || "";
  const a=Buffer.from(got), b=Buffer.from(req.csrf || "");
  if (a.length !== b.length || !timingSafeEqual(a,b)) return res.status(403).json({error:"CSRF validation failed."});
  next();
}
app.disable("x-powered-by");
app.use(helmet({contentSecurityPolicy:{directives:{
  defaultSrc:["'self'"], scriptSrc:["'self'"], styleSrc:["'self'"], imgSrc:["'self'","data:"],
  connectSrc:["'self'"], objectSrc:["'none'"], baseUri:["'self'"], frameAncestors:["'none'"]
}}}));
app.use(express.json({limit:"32kb"}));
app.use(cookieParser());
app.use("/api", rateLimit({windowMs:15*60*1000, limit:250, standardHeaders:true, legacyHeaders:false}));
app.use(express.static(path.join(__dirname,"public")));
app.get("/api/health",(req,res)=>res.json({ok:true,service:"Smart Parking API",time:new Date().toISOString()}));

if (process.env.SEED_DEMO === "true") {
  const seed = db.transaction(() => {
    for (const [name,email,password,roleName] of [
      ["Citizen Demo","citizen@example.com","CitizenDemo!2026","citizen"],
      ["Police Demo","police@example.com","PoliceDemo!2026","police"],
      ["Admin Demo","admin@example.com","AdminDemo!2026","admin"]
    ]) if (!q.userByEmail.get(email)) q.addUser.run(name,email,bcrypt.hashSync(password,12),roleName);
    if (db.prepare("SELECT COUNT(*) n FROM parking_slots").get().n===0) {
      const ins=db.prepare("INSERT INTO parking_slots(label,zone,latitude,longitude,accessible,ev_charging,hourly_rate,status) VALUES(?,?,?,?,?,?,?,?)");
      [
        ["P-001","White Town",11.935,79.835,0,1,30,"available"],
        ["P-002","White Town",11.936,79.836,1,0,25,"occupied"],
        ["P-003","Beach Road",11.932,79.834,0,1,35,"available"],
        ["P-004","Heritage Town",11.941,79.831,1,0,20,"available"],
        ["P-005","Bus Stand",11.934,79.812,0,0,15,"maintenance"],
        ["P-006","White Town",11.937,79.834,0,0,30,"available"],
        ["P-007","Beach Road",11.931,79.835,0,0,35,"reserved"],
        ["P-008","Heritage Town",11.940,79.830,0,1,25,"available"]
      ].forEach(x=>ins.run(...x));
    }
  }); seed();
}
const registerSchema = z.object({name:z.string().trim().min(2).max(80),email:z.string().trim().email().max(160),password:z.string().min(10).max(128)});
app.post("/api/auth/register", async (req,res)=>{
  const parsed=registerSchema.safeParse(req.body); if(!parsed.success) return res.status(400).json({error:"Enter a name, valid email, and password with at least 10 characters."});
  const {name,email,password}=parsed.data;
  if(q.userByEmail.get(email.toLowerCase())) return res.status(409).json({error:"An account with this email already exists."});
  try { q.addUser.run(name,email.toLowerCase(),await bcrypt.hash(password,12),"citizen"); }
  catch { return res.status(409).json({error:"Could not create account."}); }
  res.status(201).json({message:"Account created. Sign in to continue."});
});
app.post("/api/auth/login", async (req,res)=>{
  const email=String(req.body?.email||"").trim().toLowerCase(), password=String(req.body?.password||"");
  const u=q.userByEmail.get(email);
  if(!u || u.disabled || !(await bcrypt.compare(password,u.password_hash))) return res.status(401).json({error:"Invalid email or password."});
  const raw=randomBytes(32).toString("base64url"), csrfToken=randomBytes(24).toString("base64url");
  q.addSession.run(hashToken(raw),u.id,csrfToken,Date.now()+8*60*60*1000);
  res.cookie("sp_session",raw,{httpOnly:true,secure:process.env.COOKIE_SECURE==="true",sameSite:"strict",maxAge:8*60*60*1000,path:"/"});
  audit({id:u.id},"login","session");
  res.json({user:cleanUser(u),csrf:csrfToken});
});
app.post("/api/auth/logout",auth,csrf,(req,res)=>{q.delSession.run(hashToken(req.cookies.sp_session));res.clearCookie("sp_session");audit(req.user,"logout","session");res.json({ok:true});});
app.get("/api/auth/me",auth,(req,res)=>res.json({user:req.user,csrf:req.csrf}));

app.get("/api/dashboard",auth,role("police","admin"),(req,res)=>{
  const counts={
    totalSlots:db.prepare("SELECT COUNT(*) n FROM parking_slots").get().n,
    available:db.prepare("SELECT COUNT(*) n FROM parking_slots WHERE status='available'").get().n,
    occupied:db.prepare("SELECT COUNT(*) n FROM parking_slots WHERE status='occupied'").get().n,
    activeReservations:db.prepare("SELECT COUNT(*) n FROM reservations WHERE status='active'").get().n,
    openViolations:db.prepare("SELECT COUNT(*) n FROM violations WHERE status IN ('open','reviewing')").get().n,
    openReports:db.prepare("SELECT COUNT(*) n FROM reports WHERE status IN ('submitted','reviewing')").get().n
  };
  res.json({counts, zones:db.prepare("SELECT zone,COUNT(*) total,SUM(status='available') available,SUM(status='occupied') occupied FROM parking_slots GROUP BY zone ORDER BY zone").all()});
});
app.get("/api/slots",auth,(req,res)=>{
  const zone=String(req.query.zone||"").slice(0,80), status=String(req.query.status||"");
  const allowed=["available","occupied","reserved","maintenance"];
  let sql="SELECT * FROM parking_slots WHERE 1=1", args=[];
  if(zone){sql+=" AND zone=?";args.push(zone)}
  if(allowed.includes(status)){sql+=" AND status=?";args.push(status)}
  sql+=" ORDER BY zone,label";
  res.json({slots:db.prepare(sql).all(...args)});
});
app.post("/api/slots/:id/status",auth,csrf,role("police","admin"),(req,res)=>{
  const status=req.body?.status, id=Number(req.params.id);
  if(!["available","occupied","reserved","maintenance"].includes(status)) return res.status(400).json({error:"Invalid status."});
  const r=db.prepare("UPDATE parking_slots SET status=?,updated_at=CURRENT_TIMESTAMP WHERE id=?").run(status,id);
  if(!r.changes)return res.status(404).json({error:"Slot not found."});
  audit(req.user,"slot_status_changed","parking_slot",id);res.json({ok:true});
});
app.post("/api/reservations",auth,csrf,role("citizen"),(req,res)=>{
  const id=Number(req.body?.slotId), starts=Date.parse(req.body?.startsAt), ends=Date.parse(req.body?.endsAt);
  if(!id||!Number.isFinite(starts)||!Number.isFinite(ends)||starts<Date.now()-60000||ends<=starts||ends-starts>24*60*60*1000) return res.status(400).json({error:"Choose a valid future time window up to 24 hours."});
  const startsISO=new Date(starts).toISOString(), endsISO=new Date(ends).toISOString();
  // Keep availability check and insert in one SQLite transaction to reduce double-booking races.
  let result;
  try {
    result=db.transaction(()=>{
      const slot=db.prepare("SELECT * FROM parking_slots WHERE id=?").get(id);
      if(!slot||slot.status!=="available") return {error:"This slot is not available."};
      const conflict=db.prepare("SELECT id FROM reservations WHERE slot_id=? AND status='active' AND NOT(ends_at<=? OR starts_at>=?)").get(id,startsISO,endsISO);
      if(conflict) return {error:"This slot is already reserved for that time."};
      const r=db.prepare("INSERT INTO reservations(user_id,slot_id,starts_at,ends_at) VALUES(?,?,?,?)").run(req.user.id,id,startsISO,endsISO);
      return {id:Number(r.lastInsertRowid)};
    })();
  } catch (e) { return res.status(500).json({error:"Reservation could not be saved. Please retry."}); }
  if(result.error) return res.status(409).json({error:result.error});
  audit(req.user,"reservation_created","reservation",result.id);
  res.status(201).json({id:result.id,message:"Reservation created."});
});
app.get("/api/reservations",auth,(req,res)=>{
 const sql=req.user.role==="citizen"?"SELECT r.*,s.label,s.zone FROM reservations r JOIN parking_slots s ON s.id=r.slot_id WHERE r.user_id=? ORDER BY r.created_at DESC":"SELECT r.*,s.label,s.zone,u.name citizen_name FROM reservations r JOIN parking_slots s ON s.id=r.slot_id JOIN users u ON u.id=r.user_id ORDER BY r.created_at DESC LIMIT 300";
 res.json({reservations:req.user.role==="citizen"?db.prepare(sql).all(req.user.id):db.prepare(sql).all()});
});
app.post("/api/reservations/:id/cancel",auth,csrf,(req,res)=>{
 const r=db.prepare("SELECT * FROM reservations WHERE id=?").get(Number(req.params.id));
 if(!r)return res.status(404).json({error:"Reservation not found."});
 if(req.user.role==="citizen"&&r.user_id!==req.user.id)return res.status(403).json({error:"Not permitted."});
 if(!["citizen","police","admin"].includes(req.user.role))return res.status(403).json({error:"Not permitted."});
 db.prepare("UPDATE reservations SET status='cancelled' WHERE id=? AND status='active'").run(r.id);
 audit(req.user,"reservation_cancelled","reservation",r.id);res.json({ok:true});
});
app.post("/api/reports",auth,csrf,role("citizen"),(req,res)=>{
 const category=String(req.body?.category||"").slice(0,60), description=String(req.body?.description||"").trim();
 const slotId=req.body?.slotId?Number(req.body.slotId):null;
 if(!["blocked_access","wrong_occupancy","damaged_sign","unsafe_parking","other"].includes(category)||description.length<8||description.length>1500)return res.status(400).json({error:"Choose a category and enter 8–1500 characters."});
 if(slotId&&!db.prepare("SELECT id FROM parking_slots WHERE id=?").get(slotId))return res.status(400).json({error:"Invalid slot."});
 const r=db.prepare("INSERT INTO reports(user_id,slot_id,category,description) VALUES(?,?,?,?)").run(req.user.id,slotId,category,description);
 audit(req.user,"report_submitted","report",r.lastInsertRowid);res.status(201).json({id:r.lastInsertRowid,message:"Report submitted."});
});
app.get("/api/reports",auth,(req,res)=>{
 const sql=req.user.role==="citizen"?"SELECT id,slot_id,category,description,status,created_at FROM reports WHERE user_id=? ORDER BY created_at DESC":"SELECT r.id,r.slot_id,r.category,r.description,r.status,r.created_at,u.name citizen_name FROM reports r JOIN users u ON u.id=r.user_id ORDER BY r.created_at DESC LIMIT 300";
 res.json({reports:req.user.role==="citizen"?db.prepare(sql).all(req.user.id):db.prepare(sql).all()});
});
app.patch("/api/reports/:id",auth,csrf,role("police","admin"),(req,res)=>{
 const status=req.body?.status;if(!["reviewing","resolved","rejected"].includes(status))return res.status(400).json({error:"Invalid report status."});
 const r=db.prepare("UPDATE reports SET status=? WHERE id=?").run(status,Number(req.params.id));
 if(!r.changes)return res.status(404).json({error:"Report not found."});
 audit(req.user,"report_status_changed","report",Number(req.params.id));res.json({ok:true});
});
app.post("/api/violations",auth,csrf,role("citizen","police","admin"),(req,res)=>{
 const category=String(req.body?.category||"").slice(0,60), description=String(req.body?.description||"").trim(), slotId=req.body?.slotId?Number(req.body.slotId):null;
 if(!["unauthorized_parking","blocked_driveway","accessible_bay_misuse","double_parking","other"].includes(category)||description.length<8||description.length>1500)return res.status(400).json({error:"Choose a category and enter 8–1500 characters."});
 if(slotId&&!db.prepare("SELECT id FROM parking_slots WHERE id=?").get(slotId))return res.status(400).json({error:"Invalid slot."});
 const r=db.prepare("INSERT INTO violations(reporter_id,slot_id,category,description) VALUES(?,?,?,?)").run(req.user.id,slotId,category,description);
 audit(req.user,"violation_reported","violation",r.lastInsertRowid);res.status(201).json({id:r.lastInsertRowid,message:"Violation sent for human review."});
});
app.get("/api/violations",auth,role("police","admin"),(req,res)=>res.json({violations:db.prepare("SELECT v.*,u.name reporter_name,s.label slot_label FROM violations v LEFT JOIN users u ON u.id=v.reporter_id LEFT JOIN parking_slots s ON s.id=v.slot_id ORDER BY v.created_at DESC LIMIT 300").all()}));
app.patch("/api/violations/:id",auth,csrf,role("police","admin"),(req,res)=>{
 const status=req.body?.status;if(!["reviewing","resolved","dismissed"].includes(status))return res.status(400).json({error:"Invalid status."});
 const r=db.prepare("UPDATE violations SET status=? WHERE id=?").run(status,Number(req.params.id));
 if(!r.changes)return res.status(404).json({error:"Violation not found."});
 audit(req.user,"violation_status_changed","violation",Number(req.params.id));res.json({ok:true});
});
app.get("/api/audit",auth,role("admin"),(req,res)=>res.json({events:db.prepare("SELECT a.id,a.action,a.entity_type,a.entity_id,a.created_at,u.name actor FROM audit_log a LEFT JOIN users u ON u.id=a.actor_id ORDER BY a.id DESC LIMIT 200").all()}));

const aiTools = {
  occupancy_forecast: (slots)=>({tool:"occupancy_forecast",summary:`${slots.filter(s=>s.status==="occupied").length} of ${slots.length} listed spaces are occupied.`,recommendation:"Compare recent time-based counts before reallocating capacity.",confidence:"low",method:"current-state heuristic"}),
  parking_recommendation: (slots,input)=>({tool:"parking_recommendation",results:slots.filter(s=>s.status==="available"&&(!input.zone||s.zone===input.zone)&&(!input.accessible||s.accessible)&&(!input.evCharging||s.ev_charging)).sort((a,b)=>a.hourly_rate-b.hourly_rate).slice(0,5),method:"availability and preference ranking"}),
  report_classifier: (input)=>({tool:"report_classifier",category:/block|driveway|access/i.test(input.text||"")?"blocked_access":/sign|broken|damage/i.test(input.text||"")?"damaged_sign":"other",confidence:"low",method:"keyword triage; human review required"}),
  violation_triage: (items)=>({tool:"violation_triage",priority:items.map(v=>({...v,priority:/accessible|emergency|driveway/i.test(v.category+" "+v.description)?"high":"normal"})),method:"rule-based queue prioritization; no automatic penalty"}),
  demand_forecast: (slots)=>({tool:"demand_forecast",byZone:Object.values(slots.reduce((a,s)=>{a[s.zone]??={zone:s.zone,total:0,occupied:0};a[s.zone].total++;if(s.status==="occupied")a[s.zone].occupied++;return a},{})).map(z=>({...z,occupancyPercent:Math.round(z.occupied/z.total*100)})),method:"current occupancy proxy; not a time-series forecast"}),
  anomaly_detection: (slots)=>({tool:"anomaly_detection",alerts:slots.filter(s=>s.status==="occupied"&&(!s.updated_at||Date.now()-Date.parse(s.updated_at)>7*24*3600*1000)).map(s=>({slot:s.label,zone:s.zone,reason:"Occupied state has stale/missing update timestamp"})),method:"stale-state rules"}),
  route_scoring: (slots,input)=>({tool:"route_scoring",results:slots.filter(s=>s.status==="available").map(s=>({...s,score:(input.zone&&s.zone===input.zone?3:0)+(s.accessible?1:0)+(s.ev_charging?1:0)-(s.hourly_rate/100)})).sort((a,b)=>b.score-a.score).slice(0,5),method:"preference scoring; no live traffic feed"})
};
app.get("/api/ai/tools",auth,(req,res)=>res.json({tools:Object.keys(aiTools).map(name=>({name,description:({
 occupancy_forecast:"Summarize current occupancy state",
 parking_recommendation:"Rank available bays by preferences",
 report_classifier:"Suggest a report category from text",
 violation_triage:"Prioritize reports for human review",
 demand_forecast:"Compare occupancy by zone",
 anomaly_detection:"Flag stale occupancy records",
 route_scoring:"Rank bays using preferences"
 })[name]}))}));
app.post("/api/ai/:tool",auth,(req,res)=>{
 const tool=aiTools[req.params.tool];if(!tool)return res.status(404).json({error:"Unknown decision-support tool."});
 const slots=db.prepare("SELECT * FROM parking_slots ORDER BY zone,label").all();
 if(req.params.tool==="parking_recommendation"||req.params.tool==="route_scoring")return res.json(tool(slots,req.body||{}));
 if(req.params.tool==="report_classifier")return res.json(tool({text:String(req.body?.text||"").slice(0,1500)}));
 if(req.params.tool==="violation_triage"){if(!["police","admin"].includes(req.user.role))return res.status(403).json({error:"Police role required."});return res.json(tool(db.prepare("SELECT * FROM violations WHERE status IN ('open','reviewing') ORDER BY created_at").all()));}
 res.json(tool(slots));
});
app.get("/api/summary",auth,(req,res)=>{
 const slots=db.prepare("SELECT * FROM parking_slots ORDER BY zone,label").all();
 res.json({total:slots.length,available:slots.filter(s=>s.status==="available").length,zones:[...new Set(slots.map(s=>s.zone))],aiTools:Object.keys(aiTools).length});
});

const registerExtendedRoutes = require("./src/routes/extended");
const registerAccessibilityRoutes = require("./src/routes/accessibility");
const ParkingService = require("./src/services/parkingService");
const NotificationService = require("./src/services/notificationService");
const HealthService = require("./src/services/healthService");
const extendedDependencies = { db, auth, csrf, role, audit, ParkingService, NotificationService, HealthService };
registerExtendedRoutes(app, extendedDependencies);
registerAccessibilityRoutes(app, extendedDependencies);

app.use("/api",(req,res)=>res.status(404).json({error:"API endpoint not found."}));
app.use((err,req,res,next)=>{console.error(err);res.status(500).json({error:"Unexpected server error."});});
app.listen(PORT,()=>console.log(`Smart Parking running at http://localhost:${PORT}`));
