"use strict";

const { summarizeSlots, reportPriority, rankSlot } = require("./parkingRules");

function round(value, places = 2) {
  const scale = 10 ** places;
  return Math.round((Number(value) || 0) * scale) / scale;
}

function utilizationRate(slots) {
  if (!slots.length) return 0;
  return round(slots.filter(s => ["occupied", "reserved"].includes(s.status)).length / slots.length * 100, 1);
}

function zoneUtilization(slots) {
  const summary = summarizeSlots(slots);
  return Object.entries(summary.zones).map(([zone, data]) => ({
    zone,
    total: data.total,
    available: data.available,
    occupied: data.occupied,
    utilizationPercent: data.total ? round((data.total - data.available) / data.total * 100, 1) : 0
  })).sort((a, b) => b.utilizationPercent - a.utilizationPercent);
}

function availabilityBands(slots) {
  const summary = summarizeSlots(slots);
  const ratio = summary.total ? summary.available / summary.total : 0;
  if (ratio >= 0.65) return { level: "high", availableRatio: round(ratio * 100, 1), message: "Many bays are currently listed as available." };
  if (ratio >= 0.3) return { level: "moderate", availableRatio: round(ratio * 100, 1), message: "Availability is moderate; check zones before travelling." };
  return { level: "low", availableRatio: round(ratio * 100, 1), message: "Availability is limited; consider nearby zones." };
}

function staleSlots(slots, ageHours = 24, now = Date.now()) {
  const threshold = ageHours * 60 * 60 * 1000;
  return slots.filter(slot => {
    const updated = Date.parse(slot.updated_at || "");
    return !Number.isFinite(updated) || now - updated > threshold;
  }).map(slot => ({
    id: slot.id,
    label: slot.label,
    zone: slot.zone,
    status: slot.status,
    staleHours: Number.isFinite(Date.parse(slot.updated_at || "")) ? round((now - Date.parse(slot.updated_at)) / 3600000, 1) : null
  }));
}

function rankAvailableSlots(slots, preferences = {}) {
  return slots.filter(slot => slot.status === "available")
    .map(slot => ({ ...slot, score: rankSlot(slot, preferences) }))
    .sort((a, b) => b.score - a.score);
}

function classifyReport(text) {
  const value = String(text || "").toLowerCase();
  const patterns = [
    { category: "blocked_access", terms: ["blocked", "driveway", "entrance", "access"] },
    { category: "damaged_sign", terms: ["sign", "broken", "damaged", "board"] },
    { category: "wrong_occupancy", terms: ["occupied", "empty", "status", "sensor"] },
    { category: "unsafe_parking", terms: ["unsafe", "double parking", "danger", "visibility"] }
  ];
  const matches = patterns.map(pattern => ({
    category: pattern.category,
    score: pattern.terms.reduce((total, term) => total + (value.includes(term) ? 1 : 0), 0)
  })).sort((a, b) => b.score - a.score);
  if (!matches[0] || matches[0].score === 0) return { category: "other", confidence: "low", reason: "No category keywords matched." };
  return { category: matches[0].category, confidence: matches[0].score >= 2 ? "medium" : "low", reason: "Keyword suggestion; a person must confirm it." };
}

function violationQueue(violations) {
  return violations.map(item => ({
    ...item,
    priority: reportPriority(item.category, item.description)
  })).sort((a, b) => {
    const priority = { high: 0, medium: 1, normal: 2 };
    return priority[a.priority] - priority[b.priority];
  });
}

function hourlyRevenueEstimate(reservations) {
  return reservations.reduce((total, reservation) => {
    if (reservation.status !== "completed") return total;
    const start = Date.parse(reservation.starts_at);
    const end = Date.parse(reservation.ends_at);
    const hours = Number.isFinite(start) && Number.isFinite(end) ? Math.max(0, (end - start) / 3600000) : 0;
    return total + hours * Math.max(0, Number(reservation.hourly_rate) || 0);
  }, 0);
}

function generateDashboard(slots, reports = [], violations = [], reservations = []) {
  const summary = summarizeSlots(slots);
  return {
    generatedAt: new Date().toISOString(),
    summary,
    utilizationPercent: utilizationRate(slots),
    availability: availabilityBands(slots),
    zoneUtilization: zoneUtilization(slots),
    staleSlots: staleSlots(slots),
    reportCounts: reports.reduce((acc, report) => {
      acc[report.status] = (acc[report.status] || 0) + 1;
      return acc;
    }, {}),
    violationCounts: violations.reduce((acc, item) => {
      acc[item.status] = (acc[item.status] || 0) + 1;
      return acc;
    }, {}),
    activeReservations: reservations.filter(item => item.status === "active").length
  };
}

module.exports = {
  round,
  utilizationRate,
  zoneUtilization,
  availabilityBands,
  staleSlots,
  rankAvailableSlots,
  classifyReport,
  violationQueue,
  hourlyRevenueEstimate,
  generateDashboard
};
