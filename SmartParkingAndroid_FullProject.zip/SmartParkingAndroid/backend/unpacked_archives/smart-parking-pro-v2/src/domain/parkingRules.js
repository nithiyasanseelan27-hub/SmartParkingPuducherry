"use strict";

const SLOT_STATUSES = Object.freeze(["available", "occupied", "reserved", "maintenance"]);
const REPORT_STATUSES = Object.freeze(["submitted", "reviewing", "resolved", "rejected"]);
const VIOLATION_STATUSES = Object.freeze(["open", "reviewing", "resolved", "dismissed"]);
const REPORT_CATEGORIES = Object.freeze(["blocked_access", "wrong_occupancy", "damaged_sign", "unsafe_parking", "other"]);
const VIOLATION_CATEGORIES = Object.freeze(["unauthorized_parking", "blocked_driveway", "accessible_bay_misuse", "double_parking", "other"]);

function isKnown(value, options) {
  return typeof value === "string" && options.includes(value);
}

function isValidStatus(value) {
  return isKnown(value, SLOT_STATUSES);
}

function isValidReportStatus(value) {
  return isKnown(value, REPORT_STATUSES);
}

function isValidViolationStatus(value) {
  return isKnown(value, VIOLATION_STATUSES);
}

function isValidReportCategory(value) {
  return isKnown(value, REPORT_CATEGORIES);
}

function isValidViolationCategory(value) {
  return isKnown(value, VIOLATION_CATEGORIES);
}

function normalizeZone(value) {
  return String(value || "").trim().replace(/\s+/g, " ").slice(0, 80);
}

function normalizeDescription(value, maxLength = 1500) {
  return String(value || "").replace(/\u0000/g, "").trim().slice(0, maxLength);
}

function parsePositiveInteger(value) {
  const parsed = Number(value);
  return Number.isSafeInteger(parsed) && parsed > 0 ? parsed : null;
}

function parseTime(value) {
  const result = Date.parse(value);
  return Number.isFinite(result) ? result : null;
}

function validateReservationWindow(startsAt, endsAt, now = Date.now()) {
  const start = parseTime(startsAt);
  const end = parseTime(endsAt);
  if (start === null || end === null) {
    return { valid: false, reason: "Start and end times must be valid dates." };
  }
  if (start < now - 60000) {
    return { valid: false, reason: "Reservations must start in the future." };
  }
  if (end <= start) {
    return { valid: false, reason: "End time must be after start time." };
  }
  if (end - start > 24 * 60 * 60 * 1000) {
    return { valid: false, reason: "Reservations cannot exceed 24 hours." };
  }
  return { valid: true, startsAt: new Date(start).toISOString(), endsAt: new Date(end).toISOString() };
}

function hasReservationConflict(existing, candidate) {
  const start = Date.parse(candidate.startsAt);
  const end = Date.parse(candidate.endsAt);
  return existing.some(item => {
    if (item.status !== "active") return false;
    const otherStart = Date.parse(item.starts_at || item.startsAt);
    const otherEnd = Date.parse(item.ends_at || item.endsAt);
    return Number.isFinite(otherStart) && Number.isFinite(otherEnd) && start < otherEnd && end > otherStart;
  });
}

function isAvailableForPreferences(slot, preferences = {}) {
  if (slot.status !== "available") return false;
  if (preferences.zone && slot.zone !== preferences.zone) return false;
  if (preferences.accessible && !Boolean(slot.accessible)) return false;
  if (preferences.evCharging && !Boolean(slot.ev_charging)) return false;
  if (Number.isFinite(Number(preferences.maxHourlyRate)) && slot.hourly_rate > Number(preferences.maxHourlyRate)) return false;
  return true;
}

function rankSlot(slot, preferences = {}) {
  let score = 100;
  if (preferences.zone && slot.zone === preferences.zone) score += 30;
  if (preferences.accessible && slot.accessible) score += 25;
  if (preferences.evCharging && slot.ev_charging) score += 20;
  if (preferences.nearEntrance && slot.near_entrance) score += 10;
  score -= Math.max(0, Number(slot.hourly_rate) || 0);
  if (slot.status !== "available") score -= 1000;
  return Math.round(score * 100) / 100;
}

function summarizeSlots(slots) {
  const summary = { total: slots.length, available: 0, occupied: 0, reserved: 0, maintenance: 0, accessible: 0, evCharging: 0, zones: {} };
  for (const slot of slots) {
    if (summary[slot.status] !== undefined) summary[slot.status] += 1;
    if (slot.accessible) summary.accessible += 1;
    if (slot.ev_charging) summary.evCharging += 1;
    summary.zones[slot.zone] ||= { total: 0, available: 0, occupied: 0 };
    summary.zones[slot.zone].total += 1;
    if (slot.status === "available") summary.zones[slot.zone].available += 1;
    if (slot.status === "occupied") summary.zones[slot.zone].occupied += 1;
  }
  return summary;
}

function reportPriority(category, description) {
  const text = `${category} ${description}`.toLowerCase();
  if (/emergency|fire lane|ambulance|accessible|wheelchair|blocked driveway/.test(text)) return "high";
  if (/unsafe|danger|blocked|double park/.test(text)) return "medium";
  return "normal";
}

function canTransitionStatus(from, to, role) {
  const transitions = {
    available: ["occupied", "reserved", "maintenance"],
    occupied: ["available", "maintenance"],
    reserved: ["available", "occupied", "maintenance"],
    maintenance: ["available"]
  };
  if (!isValidStatus(from) || !isValidStatus(to)) return false;
  if (!["police", "admin"].includes(role)) return false;
  return from === to || transitions[from].includes(to);
}

module.exports = {
  SLOT_STATUSES,
  REPORT_STATUSES,
  VIOLATION_STATUSES,
  REPORT_CATEGORIES,
  VIOLATION_CATEGORIES,
  isValidStatus,
  isValidReportStatus,
  isValidViolationStatus,
  isValidReportCategory,
  isValidViolationCategory,
  normalizeZone,
  normalizeDescription,
  parsePositiveInteger,
  parseTime,
  validateReservationWindow,
  hasReservationConflict,
  isAvailableForPreferences,
  rankSlot,
  summarizeSlots,
  reportPriority,
  canTransitionStatus
};
