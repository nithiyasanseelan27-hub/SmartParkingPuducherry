"use strict";

const { createHash, randomBytes, timingSafeEqual } = require("crypto");

function sha256(value) {
  return createHash("sha256").update(String(value)).digest("hex");
}

function makeOpaqueToken(bytes = 32) {
  return randomBytes(bytes).toString("base64url");
}

function constantTimeEqual(left, right) {
  const a = Buffer.from(String(left || ""));
  const b = Buffer.from(String(right || ""));
  return a.length === b.length && timingSafeEqual(a, b);
}

function redactEmail(email) {
  const value = String(email || "");
  const at = value.indexOf("@");
  if (at < 1) return "[redacted]";
  const local = value.slice(0, at);
  const domain = value.slice(at + 1);
  return `${local[0]}${"*".repeat(Math.max(1, local.length - 1))}@${domain}`;
}

function redactText(value, limit = 160) {
  const text = String(value || "").replace(/[\r\n\t]+/g, " ").trim();
  return text.length > limit ? `${text.slice(0, limit)}…` : text;
}

function publicUser(user) {
  if (!user) return null;
  return {
    id: user.id,
    name: user.name,
    email: user.email,
    role: user.role
  };
}

function validateRetentionDays(days, minimum = 1, maximum = 3650) {
  const value = Number(days);
  return Number.isInteger(value) && value >= minimum && value <= maximum;
}

function redactAuditRecord(record) {
  return {
    id: record.id,
    actor: record.actor || "system",
    action: record.action,
    entity_type: record.entity_type,
    entity_id: record.entity_id,
    created_at: record.created_at
  };
}

module.exports = {
  sha256,
  makeOpaqueToken,
  constantTimeEqual,
  redactEmail,
  redactText,
  publicUser,
  validateRetentionDays,
  redactAuditRecord
};
