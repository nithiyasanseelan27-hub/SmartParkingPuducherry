"use strict";

const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const SAFE_NAME = /^[\p{L}\p{M} .'-]+$/u;

function result(valid, errors = [], value = null) {
  return { valid, errors, value };
}

function validateRegistration(input) {
  const errors = [];
  const name = String(input?.name || "").trim();
  const email = String(input?.email || "").trim().toLowerCase();
  const password = String(input?.password || "");
  if (name.length < 2 || name.length > 80 || !SAFE_NAME.test(name)) errors.push("Name must contain 2–80 letters or common punctuation.");
  if (email.length > 160 || !EMAIL.test(email)) errors.push("Enter a valid email address.");
  if (password.length < 12 || password.length > 128) errors.push("Password must contain 12–128 characters.");
  if (!/[A-Z]/.test(password)) errors.push("Password must contain an uppercase letter.");
  if (!/[a-z]/.test(password)) errors.push("Password must contain a lowercase letter.");
  if (!/[0-9]/.test(password)) errors.push("Password must contain a number.");
  return result(errors.length === 0, errors, { name, email, password });
}

function validatePagination(query = {}) {
  const page = Math.max(1, Math.min(100000, Number.parseInt(query.page, 10) || 1));
  const limit = Math.max(1, Math.min(100, Number.parseInt(query.limit, 10) || 20));
  return { page, limit, offset: (page - 1) * limit };
}

function validateCoordinates(latitude, longitude) {
  const lat = Number(latitude);
  const lng = Number(longitude);
  if (!Number.isFinite(lat) || lat < -90 || lat > 90) return result(false, ["Latitude must be between -90 and 90."]);
  if (!Number.isFinite(lng) || lng < -180 || lng > 180) return result(false, ["Longitude must be between -180 and 180."]);
  return result(true, [], { latitude: lat, longitude: lng });
}

function validateMoney(value, maximum = 100000) {
  const amount = Number(value);
  if (!Number.isFinite(amount) || amount < 0 || amount > maximum) return result(false, ["Amount is outside the allowed range."]);
  return result(true, [], Math.round(amount * 100) / 100);
}

function validateDescription(value, minimum = 8, maximum = 1500) {
  const description = String(value || "").replace(/\u0000/g, "").trim();
  if (description.length < minimum) return result(false, [`Description must contain at least ${minimum} characters.`]);
  if (description.length > maximum) return result(false, [`Description cannot exceed ${maximum} characters.`]);
  return result(true, [], description);
}

function validateIdentifier(value) {
  const id = Number(value);
  if (!Number.isSafeInteger(id) || id < 1) return result(false, ["Identifier must be a positive integer."]);
  return result(true, [], id);
}

function validateSearch(value) {
  const search = String(value || "").trim().replace(/\s+/g, " ");
  if (search.length > 100) return result(false, ["Search query cannot exceed 100 characters."]);
  if (/[<>{}]/.test(search)) return result(false, ["Search query contains unsupported characters."]);
  return result(true, [], search);
}

module.exports = {
  validateRegistration,
  validatePagination,
  validateCoordinates,
  validateMoney,
  validateDescription,
  validateIdentifier,
  validateSearch
};
