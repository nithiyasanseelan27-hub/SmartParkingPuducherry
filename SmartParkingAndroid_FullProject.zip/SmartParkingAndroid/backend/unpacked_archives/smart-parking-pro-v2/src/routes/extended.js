"use strict";

const analytics = require("../domain/analytics");
const rules = require("../domain/parkingRules");
const validation = require("../domain/validation");
const { buildSlotCsv, buildReservationCsv, buildReportCsv } = require("../services/exportService");
const { normalizePagination } = require("../services/pagination");

function registerExtendedRoutes(app, dependencies) {
  const { db, auth, csrf, role, audit, ParkingService, NotificationService, HealthService } = dependencies;
  const parking = new ParkingService(db);
  const notifications = new NotificationService(db);
  const health = new HealthService(db);

  app.get("/api/v2/health", (req, res) => {
    const result = health.check();
    res.status(result.status === "ok" ? 200 : 503).json(result);
  });

  app.get("/api/v2/parking/zones", auth, (req, res) => {
    res.json({ zones: parking.getZones() });
  });

  app.get("/api/v2/parking/recommendations", auth, (req, res) => {
    const preferences = {
      zone: String(req.query.zone || "").slice(0, 80),
      accessible: req.query.accessible === "true",
      evCharging: req.query.evCharging === "true",
      maxHourlyRate: req.query.maxHourlyRate === undefined ? undefined : Number(req.query.maxHourlyRate)
    };
    if (preferences.maxHourlyRate !== undefined && (!Number.isFinite(preferences.maxHourlyRate) || preferences.maxHourlyRate < 0)) {
      return res.status(400).json({ error: "Maximum hourly rate must be a non-negative number." });
    }
    res.json({ recommendations: parking.recommend(preferences), method: "preference ranking" });
  });

  app.get("/api/v2/analytics/overview", auth, role("police", "admin"), (req, res) => {
    const slots = db.prepare("SELECT * FROM parking_slots").all();
    const reports = db.prepare("SELECT status FROM reports").all();
    const violations = db.prepare("SELECT status,category,description FROM violations").all();
    const reservations = db.prepare("SELECT status FROM reservations").all();
    res.json(analytics.generateDashboard(slots, reports, violations, reservations));
  });

  app.get("/api/v2/analytics/stale-slots", auth, role("police", "admin"), (req, res) => {
    const hours = Number(req.query.hours || 24);
    if (!Number.isFinite(hours) || hours < 1 || hours > 720) {
      return res.status(400).json({ error: "Hours must be between 1 and 720." });
    }
    res.json({ alerts: parking.getStaleSlots(hours), ageHours: hours });
  });

  app.get("/api/v2/analytics/zone-utilization", auth, role("police", "admin"), (req, res) => {
    const slots = db.prepare("SELECT * FROM parking_slots").all();
    res.json({ zones: analytics.zoneUtilization(slots), utilizationPercent: analytics.utilizationRate(slots) });
  });

  app.post("/api/v2/ai/classify-report", auth, csrf, (req, res) => {
    const description = validation.validateDescription(req.body?.description, 8, 1500);
    if (!description.valid) return res.status(400).json({ error: description.errors[0] });
    res.json({ suggestion: analytics.classifyReport(description.value), humanReviewRequired: true });
  });

  app.post("/api/v2/ai/rank-parking", auth, csrf, (req, res) => {
    const preferences = {
      zone: String(req.body?.zone || "").slice(0, 80),
      accessible: req.body?.accessible === true,
      evCharging: req.body?.evCharging === true,
      nearEntrance: req.body?.nearEntrance === true
    };
    const slots = db.prepare("SELECT * FROM parking_slots").all();
    res.json({ results: analytics.rankAvailableSlots(slots, preferences).slice(0, 10), method: "transparent preference score" });
  });

  app.get("/api/v2/notifications", auth, (req, res) => {
    const pagination = normalizePagination(req.query);
    const rows = notifications.list(req.user.id, { unreadOnly: req.query.unread === "true", limit: pagination.limit });
    res.json({ notifications: rows, unreadCount: notifications.countUnread(req.user.id) });
  });

  app.post("/api/v2/notifications/:id/read", auth, csrf, (req, res) => {
    const parsed = validation.validateIdentifier(req.params.id);
    if (!parsed.valid) return res.status(400).json({ error: parsed.errors[0] });
    if (!notifications.markRead(req.user.id, parsed.value)) return res.status(404).json({ error: "Notification not found or already read." });
    audit(req.user, "notification_read", "notification", parsed.value);
    res.json({ ok: true });
  });

  app.post("/api/v2/notifications/read-all", auth, csrf, (req, res) => {
    const changed = notifications.markAllRead(req.user.id);
    audit(req.user, "notifications_marked_read", "notification", null);
    res.json({ ok: true, changed });
  });

  app.delete("/api/v2/notifications/:id", auth, csrf, (req, res) => {
    const parsed = validation.validateIdentifier(req.params.id);
    if (!parsed.valid) return res.status(400).json({ error: parsed.errors[0] });
    if (!notifications.delete(req.user.id, parsed.value)) return res.status(404).json({ error: "Notification not found." });
    audit(req.user, "notification_deleted", "notification", parsed.value);
    res.json({ ok: true });
  });

  app.get("/api/v2/export/slots.csv", auth, role("police", "admin"), (req, res) => {
    const slots = db.prepare("SELECT * FROM parking_slots ORDER BY zone,label").all();
    res.setHeader("Content-Type", "text/csv; charset=utf-8");
    res.setHeader("Content-Disposition", 'attachment; filename="parking-slots.csv"');
    res.send(buildSlotCsv(slots));
  });

  app.get("/api/v2/export/reservations.csv", auth, role("police", "admin"), (req, res) => {
    const reservations = db.prepare("SELECT r.*,u.name citizen_name,s.label,s.zone,s.hourly_rate FROM reservations r JOIN users u ON u.id=r.user_id JOIN parking_slots s ON s.id=r.slot_id ORDER BY r.created_at DESC").all();
    res.setHeader("Content-Type", "text/csv; charset=utf-8");
    res.setHeader("Content-Disposition", 'attachment; filename="reservations.csv"');
    res.send(buildReservationCsv(reservations));
  });

  app.get("/api/v2/export/reports.csv", auth, role("police", "admin"), (req, res) => {
    const reports = db.prepare("SELECT id,category,description,status,created_at FROM reports ORDER BY created_at DESC").all();
    res.setHeader("Content-Type", "text/csv; charset=utf-8");
    res.setHeader("Content-Disposition", 'attachment; filename="citizen-reports.csv"');
    res.send(buildReportCsv(reports));
  });

  app.post("/api/v2/sensors/parking/:id", auth, csrf, role("admin"), (req, res) => {
    const id = validation.validateIdentifier(req.params.id);
    if (!id.valid) return res.status(400).json({ error: id.errors[0] });
    const deviceId = String(req.body?.deviceId || "").trim();
    const state = String(req.body?.state || "");
    if (deviceId.length < 3 || deviceId.length > 60) return res.status(400).json({ error: "A valid device identifier is required." });
    const result = parking.markSensorUpdate(id.value, state, deviceId);
    if (!result.ok) return res.status(result.status).json({ error: result.error });
    audit(req.user, "sensor_state_received", "parking_slot", id.value);
    res.json({ ok: true, slot: result.slot });
  });

  app.get("/api/v2/police/violations/priority", auth, role("police", "admin"), (req, res) => {
    const violations = db.prepare("SELECT * FROM violations WHERE status IN ('open','reviewing')").all();
    res.json({ queue: analytics.violationQueue(violations), notice: "Priority is a suggestion for human review, not an automated enforcement decision." });
  });

  app.get("/api/v2/me/summary", auth, (req, res) => {
    const reservations = db.prepare("SELECT COUNT(*) count FROM reservations WHERE user_id=?").get(req.user.id).count;
    const reports = db.prepare("SELECT COUNT(*) count FROM reports WHERE user_id=?").get(req.user.id).count;
    const unread = notifications.countUnread(req.user.id);
    res.json({ reservations, reports, unreadNotifications: unread });
  });
}

module.exports = registerExtendedRoutes;
