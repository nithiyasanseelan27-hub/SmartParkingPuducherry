"use strict";

function registerAccessibilityRoutes(app, dependencies) {
  const { auth, csrf, db, audit } = dependencies;
  db.exec(`
    CREATE TABLE IF NOT EXISTS user_preferences(
      user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
      theme TEXT NOT NULL DEFAULT 'system',
      compact_mode INTEGER NOT NULL DEFAULT 0,
      large_text INTEGER NOT NULL DEFAULT 0,
      reduced_motion INTEGER NOT NULL DEFAULT 0,
      updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
  `);

  app.get("/api/v2/me/preferences", auth, (req, res) => {
    const preferences = db.prepare("SELECT * FROM user_preferences WHERE user_id=?").get(req.user.id);
    res.json({ preferences: preferences || { theme: "system", compact_mode: 0, large_text: 0, reduced_motion: 0 } });
  });

  app.put("/api/v2/me/preferences", auth, csrf, (req, res) => {
    const theme = String(req.body?.theme || "system");
    if (!["system", "light", "dark"].includes(theme)) return res.status(400).json({ error: "Theme must be system, light or dark." });
    const values = {
      theme,
      compact: req.body?.compactMode === true ? 1 : 0,
      large: req.body?.largeText === true ? 1 : 0,
      motion: req.body?.reducedMotion === true ? 1 : 0
    };
    db.prepare(`
      INSERT INTO user_preferences(user_id,theme,compact_mode,large_text,reduced_motion,updated_at)
      VALUES(?,?,?,?,?,CURRENT_TIMESTAMP)
      ON CONFLICT(user_id) DO UPDATE SET theme=excluded.theme,compact_mode=excluded.compact_mode,large_text=excluded.large_text,reduced_motion=excluded.reduced_motion,updated_at=CURRENT_TIMESTAMP
    `).run(req.user.id, values.theme, values.compact, values.large, values.motion);
    audit(req.user, "preferences_updated", "user_preferences", req.user.id);
    res.json({ ok: true, preferences: values });
  });
}

module.exports = registerAccessibilityRoutes;
