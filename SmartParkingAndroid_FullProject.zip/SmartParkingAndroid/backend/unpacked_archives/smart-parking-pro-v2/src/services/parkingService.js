"use strict";

const rules = require("../domain/parkingRules");
const analytics = require("../domain/analytics");

class ParkingService {
  constructor(database) {
    this.db = database;
  }

  list(filters = {}) {
    const page = Math.max(1, Number(filters.page) || 1);
    const limit = Math.min(100, Math.max(1, Number(filters.limit) || 50));
    const conditions = [];
    const args = [];
    if (filters.zone) {
      conditions.push("zone = ?");
      args.push(String(filters.zone).slice(0, 80));
    }
    if (rules.isValidStatus(filters.status)) {
      conditions.push("status = ?");
      args.push(filters.status);
    }
    if (filters.accessible === "true") conditions.push("accessible = 1");
    if (filters.evCharging === "true") conditions.push("ev_charging = 1");
    if (filters.maxRate !== undefined && Number.isFinite(Number(filters.maxRate))) {
      conditions.push("hourly_rate <= ?");
      args.push(Math.max(0, Number(filters.maxRate)));
    }
    if (filters.search) {
      conditions.push("(label LIKE ? OR zone LIKE ?)");
      const value = `%${String(filters.search).slice(0, 80)}%`;
      args.push(value, value);
    }
    const where = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";
    const total = this.db.prepare(`SELECT COUNT(*) AS total FROM parking_slots ${where}`).get(...args).total;
    const slots = this.db.prepare(
      `SELECT * FROM parking_slots ${where} ORDER BY zone, label LIMIT ? OFFSET ?`
    ).all(...args, limit, (page - 1) * limit);
    return { slots, page, limit, total, pages: Math.ceil(total / limit) };
  }

  getById(id) {
    return this.db.prepare("SELECT * FROM parking_slots WHERE id = ?").get(id) || null;
  }

  getZones() {
    return this.db.prepare(
      "SELECT zone, COUNT(*) AS total, SUM(status='available') AS available, SUM(status='occupied') AS occupied, SUM(accessible) AS accessible, SUM(ev_charging) AS evCharging FROM parking_slots GROUP BY zone ORDER BY zone"
    ).all();
  }

  updateStatus(id, status, actorId) {
    const slot = this.getById(id);
    if (!slot) return { ok: false, status: 404, error: "Parking bay not found." };
    if (!rules.isValidStatus(status)) return { ok: false, status: 400, error: "Unknown parking status." };
    if (!rules.canTransitionStatus(slot.status, status, "police")) {
      return { ok: false, status: 409, error: `Status cannot transition from ${slot.status} to ${status}.` };
    }
    this.db.prepare("UPDATE parking_slots SET status=?, updated_at=CURRENT_TIMESTAMP WHERE id=?").run(status, id);
    this.db.prepare("INSERT INTO audit_log(actor_id,action,entity_type,entity_id) VALUES(?,?,?,?)")
      .run(actorId, "parking_status_updated", "parking_slot", id);
    return { ok: true, slot: this.getById(id) };
  }

  recommend(preferences = {}) {
    const all = this.db.prepare("SELECT * FROM parking_slots WHERE status='available'").all();
    return analytics.rankAvailableSlots(all, preferences).filter(slot =>
      rules.isAvailableForPreferences(slot, preferences)
    ).slice(0, 10);
  }

  getSummary() {
    return analytics.generateDashboard(this.db.prepare("SELECT * FROM parking_slots").all());
  }

  getStaleSlots(hours = 24) {
    return analytics.staleSlots(this.db.prepare("SELECT * FROM parking_slots").all(), hours);
  }

  markSensorUpdate(id, sensorState, deviceId) {
    const allowed = ["available", "occupied", "maintenance"];
    if (!allowed.includes(sensorState)) return { ok: false, status: 400, error: "Invalid sensor state." };
    const slot = this.getById(id);
    if (!slot) return { ok: false, status: 404, error: "Parking bay not found." };
    this.db.prepare("UPDATE parking_slots SET status=?, updated_at=CURRENT_TIMESTAMP WHERE id=?")
      .run(sensorState, id);
    this.db.prepare("INSERT INTO audit_log(actor_id,action,entity_type,entity_id) VALUES(NULL,?,?,?)")
      .run(`sensor_update:${String(deviceId).slice(0, 60)}`, "parking_slot", id);
    return { ok: true, slot: this.getById(id) };
  }
}

module.exports = ParkingService;
