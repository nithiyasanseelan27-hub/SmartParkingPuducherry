"use strict";

class NotificationService {
  constructor(database) {
    this.db = database;
    this.db.exec(`
      CREATE TABLE IF NOT EXISTS notifications(
        id INTEGER PRIMARY KEY,
        user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        title TEXT NOT NULL,
        body TEXT NOT NULL,
        kind TEXT NOT NULL DEFAULT 'info',
        read_at TEXT,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
      );
      CREATE INDEX IF NOT EXISTS idx_notifications_user_read ON notifications(user_id, read_at);
    `);
  }

  create(userId, title, body, kind = "info") {
    const safeTitle = String(title || "").trim().slice(0, 120);
    const safeBody = String(body || "").trim().slice(0, 1000);
    if (!userId || !safeTitle || !safeBody) throw new Error("A recipient, title and body are required.");
    if (!["info", "success", "warning", "error"].includes(kind)) throw new Error("Unknown notification kind.");
    const result = this.db.prepare(
      "INSERT INTO notifications(user_id,title,body,kind) VALUES(?,?,?,?)"
    ).run(userId, safeTitle, safeBody, kind);
    return this.getById(userId, result.lastInsertRowid);
  }

  getById(userId, id) {
    return this.db.prepare("SELECT * FROM notifications WHERE user_id=? AND id=?").get(userId, id) || null;
  }

  list(userId, { unreadOnly = false, limit = 50 } = {}) {
    const boundedLimit = Math.min(100, Math.max(1, Number(limit) || 50));
    if (unreadOnly) {
      return this.db.prepare("SELECT * FROM notifications WHERE user_id=? AND read_at IS NULL ORDER BY id DESC LIMIT ?")
        .all(userId, boundedLimit);
    }
    return this.db.prepare("SELECT * FROM notifications WHERE user_id=? ORDER BY id DESC LIMIT ?")
      .all(userId, boundedLimit);
  }

  countUnread(userId) {
    return this.db.prepare("SELECT COUNT(*) AS count FROM notifications WHERE user_id=? AND read_at IS NULL")
      .get(userId).count;
  }

  markRead(userId, id) {
    const result = this.db.prepare(
      "UPDATE notifications SET read_at=CURRENT_TIMESTAMP WHERE user_id=? AND id=? AND read_at IS NULL"
    ).run(userId, id);
    return result.changes > 0;
  }

  markAllRead(userId) {
    return this.db.prepare(
      "UPDATE notifications SET read_at=CURRENT_TIMESTAMP WHERE user_id=? AND read_at IS NULL"
    ).run(userId).changes;
  }

  delete(userId, id) {
    return this.db.prepare("DELETE FROM notifications WHERE user_id=? AND id=?").run(userId, id).changes > 0;
  }
}

module.exports = NotificationService;
