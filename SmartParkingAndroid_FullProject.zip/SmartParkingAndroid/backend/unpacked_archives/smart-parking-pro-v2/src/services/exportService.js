"use strict";

function csvCell(value) {
  const raw = value === null || value === undefined ? "" : String(value);
  const formulaSafe = /^[\s]*[=+\-@]/.test(raw) ? `'${raw}` : raw;
  return `"${formulaSafe.replace(/"/g, '""')}"`;
}

function toCsv(rows, columns) {
  const header = columns.map(column => csvCell(column.label)).join(",");
  const lines = rows.map(row => columns.map(column => csvCell(row[column.key])).join(","));
  return [header, ...lines].join("\r\n");
}

function buildSlotCsv(slots) {
  return toCsv(slots, [
    { key: "id", label: "ID" },
    { key: "label", label: "Bay" },
    { key: "zone", label: "Zone" },
    { key: "status", label: "Status" },
    { key: "accessible", label: "Accessible" },
    { key: "ev_charging", label: "EV Charging" },
    { key: "hourly_rate", label: "Hourly Rate" },
    { key: "updated_at", label: "Last Updated" }
  ]);
}

function buildReservationCsv(rows) {
  return toCsv(rows, [
    { key: "id", label: "Reservation ID" },
    { key: "citizen_name", label: "Citizen" },
    { key: "label", label: "Bay" },
    { key: "zone", label: "Zone" },
    { key: "starts_at", label: "Start" },
    { key: "ends_at", label: "End" },
    { key: "status", label: "Status" }
  ]);
}

function buildReportCsv(rows) {
  return toCsv(rows, [
    { key: "id", label: "Report ID" },
    { key: "category", label: "Category" },
    { key: "description", label: "Description" },
    { key: "status", label: "Status" },
    { key: "created_at", label: "Created At" }
  ]);
}

module.exports = { csvCell, toCsv, buildSlotCsv, buildReservationCsv, buildReportCsv };
