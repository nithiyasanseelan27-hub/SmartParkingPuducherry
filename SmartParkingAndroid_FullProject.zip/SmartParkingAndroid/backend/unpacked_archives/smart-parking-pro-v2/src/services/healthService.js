"use strict";

const os = require("os");

class HealthService {
  constructor(database, startedAt = Date.now()) {
    this.db = database;
    this.startedAt = startedAt;
  }

  check() {
    const checks = {};
    try {
      this.db.prepare("SELECT 1 AS ok").get();
      checks.database = { ok: true };
    } catch (error) {
      checks.database = { ok: false, message: "Database query failed." };
    }
    const memory = process.memoryUsage();
    return {
      status: Object.values(checks).every(check => check.ok) ? "ok" : "degraded",
      timestamp: new Date().toISOString(),
      uptimeSeconds: Math.floor((Date.now() - this.startedAt) / 1000),
      process: {
        node: process.version,
        platform: process.platform,
        architecture: process.arch,
        pid: process.pid,
        hostname: os.hostname(),
        memory: {
          rssBytes: memory.rss,
          heapUsedBytes: memory.heapUsed,
          heapTotalBytes: memory.heapTotal
        }
      },
      checks
    };
  }
}

module.exports = HealthService;
