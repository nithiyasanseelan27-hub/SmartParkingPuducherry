"use strict";

function normalizeSearch(value) {
  return String(value || "").trim().replace(/\s+/g, " ").slice(0, 100);
}

function makeLikePattern(value) {
  return `%${normalizeSearch(value).replace(/[\\%_]/g, character => `\\${character}`)}%`;
}

function filterSlots(slots, filters = {}) {
  const query = normalizeSearch(filters.search).toLowerCase();
  const zone = String(filters.zone || "").trim().toLowerCase();
  const status = String(filters.status || "").trim().toLowerCase();
  const accessible = filters.accessible === true || filters.accessible === "true";
  const evCharging = filters.evCharging === true || filters.evCharging === "true";
  const maxRate = filters.maxRate === "" || filters.maxRate === undefined ? null : Number(filters.maxRate);
  return slots.filter(slot => {
    if (zone && String(slot.zone).toLowerCase() !== zone) return false;
    if (status && String(slot.status).toLowerCase() !== status) return false;
    if (accessible && !Boolean(slot.accessible)) return false;
    if (evCharging && !Boolean(slot.ev_charging)) return false;
    if (maxRate !== null && Number.isFinite(maxRate) && Number(slot.hourly_rate) > maxRate) return false;
    if (query && !`${slot.label} ${slot.zone}`.toLowerCase().includes(query)) return false;
    return true;
  });
}

function sortSlots(slots, sort = "zone") {
  const copy = [...slots];
  const compare = {
    zone: (a, b) => String(a.zone).localeCompare(String(b.zone)) || String(a.label).localeCompare(String(b.label)),
    rate_asc: (a, b) => Number(a.hourly_rate) - Number(b.hourly_rate),
    rate_desc: (a, b) => Number(b.hourly_rate) - Number(a.hourly_rate),
    availability: (a, b) => Number(b.status === "available") - Number(a.status === "available"),
    updated: (a, b) => Date.parse(b.updated_at || 0) - Date.parse(a.updated_at || 0)
  };
  copy.sort(compare[sort] || compare.zone);
  return copy;
}

module.exports = { normalizeSearch, makeLikePattern, filterSlots, sortSlots };
