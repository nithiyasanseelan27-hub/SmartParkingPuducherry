"use strict";

class MemoryWindowStore {
  constructor({ windowMs = 60000, limit = 60, now = () => Date.now() } = {}) {
    this.windowMs = windowMs;
    this.limit = limit;
    this.now = now;
    this.entries = new Map();
  }

  keyFor(request) {
    return String(request.ip || request.socket?.remoteAddress || "unknown").slice(0, 100);
  }

  consume(key) {
    const currentTime = this.now();
    const current = this.entries.get(key);
    if (!current || current.resetAt <= currentTime) {
      const next = { count: 1, resetAt: currentTime + this.windowMs };
      this.entries.set(key, next);
      return { allowed: true, remaining: this.limit - 1, resetAt: next.resetAt };
    }
    current.count += 1;
    return {
      allowed: current.count <= this.limit,
      remaining: Math.max(0, this.limit - current.count),
      resetAt: current.resetAt
    };
  }

  middleware() {
    return (req, res, next) => {
      const outcome = this.consume(this.keyFor(req));
      res.setHeader("RateLimit-Limit", String(this.limit));
      res.setHeader("RateLimit-Remaining", String(outcome.remaining));
      res.setHeader("RateLimit-Reset", String(Math.ceil(outcome.resetAt / 1000)));
      if (!outcome.allowed) return res.status(429).json({ error: "Too many requests. Try again later." });
      next();
    };
  }

  prune() {
    const now = this.now();
    for (const [key, value] of this.entries.entries()) {
      if (value.resetAt <= now) this.entries.delete(key);
    }
  }

  clear() {
    this.entries.clear();
  }
}

module.exports = MemoryWindowStore;
