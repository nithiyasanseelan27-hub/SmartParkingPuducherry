"use strict";

function normalizePagination(query = {}) {
  const rawPage = Number.parseInt(query.page, 10);
  const rawLimit = Number.parseInt(query.limit, 10);
  const page = Number.isFinite(rawPage) ? Math.max(1, Math.min(rawPage, 100000)) : 1;
  const limit = Number.isFinite(rawLimit) ? Math.max(1, Math.min(rawLimit, 100)) : 20;
  return { page, limit, offset: (page - 1) * limit };
}

function paginateArray(items, options = {}) {
  const { page, limit, offset } = normalizePagination(options);
  const total = items.length;
  return {
    items: items.slice(offset, offset + limit),
    page,
    limit,
    total,
    totalPages: Math.ceil(total / limit),
    hasPreviousPage: page > 1,
    hasNextPage: offset + limit < total
  };
}

function paginationLinks(path, page, limit, total) {
  const totalPages = Math.ceil(total / limit);
  const make = value => `${path}?page=${value}&limit=${limit}`;
  return {
    first: totalPages ? make(1) : null,
    previous: page > 1 ? make(page - 1) : null,
    next: page < totalPages ? make(page + 1) : null,
    last: totalPages ? make(totalPages) : null
  };
}

module.exports = { normalizePagination, paginateArray, paginationLinks };
