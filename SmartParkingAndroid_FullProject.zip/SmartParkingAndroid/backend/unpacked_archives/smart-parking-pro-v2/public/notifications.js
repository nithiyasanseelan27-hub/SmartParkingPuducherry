"use strict";

(function () {
  const button = document.createElement("button");
  button.className = "btn secondary";
  button.id = "notifications-open";
  button.textContent = "Notifications";
  button.setAttribute("aria-haspopup", "dialog");

  const dialog = document.createElement("dialog");
  dialog.id = "notifications-dialog";
  dialog.innerHTML = `
    <div class="notifications-box">
      <div class="panel-head"><h2>Notifications</h2><button class="btn small secondary" id="notifications-close">Close</button></div>
      <div class="notification-actions"><button class="btn small secondary" id="notifications-refresh">Refresh</button><button class="btn small secondary" id="notifications-read-all">Mark all read</button></div>
      <div id="notifications-list"><p class="muted">Sign in to load notifications.</p></div>
    </div>
  `;

  async function api(url, options = {}) {
    const response = await fetch(url, { credentials: "same-origin", ...options, headers: { "Content-Type": "application/json", ...(options.headers || {}) } });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || "Notification request failed.");
    return data;
  }

  function escapeHtml(value) {
    return String(value ?? "").replace(/[&<>"']/g, character => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
    }[character]));
  }

  function csrfToken() {
    return window.smartParkingCsrf || "";
  }

  async function load() {
    const target = document.querySelector("#notifications-list");
    try {
      const data = await api("/api/v2/notifications");
      button.textContent = data.unreadCount ? `Notifications (${data.unreadCount})` : "Notifications";
      target.innerHTML = data.notifications.length ? data.notifications.map(item => `
        <article class="notification-item ${item.read_at ? "read" : "unread"}">
          <div><strong>${escapeHtml(item.title)}</strong><span class="notification-kind">${escapeHtml(item.kind)}</span></div>
          <p>${escapeHtml(item.body)}</p>
          <small>${escapeHtml(item.created_at)}</small>
          ${item.read_at ? "" : `<button class="btn small secondary" data-notification-read="${item.id}">Mark read</button>`}
        </article>
      `).join("") : '<p class="muted">No notifications yet.</p>';
      target.querySelectorAll("[data-notification-read]").forEach(control => {
        control.addEventListener("click", async () => {
          try {
            await api(`/api/v2/notifications/${control.dataset.notificationRead}/read`, {
              method: "POST",
              headers: { "x-csrf-token": csrfToken() },
              body: "{}"
            });
            await load();
          } catch (error) {
            target.insertAdjacentHTML("afterbegin", `<p class="muted">${escapeHtml(error.message)}</p>`);
          }
        });
      });
    } catch (error) {
      target.textContent = error.message;
    }
  }

  function mount() {
    const session = document.querySelector("#session-area");
    if (!session || document.querySelector("#notifications-open")) return;
    session.prepend(button);
    document.body.appendChild(dialog);
    button.addEventListener("click", async () => {
      dialog.showModal();
      await load();
    });
    document.querySelector("#notifications-close").addEventListener("click", () => dialog.close());
    document.querySelector("#notifications-refresh").addEventListener("click", load);
    document.querySelector("#notifications-read-all").addEventListener("click", async () => {
      try {
        await api("/api/v2/notifications/read-all", {
          method: "POST",
          headers: { "x-csrf-token": csrfToken() },
          body: "{}"
        });
        await load();
      } catch (error) {
        document.querySelector("#notifications-list").textContent = error.message;
      }
    });
  }

  const style = document.createElement("style");
  style.textContent = `.notifications-box{min-width:min(520px,82vw);max-height:75vh;overflow:auto;padding:5px}.notifications-box h2{font-size:18px;margin:0}.notification-actions{display:flex;gap:8px;margin:14px 0}.notification-item{padding:13px;border:1px solid var(--line);border-radius:12px;margin:9px 0}.notification-item.unread{background:#f2f6ff;border-color:#cbd8f7}.notification-item p{margin:7px 0;font-size:13px}.notification-item small{color:var(--muted);font-size:10px}.notification-kind{font-size:10px;margin-left:8px;text-transform:uppercase;color:var(--muted)}#notifications-open{margin-right:8px}@media(max-width:500px){#notifications-open{font-size:10px;padding:8px}}`;
  document.head.appendChild(style);
  document.addEventListener("DOMContentLoaded", mount);
  const observer = new MutationObserver(mount);
  observer.observe(document.documentElement, { childList: true, subtree: true });
})();
