"use strict";

(function () {
  const root = document.createElement("section");
  root.id = "advanced-analytics";
  root.className = "panel advanced-panel";
  root.innerHTML = `
    <div class="panel-head">
      <div>
        <p class="eyebrow">OPERATIONS INTELLIGENCE</p>
        <h2>Advanced analytics</h2>
      </div>
      <button class="btn small secondary" id="analytics-refresh">Refresh analytics</button>
    </div>
    <div class="analytics-grid">
      <div class="metric-card"><span>Utilization</span><strong id="metric-utilization">—</strong><div class="meter"><span id="utilization-meter"></span></div></div>
      <div class="metric-card"><span>Available bays</span><strong id="metric-available">—</strong><small>Current inventory snapshot</small></div>
      <div class="metric-card"><span>Stale records</span><strong id="metric-stale">—</strong><small>Records needing verification</small></div>
      <div class="metric-card"><span>Active reservations</span><strong id="metric-reservations">—</strong><small>Across all listed zones</small></div>
    </div>
    <div class="analytics-chart-wrap"><h3>Zone utilization</h3><div id="zone-chart" class="zone-chart"></div></div>
    <div class="analytics-actions">
      <a class="btn secondary" href="/api/v2/export/slots.csv">Export parking CSV</a>
      <a class="btn secondary" href="/api/v2/export/reservations.csv">Export reservations CSV</a>
      <a class="btn secondary" href="/api/v2/export/reports.csv">Export reports CSV</a>
    </div>
    <p class="muted">Analytics reflect the data currently stored in this demonstration database. Sensor freshness and forecast accuracy depend on real integrations.</p>
  `;
  const style = document.createElement("style");
  style.textContent = `
    .advanced-panel{margin-top:18px}.analytics-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;margin:18px 0}.metric-card{border:1px solid var(--line);border-radius:14px;padding:15px;background:linear-gradient(180deg,#fff,#f9faff)}.metric-card span,.metric-card small{display:block;color:var(--muted);font-size:11px}.metric-card strong{display:block;font-size:28px;margin:7px 0}.meter{height:7px;border-radius:10px;background:#e4e9f5;overflow:hidden}.meter span{display:block;height:100%;width:0;background:#3158b6;transition:width .3s}.analytics-chart-wrap{padding:15px;border:1px solid var(--line);border-radius:14px}.analytics-chart-wrap h3{margin:0 0 15px;font-size:14px}.zone-chart{display:grid;gap:12px}.zone-row{display:grid;grid-template-columns:130px minmax(50px,1fr) 55px;align-items:center;gap:12px;font-size:12px}.zone-bar{height:12px;background:#e8edf8;border-radius:20px;overflow:hidden}.zone-bar span{height:100%;display:block;background:linear-gradient(90deg,#2346a3,#4b7ce3);border-radius:20px}.analytics-actions{display:flex;gap:8px;flex-wrap:wrap;margin:15px 0}.analytics-actions a{text-decoration:none;font-size:12px}@media(max-width:700px){.analytics-grid{grid-template-columns:repeat(2,minmax(0,1fr))}.zone-row{grid-template-columns:90px minmax(40px,1fr) 45px;gap:7px}}@media(max-width:420px){.analytics-grid{grid-template-columns:1fr 1fr}.metric-card strong{font-size:22px}}
  `;
  document.head.appendChild(style);

  function currentUserRole() {
    const text = document.querySelector("#role-chip")?.textContent || "";
    return text.trim().toLowerCase();
  }

  async function request(url) {
    const response = await fetch(url, { credentials: "same-origin" });
    const body = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(body.error || "Unable to load analytics.");
    return body;
  }

  function number(value) {
    return new Intl.NumberFormat().format(Number(value) || 0);
  }

  function renderZones(zones) {
    const target = document.querySelector("#zone-chart");
    if (!target) return;
    if (!zones.length) {
      target.textContent = "No zone data available.";
      return;
    }
    target.innerHTML = zones.map(zone => {
      const value = Math.max(0, Math.min(100, Number(zone.utilizationPercent) || 0));
      return `<div class="zone-row"><strong>${escapeHtml(zone.zone)}</strong><div class="zone-bar"><span style="width:${value}%"></span></div><span>${value}%</span></div>`;
    }).join("");
  }

  function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, character => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
    }[character]));
  }

  async function refresh() {
    if (!["police", "admin"].includes(currentUserRole())) return;
    try {
      const data = await request("/api/v2/analytics/overview");
      const summary = data.summary || {};
      document.querySelector("#metric-utilization").textContent = `${data.utilizationPercent || 0}%`;
      document.querySelector("#utilization-meter").style.width = `${Math.max(0, Math.min(100, data.utilizationPercent || 0))}%`;
      document.querySelector("#metric-available").textContent = number(summary.available);
      document.querySelector("#metric-stale").textContent = number((data.staleSlots || []).length);
      document.querySelector("#metric-reservations").textContent = number(data.activeReservations);
      renderZones(data.zoneUtilization || []);
    } catch (error) {
      const target = document.querySelector("#zone-chart");
      if (target) target.textContent = error.message;
    }
  }

  function mount() {
    if (!document.querySelector("#app-view") || document.querySelector("#advanced-analytics")) return;
    const dashboard = document.querySelector("#dashboard-page");
    if (!dashboard) return;
    dashboard.appendChild(root);
    document.querySelector("#analytics-refresh").addEventListener("click", refresh);
    refresh();
  }

  document.addEventListener("DOMContentLoaded", mount);
  const observer = new MutationObserver(mount);
  observer.observe(document.documentElement, { childList: true, subtree: true });
})();
