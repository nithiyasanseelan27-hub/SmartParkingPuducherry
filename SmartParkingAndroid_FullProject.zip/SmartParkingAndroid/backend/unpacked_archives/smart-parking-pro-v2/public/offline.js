"use strict";

(function () {
  const queueKey = "smartParkingDraftQueue";
  const banner = document.createElement("div");
  banner.id = "connection-banner";
  banner.className = "connection-banner";
  banner.setAttribute("role", "status");
  banner.setAttribute("aria-live", "polite");

  function queue() {
    try {
      return JSON.parse(localStorage.getItem(queueKey) || "[]");
    } catch {
      return [];
    }
  }

  function save(items) {
    localStorage.setItem(queueKey, JSON.stringify(items.slice(-25)));
  }

  function render() {
    const online = navigator.onLine;
    const count = queue().length;
    banner.textContent = online
      ? (count ? `Online · ${count} saved draft${count === 1 ? "" : "s"} waiting for manual submission` : "Online · connected")
      : "Offline · your new submissions will not be sent until you reconnect";
    banner.dataset.online = String(online);
    banner.dataset.pending = String(count);
  }

  function mount() {
    if (!document.body || document.querySelector("#connection-banner")) return;
    document.body.prepend(banner);
    render();
  }

  function saveDraft(kind, payload) {
    const items = queue();
    items.push({
      id: crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random()}`,
      kind,
      payload,
      createdAt: new Date().toISOString()
    });
    save(items);
    render();
  }

  function getDrafts() {
    return queue();
  }

  function removeDraft(id) {
    save(queue().filter(item => item.id !== id));
    render();
  }

  window.SmartParkingOffline = { saveDraft, getDrafts, removeDraft };
  window.addEventListener("online", render);
  window.addEventListener("offline", render);
  document.addEventListener("DOMContentLoaded", mount);
  const style = document.createElement("style");
  style.textContent = `.connection-banner{padding:6px 16px;text-align:center;font-size:11px;background:#e6efff;color:#1f438d}.connection-banner[data-online=false]{background:#fff0d9;color:#8c4b00}.connection-banner[data-pending]:not([data-pending="0"]){font-weight:700}`;
  document.head.appendChild(style);
})();
