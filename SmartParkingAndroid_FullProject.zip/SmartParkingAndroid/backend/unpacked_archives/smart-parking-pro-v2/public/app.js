const $ = (s) => document.querySelector(s);
let user = null, csrf = "", slots = [];
const toolNames = {
  occupancy_forecast: "Occupancy snapshot",
  parking_recommendation: "Find a parking bay",
  report_classifier: "Report category helper",
  violation_triage: "Violation triage",
  demand_forecast: "Zone demand",
  anomaly_detection: "Stale-state alerts",
  route_scoring: "Preference ranking"
};
const statusLabels = {available:"Available",occupied:"Occupied",reserved:"Reserved",maintenance:"Maintenance"};
const esc = (v) => String(v ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const formData = (form) => Object.fromEntries(new FormData(form).entries());

async function api(url, opts = {}) {
  const method = (opts.method || "GET").toUpperCase();
  const headers = {"Content-Type":"application/json", ...(opts.headers || {})};
  if (!["GET","HEAD","OPTIONS"].includes(method) && csrf) headers["x-csrf-token"] = csrf;
  const response = await fetch(url, {...opts, headers, credentials:"same-origin"});
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || `Request failed (${response.status})`);
  return data;
}
function toast(message, type="info") {
  const el = $("#toast");
  el.textContent = message;
  el.dataset.type = type;
  el.classList.remove("hidden");
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => el.classList.add("hidden"), 3500);
}
function setMessage(selector, message) { const el=$(selector); if(el) el.textContent=message; }
function showTab(tab) {
  document.querySelectorAll(".tab").forEach(x=>x.classList.toggle("active",x.dataset.tab===tab));
  $("#login-form").classList.toggle("hidden",tab!=="login");
  $("#register-form").classList.toggle("hidden",tab!=="register");
  setMessage("#auth-message","");
}
document.querySelectorAll(".tab").forEach(b=>b.addEventListener("click",()=>showTab(b.dataset.tab)));
$("#login-open").addEventListener("click",()=>$("#auth-view").scrollIntoView({behavior:"smooth"}));

$("#login-form").addEventListener("submit", async e=>{
  e.preventDefault();
  const button=e.submitter; if(button) button.disabled=true;
  try {
    const data=await api("/api/auth/login",{method:"POST",body:JSON.stringify(formData(e.target))});
    user=data.user; csrf=data.csrf; await boot();
  } catch(err) { setMessage("#auth-message",err.message); }
  finally { if(button) button.disabled=false; }
});
$("#register-form").addEventListener("submit",async e=>{
  e.preventDefault();
  const data=formData(e.target);
  if(data.password.length<10){toast("Use a password with at least 10 characters.","error");return;}
  try { const result=await api("/api/auth/register",{method:"POST",body:JSON.stringify(data)});toast(result.message,"success");e.target.reset();showTab("login"); }
  catch(err){toast(err.message,"error");}
});

async function boot() {
  if(!user) {
    try { const d=await api("/api/auth/me");user=d.user;csrf=d.csrf; }
    catch { return; }
  }
  $("#auth-view").classList.add("hidden");
  $("#app-view").classList.remove("hidden");
  $("#session-area").innerHTML=`<span class="session-user">${esc(user.name)}</span><button class="btn secondary" id="logout">Sign out</button>`;
  $("#logout").onclick=logout;
  $("#role-chip").textContent=user.role.toUpperCase();
  $("#welcome-copy").textContent=`Welcome, ${user.name}. Your ${user.role} workspace is ready.`;
  buildNav();
  await loadSlots();
  await loadDashboard();
  if(user.role==="citizen") await loadPersonal();
  if(user.role!=="citizen") await loadPolice();
  if(user.role==="admin") await loadAudit();
}
async function logout() {
  try { await api("/api/auth/logout",{method:"POST",body:"{}"}); } catch {}
  user=null;csrf="";
  $("#app-view").classList.add("hidden");$("#auth-view").classList.remove("hidden");
  $("#session-area").innerHTML='<button class="btn secondary" id="login-open">Sign in</button>';
  $("#login-open").onclick=()=>$("#auth-view").scrollIntoView({behavior:"smooth"});
  toast("You have signed out.");
}
function buildNav() {
  const pages=[["dashboard","Dashboard"],...(user.role==="citizen"?[["citizen","Citizen portal"]]:[["police","Police portal"]]),...(user.role==="admin"?[["admin","Admin & audit"]]:[])];
  $("#nav").innerHTML=pages.map(([id,label],i)=>`<button data-page="${id}" class="${i===0?"active":""}">${label}</button>`).join("");
  document.querySelectorAll("[data-page]").forEach(button=>button.onclick=()=>{
    document.querySelectorAll("[data-page]").forEach(x=>x.classList.toggle("active",x===button));
    document.querySelectorAll(".page").forEach(x=>x.classList.add("hidden"));
    $("#"+button.dataset.page+"-page").classList.remove("hidden");
    $("#page-title").textContent=button.textContent;
  });
}
async function loadSlots() {
  const data=await api("/api/slots");slots=data.slots;
  const zones=[...new Set(slots.map(s=>s.zone))].sort();
  const zoneSelect=$("#zone-filter"), oldZone=zoneSelect.value;
  zoneSelect.innerHTML='<option value="">All zones</option>'+zones.map(z=>`<option value="${esc(z)}">${esc(z)}</option>`).join("");
  if(zones.includes(oldZone))zoneSelect.value=oldZone;
  for(const id of ["reserve-slot","report-slot","status-slot","violation-slot"]) {
    const select=$("#"+id);if(!select)continue;
    const old=select.value, blank=id!=="reserve-slot";
    const options=slots.filter(s=>id!=="reserve-slot"||s.status==="available");
    select.innerHTML=(blank?'<option value="">Not specified</option>':"")+options.map(s=>`<option value="${s.id}">${esc(s.label)} — ${esc(s.zone)} (${esc(statusLabels[s.status])})</option>`).join("");
    if([...select.options].some(o=>o.value===old))select.value=old;
  }
  renderSlots();
}
function renderSlots() {
  const zone=$("#zone-filter").value,status=$("#status-filter").value;
  const query=$("#slot-search").value.trim().toLowerCase();
  const accessible=$("#accessible-filter").checked,ev=$("#ev-filter").checked;
  const list=slots.filter(s=>(!zone||s.zone===zone)&&(!status||s.status===status)&&(!query||`${s.label} ${s.zone}`.toLowerCase().includes(query))&&(!accessible||s.accessible)&&(!ev||s.ev_charging));
  const available=slots.filter(s=>s.status==="available").length;
  $("#availability-strip").innerHTML=`<span><i class="dot green"></i><b>${available}</b> available</span><span><i class="dot orange"></i><b>${slots.filter(s=>s.status==="occupied").length}</b> occupied</span><span><i class="dot gold"></i><b>${slots.filter(s=>s.status==="reserved").length}</b> reserved</span>`;
  $("#slots").innerHTML=list.map(s=>`<article class="slot"><div class="slot-top"><span>${esc(s.label)}</span><span class="status ${esc(s.status)}">${esc(statusLabels[s.status]||s.status)}</span></div><div class="slot-zone">${esc(s.zone)}</div><div class="slot-meta"><span>₹${Number(s.hourly_rate).toFixed(0)}/hour</span>${s.accessible?'<span>♿ Accessible</span>':""}${s.ev_charging?'<span>⚡ EV charging</span>':""}</div>${s.status==="available"&&user.role==="citizen"?`<button class="btn small book-quick" data-book="${s.id}">Choose this bay</button>`:""}</article>`).join("")||'<p class="muted empty-state">No bays match your filters. Try clearing one or more filters.</p>';
  $("#slot-count").textContent=`Showing ${list.length} of ${slots.length} bays`;
  document.querySelectorAll("[data-book]").forEach(b=>b.onclick=()=>{ $("#reserve-slot").value=b.dataset.book;$("#citizen-page").classList.remove("hidden");document.querySelector('[data-page="citizen"]')?.click();$("#reserve-form").scrollIntoView({behavior:"smooth",block:"center"});});
}
["#zone-filter","#status-filter","#slot-search","#accessible-filter","#ev-filter"].forEach(s=>$(s).addEventListener(s==="#slot-search"?"input":"change",renderSlots));
$("#refresh-slots").onclick=async()=>{try{await loadSlots();await loadDashboard();toast("Parking availability refreshed.","success");}catch(e){toast(e.message,"error");}};

async function loadDashboard() {
  const summary=await api("/api/summary");
  let counts={totalSlots:summary.total,available:summary.available,occupied:slots.filter(s=>s.status==="occupied").length,activeReservations:0,openViolations:0,openReports:0};
  try { if(user.role!=="citizen")counts=(await api("/api/dashboard")).counts; } catch {}
  const stats=[["Total bays",counts.totalSlots,"Inventory"],["Available",counts.available,"Ready to use"],["Occupied",counts.occupied,"Currently in use"]];
  if(user.role!=="citizen")stats.push(["Active reservations",counts.activeReservations,"Bookings"],["Open reports",counts.openReports,"Awaiting review"],["Open violations",counts.openViolations,"Human review"]);
  $("#stats").innerHTML=stats.map(([label,value,sub])=>`<div class="stat"><span>${esc(label)}</span><strong>${value??0}</strong><small>${esc(sub)}</small></div>`).join("");
  $("#ai-buttons").innerHTML=Object.entries(toolNames).filter(([key])=>key!=="violation_triage"||user.role!=="citizen").map(([key,label])=>`<button data-ai="${key}"><span>${esc(label)}</span><span class="ai-arrow">↗</span></button>`).join("");
  document.querySelectorAll("[data-ai]").forEach(b=>b.onclick=()=>runAI(b.dataset.ai));
}
async function runAI(tool) {
  try {
    let body={};
    if(tool==="parking_recommendation"||tool==="route_scoring"){body.zone=$("#zone-filter").value;body.accessible=$("#accessible-filter").checked;body.evCharging=$("#ev-filter").checked;}
    if(tool==="report_classifier"){body.text=prompt("Enter a short parking report description for a suggested category:")||"";if(!body.text.trim())return;}
    $("#ai-output").textContent="Analysing current project data…";
    const result=await api("/api/ai/"+tool,{method:"POST",body:JSON.stringify(body)});
    $("#ai-output").textContent=JSON.stringify(result,null,2);
  } catch(e) { $("#ai-output").textContent=e.message; }
}
async function loadPersonal() {
  const [r,p]=await Promise.all([api("/api/reservations"),api("/api/reports")]);
  $("#my-reservations").innerHTML=r.reservations.length?`<table><thead><tr><th>Bay</th><th>Zone</th><th>Time window</th><th>Status</th><th>Action</th></tr></thead><tbody>${r.reservations.map(v=>`<tr><td>${esc(v.label)}</td><td>${esc(v.zone)}</td><td>${esc(formatDate(v.starts_at))}<br>to ${esc(formatDate(v.ends_at))}</td><td><span class="status ${esc(v.status)}">${esc(v.status)}</span></td><td>${v.status==="active"?`<button class="btn small secondary" data-cancel="${v.id}">Cancel</button>`:"—"}</td></tr>`).join("")}</tbody></table>`:'<p class="muted">No reservations yet. Choose an available bay above.</p>';
  $("#my-reports").innerHTML=table(p.reports,["id","category","description","status","created_at"],"No reports submitted yet.");
  document.querySelectorAll("[data-cancel]").forEach(b=>b.onclick=async()=>{if(!confirm("Cancel this reservation?"))return;try{await api("/api/reservations/"+b.dataset.cancel+"/cancel",{method:"POST",body:"{}"});await loadPersonal();await loadDashboard();toast("Reservation cancelled.","success");}catch(e){toast(e.message,"error");}});
}
function formatDate(value){if(!value)return "—";const d=new Date(value);return Number.isNaN(d.getTime())?value:d.toLocaleString();}
function table(rows,cols,empty){if(!rows?.length)return `<p class="muted">${empty}</p>`;return `<table><thead><tr>${cols.map(c=>`<th>${esc(c.replaceAll("_"," "))}</th>`).join("")}</tr></thead><tbody>${rows.map(r=>`<tr>${cols.map(c=>`<td>${esc(c.endsWith("_at")?formatDate(r[c]):r[c])}</td>`).join("")}</tr>`).join("")}</tbody></table>`;}
$("#reserve-form").addEventListener("submit",async e=>{
  e.preventDefault();
  try{const d=formData(e.target);d.startsAt=new Date(d.startsAt).toISOString();d.endsAt=new Date(d.endsAt).toISOString();const result=await api("/api/reservations",{method:"POST",body:JSON.stringify(d)});setMessage("#reserve-msg",result.message);await loadSlots();await loadPersonal();await loadDashboard();toast(result.message,"success");}
  catch(err){setMessage("#reserve-msg",err.message);}
});
$("#report-form").addEventListener("submit",async e=>{
  e.preventDefault();try{const d=formData(e.target);if(!d.slotId)delete d.slotId;const result=await api("/api/reports",{method:"POST",body:JSON.stringify(d)});setMessage("#report-msg",result.message);e.target.reset();await loadPersonal();await loadDashboard();toast(result.message,"success");}catch(err){setMessage("#report-msg",err.message);}
});
async function loadPolice() {
  const [reports,reservations,violations]=await Promise.all([api("/api/reports"),api("/api/reservations"),api("/api/violations")]);
  $("#all-reports").innerHTML=reports.reports.length?`<table><thead><tr><th>ID</th><th>Citizen</th><th>Category</th><th>Description</th><th>Status</th><th>Review</th></tr></thead><tbody>${reports.reports.map(r=>`<tr><td>${r.id}</td><td>${esc(r.citizen_name)}</td><td>${esc(r.category)}</td><td>${esc(r.description)}</td><td><span class="status ${esc(r.status)}">${esc(r.status)}</span></td><td><select data-report="${r.id}"><option value="reviewing">Reviewing</option><option value="resolved">Resolved</option><option value="rejected">Rejected</option></select><button class="btn small" data-save-report="${r.id}">Save</button></td></tr>`).join("")}</tbody></table>`:"<p class=muted>No citizen reports yet.</p>";
  $("#all-violations").innerHTML=violations.violations.length?`<table><thead><tr><th>ID</th><th>Category</th><th>Description</th><th>Status</th><th>Review</th></tr></thead><tbody>${violations.violations.map(v=>`<tr><td>${v.id}</td><td>${esc(v.category)}</td><td>${esc(v.description)}</td><td><span class="status ${esc(v.status)}">${esc(v.status)}</span></td><td><select data-violation="${v.id}"><option value="reviewing">Reviewing</option><option value="resolved">Resolved</option><option value="dismissed">Dismissed</option></select><button class="btn small" data-save-violation="${v.id}">Save</button></td></tr>`).join("")}</tbody></table>`:"<p class=muted>No violations submitted.</p>";
  $("#all-reservations").innerHTML=table(reservations.reservations,["id","citizen_name","label","zone","starts_at","ends_at","status"],"No reservations.");
  document.querySelectorAll("[data-save-report]").forEach(b=>b.onclick=async()=>{try{await api("/api/reports/"+b.dataset.saveReport,{method:"PATCH",body:JSON.stringify({status:$(`[data-report="${b.dataset.saveReport}"]`).value})});await loadPolice();await loadDashboard();toast("Report status updated.","success");}catch(e){toast(e.message,"error");}});
  document.querySelectorAll("[data-save-violation]").forEach(b=>b.onclick=async()=>{try{await api("/api/violations/"+b.dataset.saveViolation,{method:"PATCH",body:JSON.stringify({status:$(`[data-violation="${b.dataset.saveViolation}"]`).value})});await loadPolice();await loadDashboard();toast("Violation status updated.","success");}catch(e){toast(e.message,"error");}});
}
$("#slot-status-form").addEventListener("submit",async e=>{e.preventDefault();try{const d=formData(e.target);await api("/api/slots/"+d.slotId+"/status",{method:"POST",body:JSON.stringify({status:d.status})});setMessage("#status-msg","Parking bay status updated.");await loadSlots();await loadDashboard();toast("Bay status updated.","success");}catch(err){setMessage("#status-msg",err.message);}});
$("#violation-form").addEventListener("submit",async e=>{e.preventDefault();try{const d=formData(e.target);if(!d.slotId)delete d.slotId;const result=await api("/api/violations",{method:"POST",body:JSON.stringify(d)});setMessage("#violation-msg",result.message);e.target.reset();await loadPolice();await loadDashboard();toast(result.message,"success");}catch(err){setMessage("#violation-msg",err.message);}});
$("#load-reports").onclick=()=>loadPolice().catch(e=>toast(e.message,"error"));
$("#load-violations").onclick=()=>loadPolice().catch(e=>toast(e.message,"error"));
async function loadAudit(){try{const data=await api("/api/audit");$("#audit-log").innerHTML=table(data.events,["id","actor","action","entity_type","entity_id","created_at"],"No audit events yet.");}catch(e){toast(e.message,"error");}}
boot().catch(e=>toast(e.message,"error"));
