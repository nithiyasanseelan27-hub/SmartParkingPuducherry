"use strict";

(function () {
  const storageKey = "smartParkingAccessibility";
  const defaults = { theme: "system", largeText: false, compactMode: false, reducedMotion: false };
  const readSettings = () => {
    try {
      return { ...defaults, ...JSON.parse(localStorage.getItem(storageKey) || "{}") };
    } catch {
      return { ...defaults };
    }
  };
  let settings = readSettings();

  function apply() {
    document.documentElement.dataset.theme = settings.theme;
    document.documentElement.classList.toggle("large-text", settings.largeText);
    document.documentElement.classList.toggle("compact-mode", settings.compactMode);
    document.documentElement.classList.toggle("reduced-motion", settings.reducedMotion);
  }

  function save() {
    localStorage.setItem(storageKey, JSON.stringify(settings));
    apply();
  }

  function createControl() {
    if (document.querySelector("#accessibility-controls")) return;
    const header = document.querySelector(".topbar");
    if (!header) return;
    const button = document.createElement("button");
    button.className = "btn secondary";
    button.id = "accessibility-open";
    button.textContent = "Display";
    button.setAttribute("aria-haspopup", "dialog");
    header.appendChild(button);

    const dialog = document.createElement("dialog");
    dialog.id = "accessibility-controls";
    dialog.innerHTML = `
      <form method="dialog" class="accessibility-form">
        <div class="panel-head"><h2>Display preferences</h2><button class="btn small secondary" value="close" aria-label="Close preferences">Close</button></div>
        <label>Theme<select id="display-theme"><option value="system">System</option><option value="light">Light</option><option value="dark">Dark</option></select></label>
        <label class="preference-row"><span>Large text</span><input id="display-large-text" type="checkbox"></label>
        <label class="preference-row"><span>Compact layout</span><input id="display-compact" type="checkbox"></label>
        <label class="preference-row"><span>Reduce motion</span><input id="display-motion" type="checkbox"></label>
        <button id="display-save" class="btn" value="save">Save preferences</button>
        <p class="muted">These preferences are stored in this browser. They do not change account permissions.</p>
      </form>
    `;
    document.body.appendChild(dialog);
    button.addEventListener("click", () => {
      syncForm();
      dialog.showModal();
    });
    document.querySelector("#display-save").addEventListener("click", event => {
      event.preventDefault();
      settings = {
        theme: document.querySelector("#display-theme").value,
        largeText: document.querySelector("#display-large-text").checked,
        compactMode: document.querySelector("#display-compact").checked,
        reducedMotion: document.querySelector("#display-motion").checked
      };
      save();
      dialog.close();
    });
    syncForm();
  }

  function syncForm() {
    const theme = document.querySelector("#display-theme");
    if (!theme) return;
    theme.value = settings.theme;
    document.querySelector("#display-large-text").checked = settings.largeText;
    document.querySelector("#display-compact").checked = settings.compactMode;
    document.querySelector("#display-motion").checked = settings.reducedMotion;
  }

  function injectStyles() {
    const style = document.createElement("style");
    style.textContent = `
      .accessibility-form{display:grid;gap:16px;min-width:min(360px,78vw);padding:5px}.accessibility-form label{display:grid;gap:7px;font-size:13px;font-weight:650}.accessibility-form .preference-row{display:flex;justify-content:space-between;align-items:center}.accessibility-form input[type=checkbox]{width:20px;height:20px}.accessibility-form h2{font-size:17px;margin:0}.accessibility-form .panel-head{gap:18px}dialog{border:1px solid var(--line);border-radius:18px;box-shadow:0 20px 80px #07112b50;color:var(--ink)}dialog::backdrop{background:#08112b88}html.large-text body{font-size:18px}html.large-text .muted{font-size:15px}html.compact-mode .panel{padding:12px;margin-bottom:10px}html.compact-mode .stat{padding:10px}html.reduced-motion *,html.reduced-motion *::before,html.reduced-motion *::after{scroll-behavior:auto!important;animation-duration:.01ms!important;transition-duration:.01ms!important}html[data-theme=dark]{--paper:#0d1427;--ink:#e7ecf7;--muted:#a2adc4;--line:#28334b}html[data-theme=dark] body,html[data-theme=dark] .panel,html[data-theme=dark] .stat,html[data-theme=dark] .slot,html[data-theme=dark] .metric-card,html[data-theme=dark] .analytics-chart-wrap{background:#121c33;color:#e7ecf7}html[data-theme=dark] input,html[data-theme=dark] select,html[data-theme=dark] textarea{background:#0d1427;color:#e7ecf7;border-color:#34415c}html[data-theme=dark] .nav button{background:#121c33;color:#dce4f6;border-color:#28334b}html[data-theme=dark] .nav button.active{background:#2b4b9d}html[data-theme=dark] .btn.secondary{background:#263454;color:#e7ecf7}
    `;
    document.head.appendChild(style);
  }

  apply();
  injectStyles();
  document.addEventListener("DOMContentLoaded", createControl);
  const observer = new MutationObserver(createControl);
  observer.observe(document.documentElement, { childList: true, subtree: true });
})();
