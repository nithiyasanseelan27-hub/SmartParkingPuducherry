# Puducherry Smart Parking — Pro v2

This expanded hackathon project adds modular domain rules, validation, analytics, notifications, accessibility settings, CSV exports, health checks, sensor-update structure, expanded APIs and automated tests to the original citizen/police/admin application.

## Start locally

Requirements: Node.js 20+.

```bash
npm install
cp .env.example .env
```

Configure `SESSION_SECRET` with a random secret of at least 32 characters, then run:

```bash
npm start
```

Open `http://localhost:3000`.

Run the unit tests:

```bash
npm test
```

Demo credentials are available in the development seed setup. Remove demo users and disable seeding before deployment.

## Roles

- Citizen: find parking bays, reserve time windows, submit issue reports and review their own records.
- Police: view operational analytics, update parking status, review citizen reports, manage the violation queue and export operational records.
- Admin: police capabilities plus administrative audit history and demo sensor update access.

## Added features in this version

1. Paginated inventory service.
2. Zone-level inventory summaries.
3. Search and multi-filter logic.
4. Accessible bay preference filtering.
5. EV-charging preference filtering.
6. Maximum hourly rate filtering.
7. Preference-based parking recommendations.
8. Status transition rules.
9. Reservation overlap detection helper.
10. Occupancy utilization calculation.
11. Zone utilization rankings.
12. Availability bands.
13. Stale record detection.
14. Report category suggestion.
15. Violation queue priority suggestion.
16. Notification persistence.
17. Unread notification count.
18. Mark one notification as read.
19. Mark all notifications as read.
20. Notification deletion.
21. CSV inventory export.
22. CSV reservation export.
23. CSV report export.
24. CSV formula-injection mitigation.
25. Health endpoint with process information.
26. User display preferences.
27. Dark theme option.
28. Large text preference.
29. Compact layout preference.
30. Reduced motion preference.
31. Offline connection status.
32. Local draft queue helper.
33. Sensor-update endpoint structure.
34. API pagination helpers.
35. Registration validation helpers.
36. Geographic coordinate validation.
37. Money validation.
38. Identifier validation.
39. Description normalization.
40. Audit log helpers.
41. Email redaction utility.
42. Privacy-safe user projection.
43. Search normalization.
44. Search result sorting.
45. Report priority helper.
46. Domain unit tests.
47. Validation unit tests.
48. API reference documentation.
49. Security and privacy model documentation.
50. Expanded responsive analytics panel.

## AI / decision-support tools

The system has seven local tools: occupancy snapshot, parking recommendation, report classification, violation triage, zone demand comparison, stale-record anomaly detection and preference ranking. These are rule-based heuristics rather than trained models. Their output should be checked by a human.

## End-to-end encryption

This version does not provide true end-to-end encryption. The server must read reservation and report data to process it. HTTPS protects data in transit but does not hide server-readable data from the server operator. A design where even the server operator cannot read sensitive report content requires client-side encryption and careful changes to search, moderation, analytics, backup and AI features.

## Team split

- Backend: `server.js`, `src/domain`, `src/services`, `src/routes`.
- Frontend: `public/index.html`, `public/app.js`, `public/styles.css` and the additional browser modules.
- QA: `tests/domain.test.js`, `tests/validation.test.js`.
- Deployment/security: `docs/SECURITY.md`.
- API integration: `docs/API.md`.

The code is a stronger hackathon MVP, not a certified production law-enforcement system. Before a real rollout, conduct a security review, add MFA, use HTTPS and managed secrets, define retention policies, set up backups and monitoring, and independently test authorization.
