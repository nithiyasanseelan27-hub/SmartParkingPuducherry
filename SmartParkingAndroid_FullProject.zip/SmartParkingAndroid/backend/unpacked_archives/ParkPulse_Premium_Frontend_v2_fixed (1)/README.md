# ParkPulse — Smart Parking Frontend

A responsive React + Vite hackathon frontend prototype for a Smart Parking, Traffic Enforcement & Citizen Reporting System.

## Included portals and features

- Command overview dashboard with sample KPIs, occupancy chart, alerts and parking-zone table
- Citizen portal with search, filters, availability estimates, map-style illustration, demo reservations and quick actions
- Police operations portal with a review queue and mark-resolved workflow
- Citizen report form with type, location, description and file-picker UI
- Report tracking table
- Parking-lot search and filters: all, available, EV charging, accessible
- Analytics view with zone utilization bars and demo insights
- Security/privacy architecture checklist
- Role selector for UI preview (not real authentication)
- Toast feedback, empty states, responsive desktop/tablet/mobile layout
- Eight AI demo tools: demand prediction, recommendation, congestion forecast, violation image assistance, occupancy anomaly detection, peak-hour analysis, natural-language Q&A, automatic report summary
- Sample dataset is included in `src/App.jsx`

## Run locally

Install Node.js (LTS), then in this folder:

```bash
npm install
npm run dev
```

Open the local URL Vite prints (usually `http://localhost:5173`).

To verify a production build:

```bash
npm run build
npm run preview
```

## Important: what is and is not implemented

This is a **frontend prototype**, not a complete production backend. All lot statistics, forecasts, and reports are demo data stored in browser memory. A page refresh resets the demo state. No real reservation, police dispatch, fine, notification, payment, or image upload is performed. The role selector changes only the preview label; it does not authenticate or authorize a person.

## Suggested team split

1. **Frontend (you):** React pages, responsive design, forms, UI state, API integration.
2. **Python backend teammate:** REST APIs, database models, validation, audit logs, auth, role-based authorization.
3. **AI teammate:** train/evaluate models and serve them behind authenticated APIs; document confidence and limitations.
4. **Integration teammate:** connect frontend to backend, test workflows, write deployment instructions.

## Suggested API contract for backend integration

- `POST /api/auth/login`
- `GET /api/parking-lots?area=&availableOnly=`
- `GET /api/parking-lots/:id/availability`
- `POST /api/reservations`
- `GET /api/reservations/me`
- `POST /api/reports` (multipart upload only after secure upload handling is implemented)
- `GET /api/reports` (server-side role filtering)
- `PATCH /api/reports/:id/status`
- `GET /api/analytics/occupancy`
- `POST /api/ai/predict-demand`
- `POST /api/ai/recommend-parking`
- `POST /api/ai/congestion-forecast`
- `POST /api/ai/inspect-violation-image`
- `POST /api/ai/detect-anomaly`
- `POST /api/ai/peak-hour-analysis`
- `POST /api/ai/query`
- `POST /api/ai/summarize-report`

Use environment variables (for example `VITE_API_BASE_URL`) for the backend base URL; never place private server secrets in frontend environment variables.

## Security note — end-to-end encryption

Do not claim that the application is end-to-end encrypted yet. This prototype does **not** implement E2EE. HTTPS/TLS protects data in transit but is not the same as E2EE. True E2EE generally means only intended client endpoints hold the decryption keys, which conflicts with a server needing to read plaintext to perform normal analytics or AI inference. Decide which fields must be unreadable to the server, which operational data the police system legitimately needs, and which data can be minimized or separated. Use reviewed cryptographic libraries and get a security review before handling real citizen or law-enforcement data. Never invent your own encryption scheme.

## Before a real deployment

- Add vetted authentication and server-enforced RBAC; hiding a screen is not access control.
- Use HTTPS, secure session/cookie settings, CSRF protection where applicable, input validation and rate limiting.
- Store secrets only on the server; encrypt databases/backups and define key rotation.
- Add authorization checks to every endpoint and keep a tamper-resistant audit trail.
- Add privacy notice, retention/deletion rules, abuse reporting and human review for AI outputs.
- Connect a map provider and real occupancy sensors only after permissions and data quality checks.
- Add unit, integration, accessibility and security tests.


## Premium UI polish
The current stylesheet includes a second visual-polish layer: refined spacing, gradient accents, improved hover/focus states, premium cards, softened shadows, and more consistent mobile styling. The project remains a prototype with sample data; see the security notes above before deployment.
