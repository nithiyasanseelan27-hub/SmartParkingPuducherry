import React, { useMemo, useState } from 'react';
import {
  Activity, AlertTriangle, ArrowDownRight, ArrowUpRight, Bell, BrainCircuit,
  CarFront, CheckCircle2, ChevronDown, CircleHelp, Clock3, Cloud, Compass,
  FileText, Filter, Gauge, Home, MapPin, Menu, MessageSquareWarning, ParkingCircle,
  Search, Shield, ShieldCheck, Sparkles, TrendingUp, Users, Zap, CalendarDays,
  Camera, Navigation, ClipboardList, LockKeyhole, Settings, BarChart3, X,
  CircleParking, BatteryCharging, Accessibility, Send, RefreshCw, LogOut
} from 'lucide-react';

const initialLots = [
  { name: 'Beach Road Central', area: 'White Town', total: 180, occupied: 143, price: '₹30/hr', status: 'Busy', distance: '0.4 km' },
  { name: 'Mission Street Parking', area: 'Heritage Quarter', total: 120, occupied: 67, price: '₹20/hr', status: 'Available', distance: '0.8 km' },
  { name: 'Botanical Garden Lot', area: 'Orleanpet', total: 95, occupied: 81, price: '₹15/hr', status: 'Busy', distance: '1.3 km' },
  { name: 'New Bus Stand Parking', area: 'Mudaliarpet', total: 220, occupied: 104, price: '₹25/hr', status: 'Available', distance: '2.1 km' },
  { name: 'Promenade EV Hub', area: 'Beach Road', total: 64, occupied: 31, price: '₹35/hr', status: 'Available', distance: '0.6 km' },
  { name: 'Hospital Visitor Parking', area: 'Gorimedu', total: 150, occupied: 126, price: '₹10/hr', status: 'Busy', distance: '3.2 km' }
];

const aiTools = [
  { title: 'Parking demand prediction', icon: TrendingUp, tag: 'Forecasting', desc: 'Estimate near-future demand by zone and time.' },
  { title: 'Smart parking recommendation', icon: Compass, tag: 'Citizen support', desc: 'Rank lots by availability, distance and price.' },
  { title: 'Congestion forecasting', icon: Activity, tag: 'Traffic', desc: 'Flag areas likely to become congested.' },
  { title: 'Violation image assistance', icon: Camera, tag: 'Computer vision', desc: 'Demo workflow to assist a trained model reviewing a submitted image.' },
  { title: 'Occupancy anomaly detection', icon: Gauge, tag: 'Anomaly detection', desc: 'Identify unusual occupancy changes for human review.' },
  { title: 'Peak-hour analysis', icon: Clock3, tag: 'Patterns', desc: 'Summarize recurring busy periods.' },
  { title: 'Ask parking data', icon: MessageSquareWarning, tag: 'Natural language', desc: 'Ask questions about the demo parking dataset.' },
  { title: 'Automatic report summary', icon: FileText, tag: 'Reporting', desc: 'Create a concise operational summary.' }
];

const navGroups = [
  { heading: 'WORKSPACE', items: [
    { id: 'dashboard', label: 'Overview', icon: Home },
    { id: 'citizen', label: 'Citizen portal', icon: Users },
    { id: 'police', label: 'Police portal', icon: ShieldCheck },
    { id: 'parking', label: 'Parking lots', icon: CircleParking },
    { id: 'reports', label: 'Citizen reports', icon: ClipboardList }
  ]},
  { heading: 'INTELLIGENCE', items: [
    { id: 'ai', label: 'AI intelligence', icon: BrainCircuit, badge: '8 tools' },
    { id: 'analytics', label: 'Analytics & trends', icon: BarChart3 },
    { id: 'security', label: 'Security & privacy', icon: LockKeyhole }
  ]}
];

function Metric({ icon: Icon, label, value, change, tone = 'blue', foot }) {
  return <div className="metric card">
    <div className={`metric-icon ${tone}`}><Icon size={19}/></div>
    <div className="metric-label">{label}</div>
    <div className="metric-value">{value}</div>
    <div className="metric-bottom"><span className="change"><ArrowUpRight size={14}/>{change}</span><span>{foot}</span></div>
  </div>;
}

function ProgressBar({ value }) {
  return <div className="progress"><span style={{ width: `${Math.min(value, 100)}%` }} /></div>;
}

export default function App() {
  const [page, setPage] = useState('dashboard');
  const [role, setRole] = useState('Police');
  const [query, setQuery] = useState('');
  const [filter, setFilter] = useState('All');
  const [lots, setLots] = useState(initialLots);
  const [selectedTool, setSelectedTool] = useState(null);
  const [aiQuestion, setAiQuestion] = useState('');
  const [aiResult, setAiResult] = useState('');
  const [toast, setToast] = useState('');
  const [reports, setReports] = useState([
    { id: 'PP-2041', type: 'Parking obstruction', location: 'Beach Road, near Lighthouse', time: '10:42 AM', status: 'Under review', priority: 'High' },
    { id: 'PP-2040', type: 'Unauthorized parking', location: 'Mission Street', time: '10:18 AM', status: 'Assigned', priority: 'Medium' },
    { id: 'PP-2039', type: 'Damaged parking sign', location: 'Botanical Garden Road', time: '09:51 AM', status: 'Resolved', priority: 'Low' }
  ]);
  const [reportType, setReportType] = useState('Unauthorized parking');
  const [reportLocation, setReportLocation] = useState('');
  const [reportDetails, setReportDetails] = useState('');
  const [searchTerm, setSearchTerm] = useState('');

  const visibleLots = useMemo(() => lots.filter(l => {
    const match = `${l.name} ${l.area}`.toLowerCase().includes(query.toLowerCase());
    const availability = l.total - l.occupied;
    const matchFilter = filter === 'All' || (filter === 'Available' && availability > 20) || (filter === 'EV charging' && l.name.includes('EV')) || (filter === 'Accessible' && ['Beach Road Central', 'New Bus Stand Parking'].includes(l.name));
    return match && matchFilter;
  }), [lots, query, filter]);

  const notify = (message) => {
    setToast(message);
    window.setTimeout(() => setToast(''), 3000);
  };

  const runTool = (tool) => {
    setSelectedTool(tool);
    const output = {
      'Parking demand prediction': 'DEMO FORECAST: Beach Road Central may reach 90% occupancy around 5:00–6:00 PM. Consider directing arrivals to Mission Street Parking. This is illustrative output, not a trained prediction.',
      'Smart parking recommendation': 'TOP DEMO MATCH: Mission Street Parking — 53 spaces estimated available, ₹20/hr, 0.8 km away. Promenade EV Hub is a better fit when EV charging is required.',
      'Congestion forecasting': 'DEMO ALERT: Beach Road and the Lighthouse approach are marked as potential peak-hour congestion zones. Validate with live traffic feeds before dispatch decisions.',
      'Violation image assistance': 'IMAGE REVIEW WORKFLOW: Uploads should be checked by an authorized reviewer. A production computer-vision model may flag possible parking violations, but must not issue penalties without human verification.',
      'Occupancy anomaly detection': 'DEMO SIGNAL: Hospital Visitor Parking is at 84% occupancy. Compare entry/exit sensor counts and camera observations before treating this as an anomaly.',
      'Peak-hour analysis': 'DEMO INSIGHT: Demand is modeled as highest from 4:30–7:00 PM near the waterfront. Use actual historical occupancy data to train a reliable time-of-day model.',
      'Ask parking data': 'Try asking: “Which lot has the most spaces?” or “Show lots with EV charging.” The demo assistant can answer from the sample dataset only.',
      'Automatic report summary': 'OPERATIONS SUMMARY: 6 sample lots are monitored. 3 citizen reports are open or recently resolved. Review high-priority obstruction reports and validate peak-hour occupancy.'
    };
    setAiResult(output[tool.title] || 'Demo tool ready.');
  };

  const submitReport = (e) => {
    e.preventDefault();
    if (!reportLocation.trim()) { notify('Enter a location before submitting.'); return; }
    const newReport = { id: `PP-${Date.now()}`, type: reportType, location: reportLocation.trim(), details: reportDetails.trim(), time: 'Just now', status: 'Submitted', priority: reportType === 'Parking obstruction' || reportType === 'Blocked accessible space' ? 'High' : 'Medium' };
    setReports(previousReports => [newReport, ...previousReports]);
    setReportLocation(''); setReportDetails('');
    notify('Demo report submitted successfully.');
    setPage('reports');
  };

  const pageTitle = {
    dashboard: 'Command overview', citizen: 'Citizen parking portal', police: 'Police operations portal',
    parking: 'Parking lots', reports: 'Citizen reports', ai: 'AI intelligence centre',
    analytics: 'Analytics & trends', security: 'Security & privacy'
  }[page];

  const nav = (id) => { setPage(id); setSelectedTool(null); };
  const runQuestion = () => {
    if (!aiQuestion.trim()) return;
    const q = aiQuestion.toLowerCase();
    if (q.includes('most') || q.includes('space') || q.includes('available')) {
      const best = [...lots].sort((a,b) => (b.total-b.occupied) - (a.total-a.occupied))[0];
      setAiResult(`${best.name} currently has the most estimated spaces available in this demo: ${best.total-best.occupied} of ${best.total}. Data is sample data.`);
    } else if (q.includes('ev')) {
      setAiResult('Promenade EV Hub is the EV-focused sample lot. It lists ₹35/hr and 33 estimated spaces available. Verify charger status with live hardware in production.');
    } else {
      setAiResult('I can answer basic questions from the sample dataset. Try “Which lot has the most spaces?” or “Show EV parking”. For real answers, connect a secured backend and a grounded AI service.');
    }
    setSelectedTool(aiTools[6]);
  };

  return <div className="app-shell">
    <aside className="sidebar">
      <div className="brand"><div className="brand-mark"><ParkingCircle size={25}/></div><div><b>ParkPulse</b><small>SMART CITY INTELLIGENCE</small></div></div>
      <div className="workspace"><div className="workspace-dot"/>Puducherry operations <ChevronDown size={14}/></div>
      {navGroups.map(group => <div className="nav-group" key={group.heading}>
        <div className="nav-heading">{group.heading}</div>
        {group.items.map(item => <button key={item.id} onClick={() => nav(item.id)} className={`nav-item ${page === item.id ? 'active' : ''}`}>
          <item.icon size={18}/><span>{item.label}</span>{item.badge && <em>{item.badge}</em>}
        </button>)}
      </div>)}
      <div className="sidebar-bottom">
        <div className="help-card"><div className="help-icon"><CircleHelp size={18}/></div><b>Need a hand?</b><p>Explore the demo or connect your team’s API.</p><button onClick={() => notify('Demo help: check README.md for setup and integration notes.')}>Open help <ArrowUpRight size={14}/></button></div>
        <div className="profile"><div className="avatar">PP</div><div className="profile-text"><b>Project workspace</b><small>Hackathon demo</small></div><Settings size={17}/></div>
      </div>
    </aside>

    <main className="main">
      <header className="topbar">
        <div className="crumb"><span>Workspace</span><span className="slash">/</span><b>{pageTitle}</b></div>
        <div className="top-actions">
          <div className="secure-label"><span/> Demo environment</div>
          <button className="icon-btn" aria-label="Notifications" onClick={() => notify('You are all caught up in this demo.')}><Bell size={18}/><i/></button>
          <div className="role-select"><Shield size={15}/><select value={role} onChange={e => setRole(e.target.value)} aria-label="Preview role"><option>Police</option><option>Citizen</option><option>Admin</option></select></div>
        </div>
      </header>

      <div className="page-content">
        <div className="page-head">
          <div><div className="eyebrow"><span className="eyebrow-dot"/> PUDUCHERRY • SMART PARKING</div><h1>{pageTitle}</h1><p className="subhead">{page === 'dashboard' ? 'A clearer view of parking availability, citizen reports and street-level activity.' : page === 'citizen' ? 'Find a space, plan your trip and report a parking issue.' : page === 'police' ? 'Review operational signals and coordinate parking enforcement.' : 'Explore the connected smart parking workflow.'}</p></div>
          <div className="head-actions"><button className="btn secondary" onClick={() => notify('Sample dashboard refreshed.')}><RefreshCw size={15}/> Refresh</button><button className="btn primary" onClick={() => page === 'citizen' ? setPage('reports') : notify('Demo export prepared. Connect a backend to export verified data.')}><FileText size={15}/>{page === 'citizen' ? 'My reports' : 'Export report'}</button></div>
        </div>

        {page === 'dashboard' && <>
          <div className="metric-grid">
            <Metric icon={CircleParking} label="Total parking spaces" value="829" change="+4.8%" foot="vs. last week" tone="blue"/>
            <Metric icon={CheckCircle2} label="Spaces available" value="353" change="+12.2%" foot="sample estimate" tone="green"/>
            <Metric icon={CarFront} label="Occupancy rate" value="57.4%" change="−3.1%" foot="vs. yesterday" tone="violet"/>
            <Metric icon={AlertTriangle} label="Reports to review" value={reports.filter(r=>r.status!=='Resolved').length.toString().padStart(2,'0')} change="+2 today" foot="needs attention" tone="orange"/>
          </div>
          <div className="dashboard-grid">
            <section className="card occupancy-card">
              <div className="section-head"><div><h2>Parking occupancy</h2><p>Sample occupancy trend throughout the day</p></div><button className="select-like" onClick={() => notify('Showing the last 24 hours of sample data.')}>Last 24 hours <ChevronDown size={14}/></button></div>
              <div className="chart-legend"><span><i className="legend-blue"/> Occupied</span><span><i className="legend-mint"/> Available</span></div>
              <div className="chart">
                <div className="y-labels"><span>100%</span><span>75%</span><span>50%</span><span>25%</span><span>0%</span></div>
                <div className="chart-area">
                  {[100,75,50,25,0].map(n=><div key={n} className="gridline"><span>{n===100?'': ''}</span></div>)}
                  <svg viewBox="0 0 650 220" preserveAspectRatio="none" role="img" aria-label="Illustrative occupancy line chart">
                    <defs><linearGradient id="areaFill" x1="0" x2="0" y1="0" y2="1"><stop offset="0%" stopColor="#4f7cff" stopOpacity=".24"/><stop offset="100%" stopColor="#4f7cff" stopOpacity="0"/></linearGradient></defs>
                    <path d="M0,156 C40,150 55,125 90,132 S145,164 185,116 S240,90 278,105 S330,135 372,83 S425,70 465,90 S530,46 570,66 S620,42 650,30 L650,220 L0,220 Z" fill="url(#areaFill)"/>
                    <path d="M0,156 C40,150 55,125 90,132 S145,164 185,116 S240,90 278,105 S330,135 372,83 S425,70 465,90 S530,46 570,66 S620,42 650,30" fill="none" stroke="#5b7cfa" strokeWidth="3" vectorEffect="non-scaling-stroke"/>
                    <path d="M0,188 C50,180 65,190 100,178 S160,194 200,175 S250,188 300,171 S365,187 410,160 S470,180 520,152 S600,163 650,143" fill="none" stroke="#49c6a5" strokeWidth="2.5" strokeDasharray="5 5" vectorEffect="non-scaling-stroke"/>
                  </svg>
                  <div className="x-labels"><span>6 AM</span><span>9 AM</span><span>12 PM</span><span>3 PM</span><span>6 PM</span><span>9 PM</span></div>
                </div>
              </div>
              <div className="chart-foot"><span><span className="status-dot green-dot"/> Occupancy data is illustrative</span><span>Updated just now</span></div>
            </section>
            <section className="card alerts-card">
              <div className="section-head"><div><h2>Priority alerts</h2><p>Items requiring review</p></div><button className="text-button" onClick={() => nav('reports')}>View all <ArrowUpRight size={14}/></button></div>
              {[
                {icon: AlertTriangle, tone:'alert-red', title:'Parking obstruction reported', place:'Beach Road • 10:42 AM', level:'High'},
                {icon: Activity, tone:'alert-yellow', title:'High occupancy detected', place:'Hospital Visitor Parking', level:'Medium'},
                {icon: ShieldCheck, tone:'alert-blue', title:'Report assigned for review', place:'Mission Street • 10:18 AM', level:'Info'}
              ].map((a,i)=><div className="alert-row" key={i}><div className={`alert-icon ${a.tone}`}><a.icon size={17}/></div><div className="alert-copy"><b>{a.title}</b><small>{a.place}</small></div><span className={`pill ${a.level.toLowerCase()}`}>{a.level}</span></div>)}
              <button className="wide-link" onClick={() => nav('police')}>Open enforcement queue <ArrowUpRight size={15}/></button>
            </section>
          </div>
          <section className="card lots-card">
            <div className="section-head"><div><h2>Parking zones</h2><p>Availability across monitored demo lots</p></div><button className="text-button" onClick={() => nav('parking')}>View all lots <ArrowUpRight size={14}/></button></div>
            <LotsTable lots={lots.slice(0,4)} onSelect={name=>notify(`${name}: demo lot details opened.`)}/>
          </section>
          <div className="bottom-grid">
            <section className="card ai-banner"><div className="ai-orb"><BrainCircuit size={24}/></div><div className="ai-banner-copy"><span className="mini-label">AI INTELLIGENCE</span><h2>Turn parking data into action.</h2><p>Explore forecasting and decision-support tools for your operations team.</p></div><button className="btn primary" onClick={()=>nav('ai')}>Explore AI tools <ArrowUpRight size={15}/></button></section>
            <section className="card mini-security"><div className="security-symbol"><LockKeyhole size={19}/></div><div><b>Privacy-first design</b><p>Role-based access and secure transport are deployment requirements, not enabled security guarantees in this demo.</p><button className="text-button" onClick={()=>nav('security')}>Review security <ArrowUpRight size={14}/></button></div></section>
          </div>
        </>}

        {page === 'parking' && <section className="card lots-card">
          <div className="section-head wrap-head"><div><h2>All parking lots</h2><p>Search and filter sample parking locations</p></div><div className="filters"><div className="searchbox"><Search size={16}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search lot or area..."/></div><select value={filter} onChange={e=>setFilter(e.target.value)}><option>All</option><option>Available</option><option>EV charging</option><option>Accessible</option></select></div></div>
          <LotsTable lots={visibleLots} onSelect={name=>notify(`${name}: demo lot details opened.`)}/>
          {!visibleLots.length && <div className="empty-state">No lots match those filters.</div>}
        </section>}

        {page === 'citizen' && <div className="citizen-layout">
          <section className="card citizen-search">
            <div className="citizen-welcome"><div><span className="mini-label">CITIZEN SERVICES</span><h2>Find your next parking spot.</h2><p>Search available spaces around Puducherry. Availability shown here is sample data.</p></div><div className="welcome-icon"><Navigation size={26}/></div></div>
            <div className="searchbox big-search"><Search size={18}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Enter area, landmark or parking lot"/></div>
            <div className="quick-filters">{['All','Available','EV charging','Accessible'].map(f=><button key={f} className={`filter-chip ${filter===f?'selected':''}`} onClick={()=>setFilter(f)}>{f==='EV charging'?<BatteryCharging size={14}/>:f==='Accessible'?<Accessibility size={14}/>:<ParkingCircle size={14}/>} {f}</button>)}</div>
            <div className="citizen-lot-list">{visibleLots.map(l=><div className="citizen-lot" key={l.name}><div className="lot-map-pin"><MapPin size={19}/></div><div className="citizen-lot-info"><b>{l.name}</b><span>{l.area} • {l.distance}</span><small>{l.price} <i>•</i> {l.name.includes('EV')?'EV charging listed':'Standard parking'}</small></div><div className="citizen-lot-right"><b>{l.total-l.occupied}</b><span>spaces free</span><button onClick={()=>notify(`Demo reservation started for ${l.name}. No real booking was made.`)}>Reserve <ArrowUpRight size={13}/></button></div></div>)}</div>
          </section>
          <aside className="card citizen-side"><div className="map-placeholder"><div className="map-road road-one"/><div className="map-road road-two"/><div className="map-road road-three"/><div className="map-water"/><span className="map-label label-one"><MapPin size={14}/> Beach Road</span><span className="map-label label-two"><MapPin size={14}/> Mission St.</span><span className="map-label label-three"><MapPin size={14}/> EV Hub</span><div className="map-caption"><MapPin size={15}/> Puducherry <small>Illustrative map</small></div></div><div className="side-info"><h3>Quick actions</h3><button onClick={()=>nav('reports')}><MessageSquareWarning size={17}/> Report a parking issue <ArrowUpRight size={14}/></button><button onClick={()=>notify('Navigation is a demo. Connect a map provider for live directions.')}><Navigation size={17}/> Get directions <ArrowUpRight size={14}/></button><button onClick={()=>notify('Booking history is not connected in this prototype.')}><CalendarDays size={17}/> My reservations <ArrowUpRight size={14}/></button></div><div className="privacy-note"><ShieldCheck size={17}/><span><b>Your privacy matters</b><small>Only share details needed to handle your report.</small></span></div></aside>
        </div>}

        {page === 'police' && <div className="police-grid">
          <div className="metric-grid compact-metrics"><Metric icon={AlertTriangle} label="Pending review" value={String(reports.filter(r=>r.status!=='Resolved').length).padStart(2,'0')} change="Needs review" foot="sample reports" tone="orange"/><Metric icon={ShieldCheck} label="Resolved reports" value={String(reports.filter(r=>r.status==='Resolved').length).padStart(2,'0')} change="Updated" foot="demo queue" tone="green"/><Metric icon={Activity} label="High occupancy zones" value="03" change="Monitor" foot="sample estimate" tone="violet"/></div>
          <section className="card lots-card"><div className="section-head"><div><h2>Enforcement review queue</h2><p>Human review is required before any enforcement action.</p></div><button className="btn secondary" onClick={()=>nav('reports')}><ClipboardList size={15}/> All reports</button></div><ReportsTable reports={reports} onResolve={id=>{setReports(previousReports=>previousReports.map(r=>r.id===id?{...r,status:'Resolved'}:r));notify(`${id} marked resolved in demo.`)}}/></section>
          <section className="card police-note"><ShieldCheck size={20}/><div><b>Operational safeguard</b><p>AI suggestions are advisory only. Verify evidence, location and applicable rules before taking action. Keep an audit trail for each decision.</p></div></section>
        </div>}

        {page === 'reports' && <div className="reports-layout">
          <section className="card report-form-card"><div className="section-head"><div><h2>Submit a citizen report</h2><p>Provide a location and brief description.</p></div><div className="report-form-icon"><MessageSquareWarning size={20}/></div></div>
            <form onSubmit={submitReport} className="report-form"><label>Issue type<select value={reportType} onChange={e=>setReportType(e.target.value)}><option>Unauthorized parking</option><option>Parking obstruction</option><option>Damaged parking sign</option><option>Blocked accessible space</option><option>Other parking issue</option></select></label><label>Location or landmark<input value={reportLocation} onChange={e=>setReportLocation(e.target.value)} placeholder="e.g. Near Beach Road entrance" required/></label><label>Description<textarea value={reportDetails} onChange={e=>setReportDetails(e.target.value)} placeholder="Describe what you observed (avoid unnecessary personal details)." rows="4"/></label><label className="upload-demo"><Camera size={19}/><span><b>Attach photo (UI demo only)</b><small>Real upload storage and malware checks must be implemented on the backend.</small></span><input type="file" accept="image/*" onChange={()=>notify('File picker selected. Upload is not connected in this prototype.')}/></label><button className="btn primary full-btn" type="submit"><Send size={16}/> Submit report</button><p className="form-disclaimer"><LockKeyhole size={13}/> Demo only — do not submit real personal or sensitive information.</p></form>
          </section>
          <section className="card lots-card report-list-card"><div className="section-head"><div><h2>Report tracking</h2><p>Current sample citizen reports</p></div><span className="pill info">{reports.length} reports</span></div><ReportsTable reports={reports} onResolve={id=>{setReports(previousReports=>previousReports.map(r=>r.id===id?{...r,status:'Resolved'}:r));notify(`${id} marked resolved in demo.`)}}/></section>
        </div>}

        {page === 'ai' && <div className="ai-page">
          <div className="ai-intro card"><div className="ai-intro-icon"><Sparkles size={25}/></div><div><span className="mini-label">DECISION SUPPORT • HUMAN REVIEW REQUIRED</span><h2>Eight tools. One smarter parking workflow.</h2><p>These buttons return transparent demo outputs. Connect approved models and real data before using operationally.</p></div></div>
          <div className="ai-tools-grid">{aiTools.map(tool=><button className={`ai-tool card ${selectedTool?.title===tool.title?'chosen':''}`} key={tool.title} onClick={()=>runTool(tool)}><div className="tool-top"><div className="tool-icon"><tool.icon size={19}/></div><span className="tool-arrow"><ArrowUpRight size={16}/></span></div><span className="tool-tag">{tool.tag}</span><h3>{tool.title}</h3><p>{tool.desc}</p><span className="run-label">Run demo <ArrowUpRight size={13}/></span></button>)}</div>
          <section className="card ai-output"><div className="section-head"><div><h2><Sparkles size={17}/> AI tool output</h2><p>{selectedTool ? selectedTool.title : 'Select a tool above to see its sample response.'}</p></div><span className="pill info">DEMO</span></div>
            {aiResult ? <div className="output-text">{aiResult}</div> : <div className="empty-state">Your selected tool’s output will appear here.</div>}
            <div className="ask-row"><div className="searchbox"><MessageSquareWarning size={16}/><input value={aiQuestion} onChange={e=>setAiQuestion(e.target.value)} onKeyDown={e=>e.key==='Enter'&&runQuestion()} placeholder="Ask: Which lot has the most spaces?"/></div><button className="btn primary" onClick={runQuestion}><Send size={15}/> Ask demo AI</button></div>
          </section>
        </div>}

        {page === 'analytics' && <div className="analytics-grid"><section className="card analytics-card"><div className="section-head"><div><h2>Zone utilization</h2><p>Occupied spaces from sample data</p></div><BarChart3 size={19}/></div>{lots.map(l=><div className="zone-row" key={l.name}><div><b>{l.name}</b><small>{l.area}</small></div><div className="zone-bar"><ProgressBar value={Math.round(l.occupied/l.total*100)}/></div><strong>{Math.round(l.occupied/l.total*100)}%</strong></div>)}</section><section className="card insight-card"><div className="tool-icon"><BrainCircuit size={19}/></div><h2>Demo insights</h2><div className="insight-item"><TrendingUp size={17}/><p><b>Potential peak period</b><span>4:30–7:00 PM near the waterfront (illustrative).</span></p></div><div className="insight-item"><MapPin size={17}/><p><b>Zone to monitor</b><span>Hospital Visitor Parking is modeled at 84% occupancy.</span></p></div><div className="insight-item"><ShieldCheck size={17}/><p><b>Next step</b><span>Replace sample values with validated sensor or operator data.</span></p></div><button className="btn primary" onClick={()=>nav('ai')}>Open AI intelligence <ArrowUpRight size={15}/></button></section></div>}

        {page === 'security' && <div className="security-page"><section className="card security-hero"><div className="security-symbol large"><LockKeyhole size={25}/></div><div><span className="mini-label">SECURITY DESIGN</span><h2>Protect people, not just data.</h2><p>This frontend prototype does not implement production authentication, end-to-end encryption or secure storage. The checklist below is a design plan, not a security certification.</p></div></section><div className="security-checks">{[
          ['HTTPS/TLS', 'Encrypt traffic in transit between app and backend.', 'Required before deployment'],
          ['Role-based access control', 'Enforce citizen, officer and administrator permissions on the server.', 'Backend requirement'],
          ['Client-side encryption', 'Use only for data that must remain unreadable to the server; keep keys on user devices.', 'Architecture decision'],
          ['Data minimization', 'Collect only necessary information and define retention/deletion rules.', 'Privacy requirement'],
          ['Audit trail', 'Record authorized officer actions with tamper-resistant logs and appropriate access.', 'Backend requirement'],
          ['Secure authentication', 'Use vetted identity/session management, rate limiting and account recovery controls.', 'Backend requirement']
        ].map((s,i)=><div className="card security-check" key={s[0]}><div className="check-number">{String(i+1).padStart(2,'0')}</div><div><b>{s[0]}</b><p>{s[1]}</p><small>{s[2]}</small></div></div>)}</div><div className="security-warning"><AlertTriangle size={18}/><p><b>Important:</b> A system cannot simultaneously hide all operational data from the server and let that server freely analyze it. For police workflows, design carefully around data minimization, encryption, least privilege and lawful access. Have a security professional review the architecture before handling real citizen data.</p></div></div>}
      </div>
      <footer className="footer"><span>ParkPulse <i>•</i> Hackathon prototype</span><span><span className="status-dot green-dot"/> Demo data only <i>•</i> Not connected to live police systems</span></footer>
    </main>
    {toast && <div className="toast"><CheckCircle2 size={17}/>{toast}<button onClick={()=>setToast('')} aria-label="Dismiss"><X size={14}/></button></div>}
  </div>;
}

function LotsTable({ lots, onSelect }) {
  return <div className="table-wrap"><table><thead><tr><th>Parking location</th><th>Area</th><th>Availability</th><th>Occupancy</th><th>Rate</th><th>Action</th></tr></thead><tbody>{lots.map(l=>{const free=l.total-l.occupied;const pct=Math.round(l.occupied/l.total*100);return <tr key={l.name}><td><div className="lot-name"><div className="table-lot-icon"><ParkingCircle size={17}/></div><div><b>{l.name}</b><small>{l.distance} away</small></div></div></td><td>{l.area}</td><td><span className={`availability ${free<30?'low':''}`}><span/>{free} spaces</span></td><td><div className="occupancy-cell"><ProgressBar value={pct}/><span>{pct}%</span></div></td><td className="price-cell">{l.price}</td><td><button className="row-action" onClick={()=>onSelect(l.name)}>Details <ArrowUpRight size={13}/></button></td></tr>})}</tbody></table></div>;
}

function ReportsTable({ reports, onResolve }) {
  return <div className="table-wrap"><table><thead><tr><th>Report</th><th>Location</th><th>Submitted</th><th>Priority</th><th>Status</th><th>Action</th></tr></thead><tbody>{reports.map(r=><tr key={r.id}><td><div className="report-name"><b>{r.type}</b><small>{r.id}</small></div></td><td>{r.location}</td><td>{r.time}</td><td><span className={`pill ${r.priority.toLowerCase()}`}>{r.priority}</span></td><td><span className={`status-pill ${r.status==='Resolved'?'done':r.status==='Under review'?'review':'open'}`}><i/>{r.status}</span></td><td><button className="row-action" onClick={()=>onResolve(r.id)} disabled={r.status==='Resolved'}>{r.status==='Resolved'?'Resolved':'Mark resolved'} <CheckCircle2 size={13}/></button></td></tr>)}</tbody></table></div>;
}