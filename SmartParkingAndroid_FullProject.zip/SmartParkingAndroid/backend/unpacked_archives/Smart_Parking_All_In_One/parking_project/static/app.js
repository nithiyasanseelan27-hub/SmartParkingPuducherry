"use strict";
const select = selector => document.querySelector(selector);
let token = sessionStorage.getItem("parking_token") || "";
let profile = null;
const escapeHtml = value => String(value ?? "").replace(/[&<>"']/g, character => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[character]));
const setNotice = (message, error = false) => { const node = select("#notice"); node.textContent = message; node.className = error ? "error" : ""; };
async function api(path, method = "GET", body = undefined) {
    const headers = {"Accept":"application/json"};
    if (token) headers.Authorization = `Bearer ${token}`;
    if (body !== undefined) headers["Content-Type"] = "application/json";
    const response = await fetch(`/api${path}`, {method, headers, body: body === undefined ? undefined : JSON.stringify(body)});
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(payload.detail || `Request failed (${response.status})`);
    return payload;
}
function showSignedIn() {
    select("#auth-card").hidden = Boolean(profile);
    select("#workspace").hidden = !profile;
    select("#session").textContent = profile ? `${profile.name} · ${profile.role}` : "Signed out";
}
async function signIn(email, password) {
    const result = await api("/auth/login", "POST", {email, password});
    token = result.token;
    sessionStorage.setItem("parking_token", token);
    profile = await api("/me");
    showSignedIn();
    await renderView(profile.role === "citizen" ? "lots" : "dashboard");
}
async function renderView(view) {
    if (!profile) return;
    const content = select("#content");
    content.innerHTML = "<div class='card'>Loading…</div>";
    try {
        if (view === "lots") await renderLots(content);
        else if (view === "vehicles") await renderVehicles(content);
        else if (view === "reports") await renderReports(content);
        else if (view === "police") await renderPolice(content);
        else if (view === "dashboard") await renderDashboard(content);
        setNotice("");
    } catch (error) {
        content.innerHTML = "";
        setNotice(error.message, true);
    }
}
async function renderLots(content) {
    const lots = await api("/lots");
    content.innerHTML = `<div class="card"><div class="row"><div><h2>Available parking</h2><p class="muted">Occupancy, estimated demand and current hourly price</p></div><button id="recommend">Recommend near me</button></div><div id="recommendation"></div><div class="grid">${lots.map(lot => `<article class="lot"><h3>${escapeHtml(lot.name)}</h3><p class="muted">${escapeHtml(lot.address)}</p><div class="row"><span>${lot.free} free of ${lot.capacity}</span><b>₹${lot.price_now}/hour</b></div><div class="bar"><span class="${lot.ratio > .85 ? "high" : ""}" style="width:${Math.round(lot.ratio * 100)}%"></span></div><p class="muted">One-hour forecast: ${Math.round(lot.forecast_1h * 100)}% full</p></article>`).join("")}</div></div>`;
    const button = select("#recommend");
    if (profile.role !== "citizen") button.hidden = true;
    button.addEventListener("click", () => navigator.geolocation.getCurrentPosition(async position => {
        try {
            const results = await api(`/lots/recommend?latitude=${position.coords.latitude}&longitude=${position.coords.longitude}`);
            select("#recommendation").innerHTML = `<p><b>Suggested lots:</b> ${results.slice(0, 3).map(item => `${escapeHtml(item.name)} (${item.distance_m} m)`).join(" · ")}</p>`;
        } catch (error) { setNotice(error.message, true); }
    }, () => setNotice("Location permission was not granted", true)));
}
async function renderVehicles(content) {
    if (profile.role !== "citizen") { content.innerHTML = "<div class='card'><h2>Vehicle registry</h2><p>Vehicle registry is available to citizen accounts.</p></div>"; return; }
    const vehicles = await api("/vehicles");
    content.innerHTML = `<div class="card"><h2>My vehicles</h2><form id="vehicle-form"><label>Registration number<input id="vehicle-plate" placeholder="PY01AB1234" required></label><label>Label<input id="vehicle-label" maxlength="80" placeholder="Family car"></label><button>Add vehicle</button></form><div>${vehicles.map(vehicle => `<div class="item"><b>${escapeHtml(vehicle.plate)}</b> <span class="muted">${escapeHtml(vehicle.label)}</span></div>`).join("") || "No vehicles registered yet."}</div></div>`;
    select("#vehicle-form").addEventListener("submit", async event => { event.preventDefault(); try { await api("/vehicles", "POST", {plate: select("#vehicle-plate").value, label: select("#vehicle-label").value}); await renderVehicles(content); setNotice("Vehicle added"); } catch (error) { setNotice(error.message, true); } });
}
async function renderReports(content) {
    if (profile.role !== "citizen") { content.innerHTML = "<div class='card'><h2>Violation reports</h2><p>Use Police tools to review reports.</p></div>"; return; }
    const reports = await api("/reports/mine");
    content.innerHTML = `<div class="card"><h2>Submit a parking violation</h2><form id="report-form"><label>Description<textarea id="report-description" required minlength="5" maxlength="1200" rows="3"></textarea></label><div class="grid"><label>Latitude<input id="report-latitude" type="number" min="-90" max="90" step="any" required></label><label>Longitude<input id="report-longitude" type="number" min="-180" max="180" step="any" required></label><label>Vehicle plate (optional)<input id="report-plate" placeholder="PY01AB1234"></label></div><button type="button" id="use-location" class="secondary">Use my location</button><button>Submit report</button></form></div><div class="card"><h2>My reports</h2>${reports.map(report => `<div class="item"><div class="row"><b>#${report.id} · ${escapeHtml(report.category)}</b><span class="pill">${escapeHtml(report.status)}</span></div><p class="muted">Priority ${report.priority} · ${escapeHtml(report.created_at)}</p></div>`).join("") || "No reports submitted."}</div>`;
    select("#use-location").addEventListener("click", () => navigator.geolocation.getCurrentPosition(position => { select("#report-latitude").value = position.coords.latitude; select("#report-longitude").value = position.coords.longitude; }, () => setNotice("Location permission was not granted", true)));
    select("#report-form").addEventListener("submit", async event => { event.preventDefault(); try { await api("/reports", "POST", {description: select("#report-description").value, latitude: Number(select("#report-latitude").value), longitude: Number(select("#report-longitude").value), plate: select("#report-plate").value || null}); await renderReports(content); setNotice("Report submitted"); } catch (error) { setNotice(error.message, true); } });
}
async function renderPolice(content) {
    if (!["officer", "admin"].includes(profile.role)) { content.innerHTML = "<div class='card'><h2>Police tools</h2><p>Officer access is required.</p></div>"; return; }
    const [reports, overstays, hotspots] = await Promise.all([api("/police/reports"), api("/police/overstays"), api("/police/hotspots")]);
    content.innerHTML = `<div class="card"><h2>Pending reports</h2>${reports.map(report => `<article class="item"><div class="row"><b>#${report.id} · ${escapeHtml(report.category)}</b><span class="pill">Priority ${report.priority}</span></div><p class="muted">Confidence ${Math.round(report.confidence * 100)}% · risk ${Math.round(report.risk_score * 100)}%</p><button data-open-report="${report.id}">Open</button><div id="report-${report.id}"></div></article>`).join("") || "No pending reports."}</div><div class="grid"><div class="card"><h2>Overstays</h2>${overstays.map(item => `<p>Booking #${item.booking_id} · ${escapeHtml(item.lot)} · ${item.minutes_over} min</p>`).join("") || "No overstays."}</div><div class="card"><h2>Hotspots</h2>${hotspots.map(item => `<p>${item.latitude.toFixed(4)}, ${item.longitude.toFixed(4)} · ${item.count} reports · ${escapeHtml(item.top_category)}</p>`).join("") || "Not enough data."}</div></div><div class="card"><h2>Plate lookup</h2><form id="lookup-form"><label>Registration number<input id="lookup-plate" required></label><button>Lookup</button></form><pre id="lookup-result"></pre></div>`;
    content.querySelectorAll("[data-open-report]").forEach(button => button.addEventListener("click", async () => {
        try {
            const report = await api(`/police/reports/${button.dataset.openReport}`);
            const target = select(`#report-${button.dataset.openReport}`);
            target.innerHTML = `<p>${escapeHtml(report.description)}</p><p class="muted">${report.latitude}, ${report.longitude} · ${escapeHtml(report.plate || "No plate detected")}</p><label>Review note<textarea id="note-${report.id}" maxlength="500"></textarea></label><div class="row"><button data-review="verified" data-id="${report.id}">Verify</button><button class="secondary" data-review="rejected" data-id="${report.id}">Reject</button></div>`;
            target.querySelectorAll("[data-review]").forEach(action => action.addEventListener("click", async () => { try { await api(`/police/reports/${report.id}/review`, "POST", {verdict: action.dataset.review, note: select(`#note-${report.id}`).value}); await renderPolice(content); setNotice("Review saved"); } catch (error) { setNotice(error.message, true); } }));
        } catch (error) { setNotice(error.message, true); }
    }));
    select("#lookup-form").addEventListener("submit", async event => { event.preventDefault(); try { const result = await api("/police/lookup", "POST", {plate: select("#lookup-plate").value}); select("#lookup-result").textContent = JSON.stringify(result, null, 2); } catch (error) { setNotice(error.message, true); } });
}
async function renderDashboard(content) {
    if (!["officer", "admin"].includes(profile.role)) { content.innerHTML = "<div class='card'><h2>Dashboard</h2><p>Officer access is required.</p></div>"; return; }
    const data = await api("/dashboard");
    content.innerHTML = `<div class="card"><h2>Operations dashboard</h2><div class="grid"><div class="lot"><span class="stat">₹${data.parking_revenue}</span>Parking revenue</div><div class="lot"><span class="stat">₹${data.fines_collected}</span>Fines collected</div><div class="lot"><span class="stat">₹${data.fines_pending}</span>Fines pending</div><div class="lot"><span class="stat">${data.bookings_active}</span>Active bookings</div><div class="lot"><span class="stat">${data.citizens}</span>Citizens</div><div class="lot"><span class="stat">${data.overstays}</span>Overstays</div></div></div><div class="card"><h2>Live occupancy</h2><div class="grid">${data.lots.map(lot => `<article class="lot"><h3>${escapeHtml(lot.name)}</h3><div class="row"><span>${lot.occupied}/${lot.capacity} occupied</span><b>₹${lot.price_now}/h</b></div><div class="bar"><span class="${lot.ratio > .85 ? "high" : ""}" style="width:${Math.round(lot.ratio * 100)}%"></span></div><p class="muted">Forecast ${Math.round(lot.forecast_1h * 100)}% · free ${lot.free}</p></article>`).join("")}</div></div><div class="card"><h2>Report categories</h2>${Object.entries(data.reports_by_category).map(([name, count]) => `<div class="item row"><span>${escapeHtml(name)}</span><b>${count}</b></div>`).join("") || "No reports yet."}</div>`;
}
select("#login-form").addEventListener("submit", async event => { event.preventDefault(); try { await signIn(select("#login-email").value, select("#login-password").value); setNotice("Signed in"); } catch (error) { setNotice(error.message, true); } });
select("#register-form").addEventListener("submit", async event => { event.preventDefault(); try { await api("/auth/register", "POST", {name: select("#register-name").value, email: select("#register-email").value, phone: select("#register-phone").value, password: select("#register-password").value}); setNotice("Account created. Sign in to continue."); } catch (error) { setNotice(error.message, true); } });
select("#logout").addEventListener("click", async () => { try { await api("/auth/logout", "POST"); } catch {} token = ""; profile = null; sessionStorage.removeItem("parking_token"); showSignedIn(); select("#content").innerHTML = ""; setNotice("Signed out"); });
document.querySelectorAll("[data-view]").forEach(button => button.addEventListener("click", () => renderView(button.dataset.view)));
async function boot() { if (!token) return; try { profile = await api("/me"); showSignedIn(); await renderView(profile.role === "citizen" ? "lots" : "dashboard"); } catch { token = ""; sessionStorage.removeItem("parking_token"); showSignedIn(); } }
showSignedIn();
boot();
