import os
import time
from contextlib import asynccontextmanager
from collections import defaultdict, deque
from threading import Lock
from fastapi import Depends, FastAPI, Header, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from sqlalchemy.orm import Session
from . import ai
from .audit import verify_audit, write_audit
from .config import APP_NAME, DEBUG, MAX_EVIDENCE_BYTES, REQUEST_SIZE_LIMIT, ROOT
from .database import create_schema, get_db
from .models import AuditEvent, Booking, Challan, Notification, ParkingLot, User, Vehicle, ViolationReport
from .schemas import BookingInput, ChallanInput, LoginInput, LotInput, OfficerInput, PaymentInput, RegisterInput, ReportInput, ReviewInput, SensorInput, VehicleInput
from .security import issue_token, verify_token
from .service import DomainError, add_lot, add_vehicle, authenticate_user, create_booking, create_officer, create_report, dashboard_summary, get_hotspots, get_overstays, issue_challan, lot_state, notify, pay_challan, register_user, review_report, checkin_booking, checkout_booking, update_sensor

@asynccontextmanager
async def lifespan(application):
    create_schema()
    yield

app = FastAPI(title=APP_NAME, docs_url="/docs" if DEBUG else None, redoc_url=None, openapi_url="/openapi.json" if DEBUG else None, lifespan=lifespan)
_rate_hits = defaultdict(deque)
_rate_lock = Lock()
_revoked_tokens = set()
_revoked_lock = Lock()
FINES = {"fire_hydrant_or_emergency": 1500, "disabled_bay_misuse": 1000, "blocking_road": 1000, "footpath_encroachment": 750, "double_parking": 600, "no_parking_zone": 500, "gate_or_driveway_block": 500, "abandoned_vehicle": 500, "illegal_parking": 500}

@app.middleware("http")
async def request_guard(request: Request, call_next):
    client = request.client.host if request.client else "unknown"
    limit = 12 if request.url.path.startswith("/api/auth") else 240
    key = (client, limit)
    now = time.monotonic()
    with _rate_lock:
        hits = _rate_hits[key]
        while hits and hits[0] < now - 60:
            hits.popleft()
        if len(hits) >= limit:
            return JSONResponse({"detail": "Too many requests"}, status_code=429)
        hits.append(now)
    try:
        length = int(request.headers.get("content-length", "0"))
    except ValueError:
        length = REQUEST_SIZE_LIMIT + 1
    if length > REQUEST_SIZE_LIMIT:
        return JSONResponse({"detail": "Payload too large"}, status_code=413)
    response = await call_next(request)
    response.headers.update({"Content-Security-Policy": "default-src 'self'; img-src 'self' data: blob:; style-src 'self'; script-src 'self'; frame-ancestors 'none'; base-uri 'none'", "X-Content-Type-Options": "nosniff", "X-Frame-Options": "DENY", "Referrer-Policy": "no-referrer", "Permissions-Policy": "geolocation=(self), camera=(self)"})
    if request.url.path.startswith("/api"):
        response.headers["Cache-Control"] = "no-store"
    return response

@app.exception_handler(DomainError)
async def domain_error_handler(request: Request, exc: DomainError):
    return JSONResponse({"detail": exc.detail}, status_code=exc.status_code)

def current_user(authorization: str | None = Header(default=None), db: Session = Depends(get_db)):
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(401, "Login required")
    claims = verify_token(authorization[7:])
    if not claims:
        raise HTTPException(401, "Invalid or expired token")
    with _revoked_lock:
        if claims["jti"] in _revoked_tokens:
            raise HTTPException(401, "Token revoked")
    user = db.get(User, claims["sub"])
    if not user or not user.active or user.role != claims["role"]:
        raise HTTPException(401, "Account unavailable")
    return user

def require_roles(*roles):
    def dependency(user: User = Depends(current_user)):
        if user.role not in roles:
            raise HTTPException(403, "Insufficient permissions")
        return user
    return dependency

Citizen = require_roles("citizen")
Police = require_roles("officer", "admin")
Admin = require_roles("admin")

@app.get("/api/health")
def health():
    return {"status": "ok", "service": APP_NAME}

@app.post("/api/auth/register", status_code=201)
def register(body: RegisterInput, db: Session = Depends(get_db)):
    user = register_user(db, body.email, body.name, body.phone, body.password)
    return {"ok": True, "id": user.id}

@app.post("/api/auth/login")
def login(body: LoginInput, db: Session = Depends(get_db)):
    user = authenticate_user(db, body.email, body.password)
    return {"token": issue_token(user.id, user.role), "role": user.role, "expires_in": 3600}

@app.post("/api/auth/logout")
def logout(authorization: str | None = Header(default=None), user: User = Depends(current_user)):
    claims = verify_token(authorization[7:])
    with _revoked_lock:
        _revoked_tokens.add(claims["jti"])
    return {"ok": True}

@app.get("/api/me")
def who_am_i(user: User = Depends(current_user)):
    return {"id": user.id, "email": user.email, "name": user.name, "role": user.role, "points": user.points}

@app.post("/api/vehicles", status_code=201)
def vehicle_add(body: VehicleInput, user: User = Depends(Citizen), db: Session = Depends(get_db)):
    vehicle = add_vehicle(db, user, body.plate, body.label)
    return {"id": vehicle.id, "plate": vehicle.plate, "label": vehicle.label}

@app.get("/api/vehicles")
def vehicle_list(user: User = Depends(Citizen), db: Session = Depends(get_db)):
    return [{"id": item.id, "plate": item.plate, "label": item.label} for item in db.query(Vehicle).filter_by(owner_id=user.id).order_by(Vehicle.id.desc()).all()]

@app.get("/api/lots")
def lots_list(user: User = Depends(current_user), db: Session = Depends(get_db)):
    return [lot_state(db, lot) for lot in db.query(ParkingLot).filter_by(active=True).order_by(ParkingLot.name).all()]

@app.get("/api/lots/recommend")
def recommend_lots(latitude: float, longitude: float, user: User = Depends(current_user), db: Session = Depends(get_db)):
    from .ai import recommend_lots as rank_lots
    lots = db.query(ParkingLot).filter_by(active=True).all()
    return rank_lots(lots, latitude, longitude, lambda lot: lot_state(db, lot))

@app.post("/api/bookings", status_code=201)
def booking_create(body: BookingInput, user: User = Depends(Citizen), db: Session = Depends(get_db)):
    booking = create_booking(db, user, body.lot_id, body.vehicle_id, body.hours, body.start_in_minutes)
    return {"id": booking.id, "estimated_fee": booking.estimated_fee, "rate_per_hour": booking.rate_per_hour, "starts_at": booking.starts_at.isoformat(), "ends_at": booking.ends_at.isoformat()}

@app.get("/api/bookings/mine")
def booking_mine(user: User = Depends(Citizen), db: Session = Depends(get_db)):
    rows = db.query(Booking).filter_by(user_id=user.id).order_by(Booking.id.desc()).limit(100).all()
    result = []
    for booking in rows:
        lot = db.get(ParkingLot, booking.lot_id)
        risk = None
        if booking.status == "checked_in":
            minutes_left = (booking.ends_at - __import__("app.database", fromlist=["utcnow"]).utcnow()).total_seconds() / 60
            risk = ai.overstay_risk(minutes_left, lot_state(db, lot)["ratio"])
        result.append({"id": booking.id, "lot": lot.name if lot else "Unknown", "status": booking.status, "starts_at": booking.starts_at.isoformat(), "ends_at": booking.ends_at.isoformat(), "estimated_fee": booking.estimated_fee, "final_fee": booking.final_fee, "overstay_risk": risk})
    return result

@app.post("/api/bookings/{booking_id}/checkin")
def booking_checkin(booking_id: int, user: User = Depends(Citizen), db: Session = Depends(get_db)):
    booking = checkin_booking(db, user, booking_id)
    return {"ok": True, "status": booking.status}

@app.post("/api/bookings/{booking_id}/checkout")
def booking_checkout(booking_id: int, user: User = Depends(Citizen), db: Session = Depends(get_db)):
    booking = checkout_booking(db, user, booking_id)
    return {"status": booking.status, "final_fee": booking.final_fee}

@app.post("/api/reports", status_code=201)
def report_create(body: ReportInput, user: User = Depends(Citizen), db: Session = Depends(get_db)):
    report = create_report(db, user, body.description, body.latitude, body.longitude, body.plate, body.evidence_base64)
    return {"id": report.id, "category": report.category, "confidence": report.confidence, "priority": report.priority, "risk_score": report.risk_score, "duplicate_of": report.duplicate_of}

@app.get("/api/reports/mine")
def report_mine(user: User = Depends(Citizen), db: Session = Depends(get_db)):
    reports = db.query(ViolationReport).filter_by(reporter_id=user.id).order_by(ViolationReport.id.desc()).limit(100).all()
    return [{"id": item.id, "category": item.category, "status": item.status, "priority": item.priority, "created_at": item.created_at.isoformat(), "review_note": item.review_note} for item in reports]

@app.get("/api/challans/mine")
def challan_mine(user: User = Depends(Citizen), db: Session = Depends(get_db)):
    plates = [item.plate for item in db.query(Vehicle).filter_by(owner_id=user.id).all()]
    rows = db.query(Challan).filter(Challan.plate.in_(plates)).order_by(Challan.id.desc()).all() if plates else []
    return [{"id": item.id, "plate": item.plate, "category": item.category, "amount": item.amount, "status": item.status, "created_at": item.created_at.isoformat()} for item in rows]

@app.post("/api/challans/{challan_id}/pay")
def challan_pay(challan_id: int, body: PaymentInput, user: User = Depends(Citizen), db: Session = Depends(get_db)):
    challan = pay_challan(db, user, challan_id, body.payment_reference)
    return {"ok": True, "id": challan.id, "status": challan.status, "paid_at": challan.paid_at.isoformat()}

@app.get("/api/notifications")
def notifications(user: User = Depends(current_user), db: Session = Depends(get_db)):
    rows = db.query(Notification).filter_by(user_id=user.id).order_by(Notification.id.desc()).limit(100).all()
    return [{"id": item.id, "message": item.message, "read": item.read_at is not None, "created_at": item.created_at.isoformat()} for item in rows]

@app.get("/api/police/reports")
def police_reports(status: str = "pending", officer: User = Depends(Police), db: Session = Depends(get_db)):
    if status not in {"pending", "verified", "rejected"}:
        raise HTTPException(422, "Invalid report status")
    rows = db.query(ViolationReport).filter_by(status=status).order_by(ViolationReport.priority.desc(), ViolationReport.id.asc()).limit(200).all()
    return [{"id": item.id, "category": item.category, "confidence": item.confidence, "priority": item.priority, "risk_score": item.risk_score, "duplicate_of": item.duplicate_of, "created_at": item.created_at.isoformat(), "has_evidence": bool(item.evidence_data)} for item in rows]

@app.get("/api/police/reports/{report_id}")
def police_report(report_id: int, officer: User = Depends(Police), db: Session = Depends(get_db)):
    report = db.get(ViolationReport, report_id)
    if not report:
        raise HTTPException(404, "Report not found")
    write_audit(db, officer.id, officer.role, "report_viewed", "violation_report", report.id)
    db.commit()
    return {"id": report.id, "description": report.description, "latitude": report.latitude, "longitude": report.longitude, "plate": report.plate, "evidence_sha256": report.evidence_sha256, "evidence_base64": report.evidence_data, "category": report.category, "status": report.status}

@app.post("/api/police/reports/{report_id}/review")
def police_review(report_id: int, body: ReviewInput, officer: User = Depends(Police), db: Session = Depends(get_db)):
    report = review_report(db, officer, report_id, body.verdict, body.note)
    return {"ok": True, "status": report.status}

@app.post("/api/police/challans", status_code=201)
def police_issue_challan(body: ChallanInput, officer: User = Depends(Police), db: Session = Depends(get_db)):
    challan = issue_challan(db, officer, body.plate, body.category, body.report_id, body.amount)
    return {"id": challan.id, "amount": challan.amount, "status": challan.status}

@app.post("/api/police/lookup")
def police_lookup(body: VehicleInput, officer: User = Depends(Police), db: Session = Depends(get_db)):
    vehicle = db.query(Vehicle).filter_by(plate=body.plate).first()
    reports = db.query(ViolationReport).filter_by(plate=body.plate).order_by(ViolationReport.id.desc()).limit(100).all()
    challans = db.query(Challan).filter_by(plate=body.plate).order_by(Challan.id.desc()).limit(100).all()
    write_audit(db, officer.id, officer.role, "plate_lookup", "vehicle", body.plate)
    db.commit()
    return {"registered": vehicle is not None, "challans": [{"id": item.id, "category": item.category, "amount": item.amount, "status": item.status} for item in challans], "reports": [{"id": item.id, "category": item.category, "status": item.status} for item in reports]}

@app.post("/api/police/lots/{lot_id}/sensor")
def police_sensor(lot_id: int, body: SensorInput, officer: User = Depends(Police), db: Session = Depends(get_db)):
    lot = update_sensor(db, officer, lot_id, body.occupied)
    return {"ok": True, "occupied": lot.sensor_occupied}

@app.get("/api/police/overstays")
def police_overstays(officer: User = Depends(Police), db: Session = Depends(get_db)):
    return get_overstays(db)

@app.get("/api/police/hotspots")
def police_hotspots(officer: User = Depends(Police), db: Session = Depends(get_db)):
    return get_hotspots(db)

@app.get("/api/police/audit/verify")
def police_audit_verify(officer: User = Depends(Police), db: Session = Depends(get_db)):
    return verify_audit(db)

@app.post("/api/admin/officers", status_code=201)
def admin_add_officer(body: OfficerInput, admin: User = Depends(Admin), db: Session = Depends(get_db)):
    user = create_officer(db, admin, body.email, body.name, body.password)
    return {"id": user.id, "role": user.role}

@app.post("/api/admin/lots", status_code=201)
def admin_add_lot(body: LotInput, admin: User = Depends(Admin), db: Session = Depends(get_db)):
    lot = add_lot(db, admin, body.model_dump())
    return {"id": lot.id, "name": lot.name}

@app.get("/api/dashboard")
def dashboard(officer: User = Depends(Police), db: Session = Depends(get_db)):
    return dashboard_summary(db)

@app.get("/api/admin/audit")
def admin_audit(limit: int = 100, admin: User = Depends(Admin), db: Session = Depends(get_db)):
    limit = max(1, min(500, limit))
    rows = db.query(AuditEvent).order_by(AuditEvent.id.desc()).limit(limit).all()
    return [{"id": item.id, "actor_id": item.actor_id, "actor_role": item.actor_role, "action": item.action, "entity_type": item.entity_type, "entity_id": item.entity_id, "created_at": item.created_at.isoformat(), "event_hash": item.event_hash} for item in rows]

static_dir = ROOT / "static"
if static_dir.exists():
    app.mount("/static", StaticFiles(directory=str(static_dir)), name="static")

@app.get("/")
def index():
    page = static_dir / "index.html"
    if page.exists():
        return FileResponse(page)
    return {"service": APP_NAME, "docs": "/docs" if DEBUG else "disabled"}

def main():
    import uvicorn
    create_schema()
    uvicorn.run(app, host=os.environ.get("PARKING_HOST", "127.0.0.1"), port=int(os.environ.get("PARKING_PORT", "8000")))

if __name__ == "__main__":
    main()

@app.get("/api/admin/analytics/extended")
def extended_analytics(days: int = 30, admin: User = Depends(Admin), db: Session = Depends(get_db)):
    from .analytics import dashboard_extra_metrics
    return dashboard_extra_metrics(db, max(1, min(days, 90)))

@app.get("/api/police/reports/analytics")
def police_report_analytics(officer: User = Depends(Police), db: Session = Depends(get_db)):
    from .reporting import report_backlog, report_category_matrix, report_risk_bands
    reports = db.query(ViolationReport).all()
    return {"backlog": report_backlog(reports), "category_matrix": report_category_matrix(reports), "risk_bands": report_risk_bands(reports)}

@app.get("/api/admin/maintenance")
def admin_maintenance(admin: User = Depends(Admin), db: Session = Depends(get_db)):
    from .maintenance import maintenance_summary
    return maintenance_summary(db)

@app.get("/api/admin/exports/reports.csv")
def admin_export_reports(include_description: bool = False, admin: User = Depends(Admin), db: Session = Depends(get_db)):
    from fastapi.responses import Response
    from .exports import reports_export
    rows = db.query(ViolationReport).order_by(ViolationReport.id.asc()).all()
    content = reports_export(rows, include_coordinates=True, include_description=include_description)
    return Response(content=content, media_type="text/csv", headers={"Content-Disposition": "attachment; filename=violation_reports.csv", "Cache-Control": "no-store"})
