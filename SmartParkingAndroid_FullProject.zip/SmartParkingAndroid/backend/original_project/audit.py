import hashlib
import json
from .database import utcnow
from .models import AuditEvent

GENESIS_HASH = "0" * 64

def _event_hash(previous_hash, timestamp, actor_id, actor_role, action, entity_type, entity_id, details_json):
    payload = "|".join((previous_hash, timestamp, str(actor_id or 0), actor_role, action, entity_type, entity_id, details_json))
    return hashlib.sha256(payload.encode()).hexdigest()

def write_audit(db, actor_id, actor_role, action, entity_type="", entity_id="", details=None):
    previous = db.query(AuditEvent).order_by(AuditEvent.id.desc()).first()
    previous_hash = previous.event_hash if previous else GENESIS_HASH
    timestamp = utcnow()
    details_json = json.dumps(details or {}, sort_keys=True, separators=(",", ":"))
    digest = _event_hash(previous_hash, timestamp.isoformat(), actor_id, actor_role, action, entity_type, str(entity_id), details_json)
    event = AuditEvent(actor_id=actor_id, actor_role=actor_role, action=action, entity_type=entity_type, entity_id=str(entity_id), details_json=details_json, previous_hash=previous_hash, event_hash=digest, created_at=timestamp)
    db.add(event)
    db.flush()
    return event

def verify_audit(db):
    previous_hash = GENESIS_HASH
    entries = db.query(AuditEvent).order_by(AuditEvent.id.asc()).all()
    for event in entries:
        expected = _event_hash(previous_hash, event.created_at.isoformat(), event.actor_id, event.actor_role, event.action, event.entity_type, event.entity_id, event.details_json)
        if event.previous_hash != previous_hash or event.event_hash != expected:
            return {"intact": False, "first_broken_id": event.id, "entries": len(entries)}
        previous_hash = event.event_hash
    return {"intact": True, "first_broken_id": None, "entries": len(entries)}
