from datetime import timedelta
from sqlalchemy import func
from .audit import write_audit
from .database import utcnow
from .models import Booking, Notification, OccupancySample, ParkingLot, User, ViolationReport


def expire_unchecked_bookings(db, actor_id=None, actor_role="system", grace_minutes=30, now=None):
    now = now or utcnow()
    cutoff = now - timedelta(minutes=grace_minutes)
    rows = db.query(Booking).filter(Booking.status == "reserved", Booking.ends_at < cutoff).all()
    for booking in rows:
        booking.status = "expired"
        write_audit(db, actor_id, actor_role, "booking_expired", "booking", booking.id)
    db.commit()
    return {"expired_count": len(rows), "booking_ids": [booking.id for booking in rows]}


def prune_occupancy_samples(db, older_than_days=180, now=None):
    now = now or utcnow()
    cutoff = now - timedelta(days=older_than_days)
    count = db.query(OccupancySample).filter(OccupancySample.sampled_at < cutoff).delete(synchronize_session=False)
    db.commit()
    return {"deleted_count": count, "cutoff": cutoff.isoformat()}


def deactivate_inactive_users(db, days=365, now=None):
    now = now or utcnow()
    cutoff = now - timedelta(days=days)
    rows = db.query(User).filter(User.active.is_(True), User.role == "citizen", User.created_at < cutoff).all()
    for user in rows:
        user.active = False
        write_audit(db, None, "system", "user_deactivated", "user", user.id)
    db.commit()
    return {"deactivated_count": len(rows), "user_ids": [user.id for user in rows]}


def count_old_pending_reports(db, days=14, now=None):
    now = now or utcnow()
    cutoff = now - timedelta(days=days)
    count = db.query(ViolationReport).filter(ViolationReport.status == "pending", ViolationReport.created_at < cutoff).count()
    return {"count": count, "cutoff": cutoff.isoformat()}


def report_stale_lots(db, no_sensor_days=2, now=None):
    now = now or utcnow()
    cutoff = now - timedelta(days=no_sensor_days)
    lots = db.query(ParkingLot).filter_by(active=True).all()
    output = []
    for lot in lots:
        latest = db.query(func.max(OccupancySample.sampled_at)).filter_by(lot_id=lot.id).scalar()
        if latest is None or latest < cutoff:
            output.append({"lot_id": lot.id, "name": lot.name, "last_sample_at": latest.isoformat() if latest else None})
    return output


def notification_counts(db, user_id):
    total = db.query(Notification).filter_by(user_id=user_id).count()
    unread = db.query(Notification).filter_by(user_id=user_id, read_at=None).count()
    return {"total": total, "unread": unread, "read": total - unread}


def mark_notifications_read(db, user_id, notification_ids=None):
    query = db.query(Notification).filter_by(user_id=user_id, read_at=None)
    if notification_ids:
        query = query.filter(Notification.id.in_(notification_ids))
    now = utcnow()
    rows = query.all()
    for row in rows:
        row.read_at = now
    db.commit()
    return {"marked_read": len(rows), "at": now.isoformat()}


def delete_expired_notifications(db, days=180, now=None):
    now = now or utcnow()
    cutoff = now - timedelta(days=days)
    count = db.query(Notification).filter(Notification.created_at < cutoff).delete(synchronize_session=False)
    db.commit()
    return {"deleted_count": count, "cutoff": cutoff.isoformat()}


def parking_data_quality(db):
    lots = db.query(ParkingLot).all()
    reports = db.query(ViolationReport).all()
    output = {"lots_total": len(lots), "lots_invalid_capacity": 0, "lots_sensor_out_of_range": 0, "reports_total": len(reports), "reports_invalid_coordinates": 0, "reports_missing_description": 0}
    for lot in lots:
        if lot.capacity <= 0 or lot.accessible_spaces < 0 or lot.accessible_spaces > lot.capacity:
            output["lots_invalid_capacity"] += 1
        if lot.sensor_occupied < 0 or lot.sensor_occupied > lot.capacity:
            output["lots_sensor_out_of_range"] += 1
    for report in reports:
        if not -90 <= report.latitude <= 90 or not -180 <= report.longitude <= 180:
            output["reports_invalid_coordinates"] += 1
        if not report.description.strip():
            output["reports_missing_description"] += 1
    output["healthy"] = not any(value for key, value in output.items() if key not in {"lots_total", "reports_total", "healthy"})
    return output


def compact_notification_message(message, maximum_length=240):
    normalized = " ".join(str(message).split())
    if len(normalized) <= maximum_length:
        return normalized
    return normalized[: maximum_length - 1].rstrip() + "…"


def normalize_notification_batch(messages, maximum_items=100):
    result = []
    seen = set()
    for message in messages:
        clean = compact_notification_message(message)
        if not clean or clean in seen:
            continue
        seen.add(clean)
        result.append(clean)
        if len(result) >= maximum_items:
            break
    return result


def maintenance_summary(db, now=None):
    now = now or utcnow()
    return {"pending_reports_14d": count_old_pending_reports(db, 14, now)["count"], "stale_lots": report_stale_lots(db, 2, now), "data_quality": parking_data_quality(db), "unread_notifications": db.query(Notification).filter(Notification.read_at.is_(None)).count(), "active_bookings": db.query(Booking).filter(Booking.status.in_(("reserved", "checked_in"))).count()}
