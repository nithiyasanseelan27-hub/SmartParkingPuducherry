import base64
import binascii
import math
from datetime import timedelta
from sqlalchemy import func
from sqlalchemy.exc import IntegrityError
from . import ai
from .audit import write_audit
from .config import LOGIN_FAILURE_LIMIT, LOGIN_LOCK_MINUTES, MAX_EVIDENCE_BYTES, REPORT_DAILY_LIMIT
from .database import utcnow
from .models import AuditEvent, Booking, Challan, Notification, OccupancySample, ParkingLot, User, Vehicle, ViolationReport
from .security import digest_bytes, hash_password, verify_password

FINES = {"fire_hydrant_or_emergency": 1500.0, "disabled_bay_misuse": 1000.0, "blocking_road": 1000.0, "footpath_encroachment": 750.0, "double_parking": 600.0, "no_parking_zone": 500.0, "gate_or_driveway_block": 500.0, "abandoned_vehicle": 500.0, "illegal_parking": 500.0}
ACTIVE_BOOKING_STATUSES = ("reserved", "checked_in")

class DomainError(Exception):
    def __init__(self, status_code, detail):
        self.status_code = status_code
        self.detail = detail
        super().__init__(detail)

def notify(db, user_id, message):
    db.add(Notification(user_id=user_id, message=message))

def register_user(db, email, name, phone, password):
    normalized = email.strip().casefold()
    if db.query(User).filter_by(email=normalized).first():
        raise DomainError(409, "Account already exists")
    user = User(email=normalized, name=" ".join(name.split()), phone=phone.strip(), password_hash=hash_password(password), role="citizen")
    db.add(user)
    try:
        db.flush()
        write_audit(db, user.id, user.role, "register", "user", user.id)
        db.commit()
    except IntegrityError:
        db.rollback()
        raise DomainError(409, "Account already exists")
    return user

def authenticate_user(db, email, password):
    now = utcnow()
    user = db.query(User).filter_by(email=email.strip().casefold()).first()
    if user and user.locked_until and user.locked_until > now:
        raise DomainError(423, "Account temporarily locked")
    if not user or not user.active or not verify_password(password, user.password_hash):
        if user:
            user.failed_logins += 1
            if user.failed_logins >= LOGIN_FAILURE_LIMIT:
                user.failed_logins = 0
                user.locked_until = now + timedelta(minutes=LOGIN_LOCK_MINUTES)
            db.commit()
        raise DomainError(401, "Invalid credentials")
    user.failed_logins = 0
    user.locked_until = None
    write_audit(db, user.id, user.role, "login", "user", user.id)
    db.commit()
    return user

def add_vehicle(db, user, plate, label=""):
    normalized = ai.normalize_plate(plate)
    if not normalized:
        raise DomainError(422, "Invalid Indian vehicle registration number")
    vehicle = Vehicle(owner_id=user.id, plate=normalized, label=label.strip())
    db.add(vehicle)
    try:
        db.flush()
        write_audit(db, user.id, user.role, "vehicle_added", "vehicle", vehicle.id)
        db.commit()
    except IntegrityError:
        db.rollback()
        raise DomainError(409, "Vehicle already registered")
    return vehicle

def add_lot(db, actor, values):
    if values["accessible_spaces"] > values["capacity"]:
        raise DomainError(422, "Accessible spaces cannot exceed total capacity")
    lot = ParkingLot(**values)
    db.add(lot)
    try:
        db.flush()
        write_audit(db, actor.id, actor.role, "lot_added", "parking_lot", lot.id)
        db.commit()
    except IntegrityError:
        db.rollback()
        raise DomainError(409, "A lot with that name already exists")
    return lot

def lot_occupancy(db, lot, at=None):
    at = at or utcnow()
    checked_in = db.query(Booking).filter(Booking.lot_id == lot.id, Booking.status == "checked_in").count()
    occupied = min(lot.capacity, max(0, lot.sensor_occupied + checked_in))
    return occupied, max(0, lot.capacity - occupied)

def lot_state(db, lot, now=None):
    now = now or utcnow()
    occupied, free = lot_occupancy(db, lot, now)
    ratio = occupied / lot.capacity if lot.capacity else 0.0
    samples = db.query(OccupancySample).filter_by(lot_id=lot.id).order_by(OccupancySample.sampled_at.desc()).limit(400).all()
    forecast = ai.occupancy_forecast(samples, now + timedelta(hours=1), now, ratio)
    baseline = ai.occupancy_forecast(samples, now, now)
    local_hour = (now + timedelta(hours=5, minutes=30)).hour
    state = {"id": lot.id, "name": lot.name, "address": lot.address, "latitude": lot.latitude, "longitude": lot.longitude, "capacity": lot.capacity, "occupied": occupied, "free": free, "ratio": round(ratio, 3), "forecast_1h": round(forecast, 3), "price_now": ai.dynamic_price(lot.base_rate, ratio, forecast, local_hour), "anomaly": ai.occupancy_anomaly(ratio, baseline), "accessible_spaces": lot.accessible_spaces}
    state["forecast_24h"] = [round(ai.occupancy_forecast(samples, now + timedelta(hours=hours), now, ratio), 3) for hours in range(0, 25, 3)]
    return state

def record_occupancy(db, lot):
    occupied, _ = lot_occupancy(db, lot)
    ratio = occupied / lot.capacity if lot.capacity else 0.0
    sample = OccupancySample(lot_id=lot.id, occupancy_ratio=ratio)
    db.add(sample)
    return sample

def create_booking(db, user, lot_id, vehicle_id, hours, start_in_minutes=0):
    lot = db.get(ParkingLot, lot_id)
    vehicle = db.get(Vehicle, vehicle_id)
    if not lot or not lot.active or not vehicle or vehicle.owner_id != user.id:
        raise DomainError(404, "Lot or vehicle not found")
    now = utcnow()
    starts_at = now + timedelta(minutes=start_in_minutes)
    ends_at = starts_at + timedelta(hours=hours)
    active_vehicle_booking = db.query(Booking).filter(Booking.vehicle_id == vehicle.id, Booking.status.in_(ACTIVE_BOOKING_STATUSES)).first()
    if active_vehicle_booking:
        raise DomainError(409, "Vehicle already has an active booking")
    overlaps = db.query(Booking).filter(Booking.lot_id == lot.id, Booking.status.in_(ACTIVE_BOOKING_STATUSES), Booking.starts_at < ends_at, Booking.ends_at > starts_at).count()
    if lot.sensor_occupied + overlaps >= lot.capacity:
        raise DomainError(409, "Lot is full for that time")
    state = lot_state(db, lot, now)
    rate = state["price_now"]
    booking = Booking(user_id=user.id, lot_id=lot.id, vehicle_id=vehicle.id, starts_at=starts_at, ends_at=ends_at, rate_per_hour=rate, estimated_fee=round(rate * hours, 2), final_fee=0, status="reserved")
    db.add(booking)
    db.flush()
    record_occupancy(db, lot)
    write_audit(db, user.id, user.role, "booking_created", "booking", booking.id, {"lot_id": lot.id, "hours": hours})
    db.commit()
    return booking

def checkin_booking(db, user, booking_id):
    booking = db.get(Booking, booking_id)
    if not booking or booking.user_id != user.id:
        raise DomainError(404, "Booking not found")
    if booking.status != "reserved":
        raise DomainError(409, "Booking is not available for check-in")
    if utcnow() < booking.starts_at - timedelta(minutes=15):
        raise DomainError(400, "Check-in opens 15 minutes before the booking")
    booking.status = "checked_in"
    booking.checked_in_at = utcnow()
    lot = db.get(ParkingLot, booking.lot_id)
    record_occupancy(db, lot)
    write_audit(db, user.id, user.role, "booking_checkin", "booking", booking.id)
    db.commit()
    return booking

def checkout_booking(db, user, booking_id):
    booking = db.get(Booking, booking_id)
    if not booking or booking.user_id != user.id:
        raise DomainError(404, "Booking not found")
    if booking.status != "checked_in" or not booking.checked_in_at:
        raise DomainError(409, "Booking is not checked in")
    now = utcnow()
    used_hours = max(0.25, math.ceil(max(0, (now - booking.checked_in_at).total_seconds()) / 900) / 4)
    booked_hours = (booking.ends_at - booking.starts_at).total_seconds() / 3600
    normal_hours = min(used_hours, booked_hours)
    extra_hours = max(0.0, used_hours - booked_hours)
    fee = booking.rate_per_hour * normal_hours + booking.rate_per_hour * 1.5 * extra_hours
    booking.final_fee = round(fee, 2)
    booking.status = "completed"
    booking.checked_out_at = now
    if extra_hours > 0:
        notify(db, user.id, f"Overstay surcharge applied to booking #{booking.id}")
    lot = db.get(ParkingLot, booking.lot_id)
    record_occupancy(db, lot)
    write_audit(db, user.id, user.role, "booking_checkout", "booking", booking.id, {"fee": booking.final_fee})
    db.commit()
    return booking

def create_report(db, user, description, latitude, longitude, plate=None, evidence_base64=None):
    since = utcnow() - timedelta(days=1)
    count = db.query(ViolationReport).filter(ViolationReport.reporter_id == user.id, ViolationReport.created_at > since).count()
    if count >= REPORT_DAILY_LIMIT:
        raise DomainError(429, "Daily report limit reached")
    evidence = None
    evidence_hash = None
    if evidence_base64:
        try:
            encoded = evidence_base64.split(",")[-1]
            evidence = base64.b64decode(encoded, validate=True)
        except (binascii.Error, ValueError):
            raise DomainError(422, "Evidence must be valid base64 data")
        if len(evidence) > MAX_EVIDENCE_BYTES:
            raise DomainError(413, "Evidence file is too large")
        if not evidence.startswith(b"\x89PNG\r\n\x1a\n") and not evidence.startswith(b"\xff\xd8\xff") and not evidence.startswith(b"GIF8") and not evidence.startswith(b"RIFF"):
            raise DomainError(422, "Evidence must be an image")
        evidence_hash = digest_bytes(evidence)
    category, confidence = ai.classify_violation(description)
    previous = db.query(ViolationReport).filter(ViolationReport.created_at > utcnow() - timedelta(hours=6)).all()
    duplicate = ai.find_duplicate(description, latitude, longitude, plate, previous)
    risk = ai.fake_report_risk(user.points, 0, bool(evidence), len(description), bool(duplicate))
    priority = ai.priority_score(category, description, risk)
    report = ViolationReport(reporter_id=user.id, description=description.strip(), category=category, confidence=confidence, priority=priority, risk_score=risk, latitude=round(latitude, 3), longitude=round(longitude, 3), plate=plate, evidence_sha256=evidence_hash, evidence_data=base64.b64encode(evidence).decode() if evidence else None, duplicate_of=duplicate)
    db.add(report)
    db.flush()
    write_audit(db, user.id, user.role, "report_created", "violation_report", report.id, {"category": category, "priority": priority})
    db.commit()
    return report

def review_report(db, officer, report_id, verdict, note=""):
    report = db.get(ViolationReport, report_id)
    if not report or report.status != "pending":
        raise DomainError(409, "Report is not reviewable")
    if verdict not in {"verified", "rejected"}:
        raise DomainError(422, "Verdict must be verified or rejected")
    report.status = verdict
    report.reviewed_by = officer.id
    report.review_note = note.strip()
    report.reviewed_at = utcnow()
    reporter = db.get(User, report.reporter_id)
    if verdict == "verified":
        points = 0 if report.duplicate_of else 10 + (5 if report.priority >= 4 else 0)
        reporter.points += points
        notify(db, reporter.id, f"Report #{report.id} verified. Reward points: {points}")
    else:
        notify(db, reporter.id, f"Report #{report.id} was not accepted")
    write_audit(db, officer.id, officer.role, f"report_{verdict}", "violation_report", report.id)
    db.commit()
    return report

def issue_challan(db, officer, plate, category, report_id=None, amount=None):
    normalized = ai.normalize_plate(plate)
    if not normalized:
        raise DomainError(422, "Invalid vehicle registration number")
    report = None
    if report_id is not None:
        report = db.get(ViolationReport, report_id)
        if not report or report.status != "verified":
            raise DomainError(409, "Report must be verified before a challan is issued")
    vehicle = db.query(Vehicle).filter_by(plate=normalized).first()
    charge = float(amount if amount is not None else FINES.get(category, 500.0))
    challan = Challan(vehicle_id=vehicle.id if vehicle else None, plate=normalized, report_id=report_id, issued_by=officer.id, category=category, amount=charge)
    db.add(challan)
    db.flush()
    if vehicle:
        notify(db, vehicle.owner_id, f"E-challan #{challan.id} issued: Rs {charge:.2f}")
    write_audit(db, officer.id, officer.role, "challan_issued", "challan", challan.id, {"amount": charge, "category": category})
    db.commit()
    return challan

def pay_challan(db, user, challan_id, payment_reference):
    challan = db.get(Challan, challan_id)
    if not challan:
        raise DomainError(404, "Challan not found")
    vehicle = db.query(Vehicle).filter_by(plate=challan.plate, owner_id=user.id).first()
    if not vehicle:
        raise DomainError(404, "Challan not payable by this account")
    if challan.status != "unpaid":
        raise DomainError(409, "Challan has already been paid")
    challan.status = "paid"
    challan.payment_reference = payment_reference.strip()
    challan.paid_at = utcnow()
    write_audit(db, user.id, user.role, "challan_paid", "challan", challan.id)
    db.commit()
    return challan

def create_officer(db, admin, email, name, password):
    normalized = email.strip().casefold()
    if db.query(User).filter_by(email=normalized).first():
        raise DomainError(409, "Account already exists")
    user = User(email=normalized, name=name.strip(), phone="", password_hash=hash_password(password), role="officer")
    db.add(user)
    try:
        db.flush()
        write_audit(db, admin.id, admin.role, "officer_created", "user", user.id)
        db.commit()
    except IntegrityError:
        db.rollback()
        raise DomainError(409, "Account already exists")
    return user

def update_sensor(db, officer, lot_id, occupied):
    lot = db.get(ParkingLot, lot_id)
    if not lot:
        raise DomainError(404, "Parking lot not found")
    lot.sensor_occupied = min(occupied, lot.capacity)
    record_occupancy(db, lot)
    write_audit(db, officer.id, officer.role, "sensor_updated", "parking_lot", lot.id, {"occupied": lot.sensor_occupied})
    db.commit()
    return lot

def get_hotspots(db):
    reports = db.query(ViolationReport).filter(ViolationReport.status != "rejected").all()
    points = [(report.latitude, report.longitude, report.category) for report in reports]
    return ai.detect_hotspots(points)

def get_overstays(db):
    now = utcnow()
    records = db.query(Booking).filter(Booking.status == "checked_in", Booking.ends_at < now).all()
    result = []
    for booking in records:
        lot = db.get(ParkingLot, booking.lot_id)
        result.append({"booking_id": booking.id, "lot": lot.name if lot else "Unknown", "minutes_over": int((now - booking.ends_at).total_seconds() / 60)})
    return result

def dashboard_summary(db):
    now = utcnow()
    lots = [lot_state(db, lot, now) for lot in db.query(ParkingLot).filter_by(active=True).all()]
    reports = db.query(ViolationReport).all()
    categories = {}
    statuses = {}
    trend = {}
    for report in reports:
        categories[report.category] = categories.get(report.category, 0) + 1
        statuses[report.status] = statuses.get(report.status, 0) + 1
        if report.created_at >= now - timedelta(days=7):
            key = report.created_at.strftime("%Y-%m-%d")
            trend[key] = trend.get(key, 0) + 1
    parking_revenue = db.query(func.coalesce(func.sum(Booking.final_fee), 0)).filter_by(status="completed").scalar()
    fines_collected = db.query(func.coalesce(func.sum(Challan.amount), 0)).filter_by(status="paid").scalar()
    fines_pending = db.query(func.coalesce(func.sum(Challan.amount), 0)).filter_by(status="unpaid").scalar()
    return {"lots": lots, "parking_revenue": round(float(parking_revenue), 2), "bookings_active": db.query(Booking).filter(Booking.status.in_(ACTIVE_BOOKING_STATUSES)).count(), "reports_by_category": categories, "reports_by_status": statuses, "reports_7d": trend, "fines_collected": round(float(fines_collected), 2), "fines_pending": round(float(fines_pending), 2), "hotspots": get_hotspots(db)[:10], "overstays": len(get_overstays(db)), "citizens": db.query(User).filter_by(role="citizen", active=True).count()}
