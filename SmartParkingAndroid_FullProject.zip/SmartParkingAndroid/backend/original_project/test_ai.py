import math
import pytest
from app.ai import classify_violation, detect_hotspots, distance_meters, dynamic_price, fake_report_risk, find_duplicate, hamming_distance, normalize_plate, occupancy_anomaly, occupancy_forecast, overstay_risk, priority_score, simhash

@pytest.mark.parametrize(("source", "expected"), [
    ("PY01AB1234", "PY01AB1234"),
    ("py 1 ab 1234", "PY01AB1234"),
    ("TN-09-BC-0001", "TN09BC0001"),
    ("KA 3 MNO 9876", "KA03MNO9876"),
    ("MH12A1234", "MH12A1234"),
])
def test_plate_normalization(source, expected):
    assert normalize_plate(source) == expected

@pytest.mark.parametrize("source", [None, "", "hello", "PY01AB12", "1234ABCD", "PY999AB1234"])
def test_invalid_plate(source):
    assert normalize_plate(source) is None

@pytest.mark.parametrize(("text", "expected"), [
    ("A car is blocking the road near traffic", "blocking_road"),
    ("Vehicle parked on footpath", "footpath_encroachment"),
    ("Car blocking the hospital ambulance entrance", "fire_hydrant_or_emergency"),
    ("Car in disabled accessible bay", "disabled_bay_misuse"),
    ("A vehicle in no parking zone", "no_parking_zone"),
    ("Two cars double parking in second row", "double_parking"),
    ("Old abandoned vehicle with flat tyre", "abandoned_vehicle"),
    ("Vehicle blocks the driveway gate", "gate_or_driveway_block"),
])
def test_classification_categories(text, expected):
    category, confidence = classify_violation(text)
    assert category == expected
    assert 0 <= confidence <= 1

@pytest.mark.parametrize("text", ["", "xyz", "something unclear", "vehicle noticed"])
def test_classifier_fallback(text):
    category, confidence = classify_violation(text)
    assert category == "illegal_parking"
    assert confidence == 0.3

def test_simhash_is_stable():
    assert simhash("car blocks the road") == simhash("car blocks the road")

def test_simhash_is_64_bit_hex():
    value = simhash("vehicle parked outside the gate")
    assert len(value) == 16
    assert int(value, 16) >= 0

def test_hamming_distance_equal_values():
    assert hamming_distance("ffff", "ffff") == 0

def test_hamming_distance_one_bit():
    assert hamming_distance("0", "1") == 1

def test_hamming_distance_invalid_input():
    assert hamming_distance("nothex", "0") == 64

def test_distance_zero():
    assert distance_meters(11.9, 79.8, 11.9, 79.8) == 0

def test_distance_positive():
    assert distance_meters(11.9, 79.8, 11.91, 79.8) > 100

def test_distance_symmetric():
    left = distance_meters(11.9, 79.8, 11.91, 79.81)
    right = distance_meters(11.91, 79.81, 11.9, 79.8)
    assert left == pytest.approx(right)

@pytest.mark.parametrize("demand", [0, 0.25, 0.5, 0.75, 1])
def test_dynamic_price_increases_with_demand(demand):
    assert dynamic_price(20, demand, demand, 12) >= dynamic_price(20, 0, 0, 12)

def test_dynamic_price_peak_surcharge():
    assert dynamic_price(20, 0.5, 0.5, 18) > dynamic_price(20, 0.5, 0.5, 12)

def test_dynamic_price_never_negative():
    assert dynamic_price(10, 0, 0, 3) > 0

def test_priority_score_clamps_to_range():
    assert 1 <= priority_score("fire_hydrant_or_emergency", "emergency ambulance", 0) <= 5

def test_priority_score_penalizes_high_risk():
    low = priority_score("blocking_road", "road blocked", 0.1)
    high = priority_score("blocking_road", "road blocked", 0.9)
    assert high <= low

def test_fake_risk_increases_for_duplicate():
    baseline = fake_report_risk(0, 0, True, 80, False)
    duplicate = fake_report_risk(0, 0, True, 80, True)
    assert duplicate > baseline

def test_fake_risk_stays_bounded():
    assert 0 <= fake_report_risk(0, 0, False, 2, True) <= 1

def test_anomaly_threshold():
    assert occupancy_anomaly(0.9, 0.2)
    assert not occupancy_anomaly(0.5, 0.4)

def test_overstay_risk_increases_near_end():
    assert overstay_risk(5, 0.2) > overstay_risk(60, 0.2)

def test_overstay_risk_increases_when_lot_busy():
    assert overstay_risk(60, 0.95) > overstay_risk(60, 0.2)

def test_hotspots_need_minimum_points():
    assert detect_hotspots([(11.9, 79.8, "blocking_road"), (11.9, 79.8, "blocking_road")]) == []

def test_hotspots_cluster_close_points():
    points = [(11.93, 79.83, "blocking_road"), (11.9301, 79.8301, "blocking_road"), (11.9302, 79.8302, "footpath_encroachment")]
    result = detect_hotspots(points)
    assert len(result) == 1
    assert result[0]["count"] == 3
    assert result[0]["severity"] == 2

def test_hotspots_ignore_far_points():
    points = [(0, 0, "illegal_parking"), (40, 40, "illegal_parking"), (-40, -40, "illegal_parking")]
    assert detect_hotspots(points) == []

def test_forecast_without_samples_uses_current():
    from datetime import datetime
    now = datetime(2026, 1, 1)
    assert occupancy_forecast([], now, now, 0.7) == 0.7

def test_forecast_without_samples_default():
    from datetime import datetime
    now = datetime(2026, 1, 1)
    assert occupancy_forecast([], now, now) == 0.5
