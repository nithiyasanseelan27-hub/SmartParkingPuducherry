import ipaddress
import re
from datetime import date, datetime
from urllib.parse import urlparse

EMAIL_PATTERN = re.compile(r"^[^\s@]+@[^\s@]+\.[^\s@]+$")
PHONE_PATTERN = re.compile(r"^[+0-9(). -]{0,30}$")
SAFE_IDENTIFIER_PATTERN = re.compile(r"^[A-Za-z0-9_.:-]{1,100}$")

class ValidationError(ValueError):
    pass

def normalize_email(value):
    result = str(value or "").strip().casefold()
    if len(result) > 254 or not EMAIL_PATTERN.fullmatch(result):
        raise ValidationError("Email address is invalid")
    return result

def normalize_name(value, minimum=1, maximum=100):
    result = " ".join(str(value or "").split())
    if len(result) < minimum or len(result) > maximum:
        raise ValidationError("Name length is outside the allowed range")
    if any(ord(character) < 32 for character in result):
        raise ValidationError("Name contains control characters")
    return result

def normalize_phone(value, required=False):
    result = " ".join(str(value or "").split())
    if required and not result:
        raise ValidationError("Phone number is required")
    if len(result) > 30 or not PHONE_PATTERN.fullmatch(result):
        raise ValidationError("Phone number contains unsupported characters")
    digits = sum(character.isdigit() for character in result)
    if required and digits < 7:
        raise ValidationError("Phone number must contain at least seven digits")
    return result

def validate_password_policy(value, minimum=10, maximum=128):
    password = str(value or "")
    if len(password) < minimum or len(password) > maximum:
        raise ValidationError("Password length is outside the allowed range")
    if password.isspace():
        raise ValidationError("Password cannot contain only whitespace")
    if "\x00" in password:
        raise ValidationError("Password contains an unsupported character")
    return password

def validate_latitude(value):
    try:
        result = float(value)
    except (TypeError, ValueError):
        raise ValidationError("Latitude must be numeric")
    if not -90 <= result <= 90:
        raise ValidationError("Latitude is outside the valid range")
    return result

def validate_longitude(value):
    try:
        result = float(value)
    except (TypeError, ValueError):
        raise ValidationError("Longitude must be numeric")
    if not -180 <= result <= 180:
        raise ValidationError("Longitude is outside the valid range")
    return result

def validate_positive_integer(value, field_name="Value", maximum=2_147_483_647):
    try:
        result = int(value)
    except (TypeError, ValueError):
        raise ValidationError(f"{field_name} must be an integer")
    if isinstance(value, float) and not value.is_integer():
        raise ValidationError(f"{field_name} must be an integer")
    if result <= 0 or result > maximum:
        raise ValidationError(f"{field_name} is outside the allowed range")
    return result

def validate_nonnegative_integer(value, field_name="Value", maximum=2_147_483_647):
    try:
        result = int(value)
    except (TypeError, ValueError):
        raise ValidationError(f"{field_name} must be an integer")
    if isinstance(value, float) and not value.is_integer():
        raise ValidationError(f"{field_name} must be an integer")
    if result < 0 or result > maximum:
        raise ValidationError(f"{field_name} is outside the allowed range")
    return result

def validate_money(value, minimum=0.01, maximum=1_000_000.0):
    try:
        result = float(value)
    except (TypeError, ValueError):
        raise ValidationError("Amount must be numeric")
    if result != result or result in (float("inf"), float("-inf")):
        raise ValidationError("Amount must be finite")
    if result < minimum or result > maximum:
        raise ValidationError("Amount is outside the allowed range")
    return round(result, 2)

def validate_date_range(start, end, maximum_days=366):
    if isinstance(start, datetime):
        start = start.date()
    if isinstance(end, datetime):
        end = end.date()
    if start is not None and not isinstance(start, date):
        raise ValidationError("Start date is invalid")
    if end is not None and not isinstance(end, date):
        raise ValidationError("End date is invalid")
    if start and end and end < start:
        raise ValidationError("End date precedes start date")
    if start and end and (end - start).days > maximum_days:
        raise ValidationError("Date range exceeds the allowed limit")
    return start, end

def validate_identifier(value):
    result = str(value or "")
    if not SAFE_IDENTIFIER_PATTERN.fullmatch(result):
        raise ValidationError("Identifier contains unsupported characters")
    return result

def validate_http_url(value, allow_localhost=False):
    parsed = urlparse(str(value or ""))
    if parsed.scheme not in {"http", "https"} or not parsed.hostname:
        raise ValidationError("URL must use HTTP or HTTPS")
    host = parsed.hostname.casefold()
    if host in {"localhost", "localhost.localdomain"} and not allow_localhost:
        raise ValidationError("Localhost URLs are not allowed")
    try:
        address = ipaddress.ip_address(host)
    except ValueError:
        address = None
    if address is not None and (address.is_private or address.is_loopback or address.is_link_local) and not allow_localhost:
        raise ValidationError("Private network URLs are not allowed")
    return value

def validate_content_type(value, allowed):
    normalized = str(value or "").split(";", 1)[0].strip().casefold()
    accepted = {item.casefold() for item in allowed}
    if normalized not in accepted:
        raise ValidationError("Content type is not allowed")
    return normalized

def validate_sort_order(value):
    normalized = str(value or "asc").strip().casefold()
    if normalized not in {"asc", "desc"}:
        raise ValidationError("Sort order must be asc or desc")
    return normalized

def validate_pagination(limit, offset, maximum_limit=200):
    page_limit = validate_positive_integer(limit, "Limit", maximum_limit)
    page_offset = validate_nonnegative_integer(offset, "Offset")
    return {"limit": page_limit, "offset": page_offset}

def normalize_search_query(value, maximum_length=120):
    query = " ".join(str(value or "").split())
    if len(query) > maximum_length:
        raise ValidationError("Search query is too long")
    if any(ord(character) < 32 for character in query):
        raise ValidationError("Search query contains control characters")
    return query

def validate_enum(value, allowed, field_name="Value", casefold=False):
    result = str(value or "").strip()
    if casefold:
        result = result.casefold()
        options = {str(item).casefold(): item for item in allowed}
        if result not in options:
            raise ValidationError(f"{field_name} is not supported")
        return options[result]
    if result not in allowed:
        raise ValidationError(f"{field_name} is not supported")
    return result

def validate_boolean(value, default=None):
    if value is None and default is not None:
        return bool(default)
    if isinstance(value, bool):
        return value
    if isinstance(value, int) and value in {0, 1}:
        return bool(value)
    if isinstance(value, str):
        normalized = value.strip().casefold()
        if normalized in {"true", "yes", "1", "on"}:
            return True
        if normalized in {"false", "no", "0", "off"}:
            return False
    raise ValidationError("Value must be a boolean")
