from app.main import app, main

if __name__ == "__main__":
    main()
