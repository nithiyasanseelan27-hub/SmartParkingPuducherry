from pydantic import BaseModel, ConfigDict, Field, field_validator
from .ai import normalize_plate

class RegisterInput(BaseModel):
    email: str = Field(min_length=5, max_length=254)
    name: str = Field(min_length=1, max_length=100)
    phone: str = Field(default="", max_length=30)
    password: str = Field(min_length=10, max_length=128)

    @field_validator("email")
    @classmethod
    def clean_email(cls, value):
        value = value.strip().casefold()
        if "@" not in value or value.startswith("@") or value.endswith("@"):
            raise ValueError("A valid email address is required")
        return value

    @field_validator("name")
    @classmethod
    def clean_name(cls, value):
        value = " ".join(value.split())
        if not value:
            raise ValueError("Name is required")
        return value

class LoginInput(BaseModel):
    email: str = Field(min_length=1, max_length=254)
    password: str = Field(min_length=1, max_length=128)

class VehicleInput(BaseModel):
    plate: str = Field(min_length=6, max_length=20)
    label: str = Field(default="", max_length=80)

    @field_validator("plate")
    @classmethod
    def clean_plate(cls, value):
        normalized = normalize_plate(value)
        if not normalized:
            raise ValueError("Invalid Indian vehicle registration number")
        return normalized

class LotInput(BaseModel):
    name: str = Field(min_length=2, max_length=120)
    address: str = Field(default="", max_length=250)
    latitude: float = Field(ge=-90, le=90)
    longitude: float = Field(ge=-180, le=180)
    capacity: int = Field(gt=0, le=100000)
    base_rate: float = Field(gt=0, le=100000)
    accessible_spaces: int = Field(default=0, ge=0)

class BookingInput(BaseModel):
    lot_id: int = Field(gt=0)
    vehicle_id: int = Field(gt=0)
    hours: float = Field(gt=0, le=24)
    start_in_minutes: int = Field(default=0, ge=0, le=1440)

class ReportInput(BaseModel):
    description: str = Field(min_length=5, max_length=1200)
    latitude: float = Field(ge=-90, le=90)
    longitude: float = Field(ge=-180, le=180)
    plate: str | None = Field(default=None, max_length=20)
    evidence_base64: str | None = Field(default=None, max_length=4_200_000)

    @field_validator("plate")
    @classmethod
    def clean_plate(cls, value):
        if value is None or not value.strip():
            return None
        normalized = normalize_plate(value)
        if not normalized:
            raise ValueError("Invalid vehicle registration number")
        return normalized

class ReviewInput(BaseModel):
    verdict: str
    note: str = Field(default="", max_length=500)

    @field_validator("verdict")
    @classmethod
    def clean_verdict(cls, value):
        if value not in {"verified", "rejected"}:
            raise ValueError("Verdict must be verified or rejected")
        return value

class ChallanInput(BaseModel):
    plate: str = Field(min_length=6, max_length=20)
    category: str = Field(min_length=2, max_length=60)
    report_id: int | None = Field(default=None, gt=0)
    amount: float | None = Field(default=None, gt=0, le=50000)

    @field_validator("plate")
    @classmethod
    def clean_plate(cls, value):
        normalized = normalize_plate(value)
        if not normalized:
            raise ValueError("Invalid vehicle registration number")
        return normalized

class SensorInput(BaseModel):
    occupied: int = Field(ge=0)

class OfficerInput(BaseModel):
    email: str = Field(min_length=5, max_length=254)
    name: str = Field(min_length=1, max_length=100)
    password: str = Field(min_length=12, max_length=128)

class PaymentInput(BaseModel):
    payment_reference: str = Field(min_length=6, max_length=100)

class ReadinessOutput(BaseModel):
    model_config = ConfigDict(extra="allow")
    status: str
