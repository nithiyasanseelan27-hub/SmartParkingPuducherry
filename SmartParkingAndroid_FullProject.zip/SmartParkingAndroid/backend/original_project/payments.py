import hashlib
import hmac
import json
import secrets
from dataclasses import dataclass
from datetime import datetime, timezone
from decimal import Decimal, ROUND_HALF_UP

@dataclass(frozen=True)
class PaymentIntent:
    reference: str
    amount_minor: int
    currency: str
    status: str
    created_at: str
    metadata: dict

@dataclass(frozen=True)
class PaymentResult:
    success: bool
    reference: str
    status: str
    amount_minor: int
    currency: str
    message: str

class PaymentError(Exception):
    pass

class PaymentProvider:
    def create_intent(self, amount_minor, currency, metadata=None, idempotency_key=None):
        raise NotImplementedError

    def verify_callback(self, payload, signature):
        raise NotImplementedError

    def refund(self, reference, amount_minor=None):
        raise NotImplementedError


def to_minor_units(amount, currency="INR"):
    decimal_amount = Decimal(str(amount))
    if not decimal_amount.is_finite() or decimal_amount <= 0:
        raise PaymentError("Payment amount must be a positive finite number")
    exponent = 0 if currency.upper() in {"JPY", "KRW"} else 2
    factor = Decimal(10) ** exponent
    return int((decimal_amount * factor).quantize(Decimal("1"), rounding=ROUND_HALF_UP))


def from_minor_units(amount_minor, currency="INR"):
    exponent = 0 if currency.upper() in {"JPY", "KRW"} else 2
    return Decimal(int(amount_minor)) / (Decimal(10) ** exponent)


def canonical_payload(payload):
    return json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()


def sign_callback(payload, secret):
    if not secret:
        raise PaymentError("Callback secret is required")
    return hmac.new(secret.encode(), canonical_payload(payload), hashlib.sha256).hexdigest()


def verify_callback_signature(payload, signature, secret):
    if not isinstance(signature, str) or not secret:
        return False
    expected = sign_callback(payload, secret)
    return hmac.compare_digest(expected, signature)

class DemoPaymentProvider(PaymentProvider):
    def __init__(self, callback_secret=None):
        self.callback_secret = callback_secret or secrets.token_urlsafe(32)
        self.intents = {}
        self.idempotency = {}

    def create_intent(self, amount_minor, currency="INR", metadata=None, idempotency_key=None):
        amount_minor = int(amount_minor)
        if amount_minor <= 0:
            raise PaymentError("Payment amount must be positive")
        currency = currency.upper()
        if len(currency) != 3 or not currency.isalpha():
            raise PaymentError("Currency must be a three-letter code")
        if idempotency_key and idempotency_key in self.idempotency:
            return self.intents[self.idempotency[idempotency_key]]
        reference = "DEMO-" + secrets.token_hex(12).upper()
        intent = PaymentIntent(reference=reference, amount_minor=amount_minor, currency=currency, status="created", created_at=datetime.now(timezone.utc).isoformat(), metadata=dict(metadata or {}))
        self.intents[reference] = intent
        if idempotency_key:
            self.idempotency[idempotency_key] = reference
        return intent

    def verify_callback(self, payload, signature):
        if not verify_callback_signature(payload, signature, self.callback_secret):
            raise PaymentError("Invalid callback signature")
        reference = payload.get("reference")
        intent = self.intents.get(reference)
        if not intent:
            raise PaymentError("Unknown payment reference")
        if int(payload.get("amount_minor", -1)) != intent.amount_minor:
            raise PaymentError("Callback amount mismatch")
        if str(payload.get("currency", "")).upper() != intent.currency:
            raise PaymentError("Callback currency mismatch")
        status = payload.get("status")
        if status not in {"succeeded", "failed"}:
            raise PaymentError("Unsupported payment status")
        updated = PaymentIntent(reference=intent.reference, amount_minor=intent.amount_minor, currency=intent.currency, status=status, created_at=intent.created_at, metadata=intent.metadata)
        self.intents[reference] = updated
        return PaymentResult(success=status == "succeeded", reference=reference, status=status, amount_minor=intent.amount_minor, currency=intent.currency, message="Demo callback processed")

    def refund(self, reference, amount_minor=None):
        intent = self.intents.get(reference)
        if not intent:
            raise PaymentError("Unknown payment reference")
        if intent.status != "succeeded":
            raise PaymentError("Only successful payments can be refunded")
        amount = intent.amount_minor if amount_minor is None else int(amount_minor)
        if amount <= 0 or amount > intent.amount_minor:
            raise PaymentError("Refund amount is outside the allowed range")
        refund_reference = "REF-" + secrets.token_hex(10).upper()
        return PaymentResult(success=True, reference=refund_reference, status="refunded", amount_minor=amount, currency=intent.currency, message="Demo refund recorded; no money was moved")


def validate_payment_reference(reference):
    value = str(reference or "").strip()
    if len(value) < 6 or len(value) > 100:
        raise PaymentError("Payment reference length is invalid")
    if any(ord(character) < 32 for character in value):
        raise PaymentError("Payment reference contains control characters")
    return value


def payment_reconciliation(expected, received, tolerance_minor=0):
    expected_amount = int(expected)
    received_amount = int(received)
    difference = received_amount - expected_amount
    return {"expected_minor": expected_amount, "received_minor": received_amount, "difference_minor": difference, "matched": abs(difference) <= int(tolerance_minor)}


def payment_status_transition(current, target):
    allowed = {"created": {"succeeded", "failed", "cancelled"}, "failed": {"created"}, "succeeded": {"refunded"}, "cancelled": set(), "refunded": set()}
    if target not in allowed.get(current, set()):
        raise PaymentError(f"Payment cannot transition from {current} to {target}")
    return target


def payment_audit_payload(reference, amount_minor, currency, status, actor_id=None):
    return {"reference": validate_payment_reference(reference), "amount_minor": int(amount_minor), "currency": currency.upper(), "status": status, "actor_id": actor_id}
