import os
from app.database import SessionLocal, create_schema
from app.models import ParkingLot, User
from app.security import hash_password

create_schema()
db = SessionLocal()
try:
    admin_email = os.environ.get("PARKING_ADMIN_EMAIL", "admin@puducherry.police").strip().casefold()
    admin_password = os.environ.get("PARKING_ADMIN_PASSWORD")
    if not admin_password:
        raise SystemExit("Set PARKING_ADMIN_PASSWORD to a strong password before seeding the admin account")
    admin = db.query(User).filter_by(email=admin_email).first()
    if not admin:
        admin = User(email=admin_email, name="System Administrator", password_hash=hash_password(admin_password), role="admin")
        db.add(admin)
    elif admin.role != "admin":
        raise SystemExit("The configured admin email belongs to a non-admin account")
    lots = [
        ("Promenade Beach Lot", "Near Promenade Beach", 11.9341, 79.8355, 80, 20.0, 4),
        ("Grand Bazaar Complex", "Market area parking", 11.9335, 79.8302, 120, 15.0, 4),
        ("White Town Heritage Lot", "White Town", 11.9330, 79.8330, 60, 25.0, 2),
        ("Railway Station Parking", "Near Puducherry railway station", 11.9190, 79.8230, 150, 10.0, 5),
        ("JIPMER Hospital Lot", "Near JIPMER", 11.9560, 79.7990, 200, 10.0, 8),
    ]
    for name, address, latitude, longitude, capacity, rate, accessible in lots:
        if not db.query(ParkingLot).filter_by(name=name).first():
            db.add(ParkingLot(name=name, address=address, latitude=latitude, longitude=longitude, capacity=capacity, base_rate=rate, accessible_spaces=accessible))
    db.commit()
    print(f"Admin account ready: {admin_email}")
    print(f"Parking lots available: {db.query(ParkingLot).count()}")
finally:
    db.close()
