import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool
from app.database import Base, get_db
from app.main import app
from app import main as main_module
from app.models import ParkingLot, User
from app.security import hash_password

@pytest.fixture()
def database():
    main_module._rate_hits.clear()
    main_module._revoked_tokens.clear()
    engine = create_engine("sqlite://", connect_args={"check_same_thread": False}, poolclass=StaticPool)
    TestingSession = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    Base.metadata.create_all(engine)
    session = TestingSession()
    session.add_all([
        User(id=1, email="citizen@example.com", name="Test Citizen", phone="", password_hash=hash_password("citizen-password-1"), role="citizen"),
        User(id=2, email="officer@example.com", name="Test Officer", phone="", password_hash=hash_password("officer-password-1"), role="officer"),
        User(id=3, email="admin@example.com", name="Test Admin", phone="", password_hash=hash_password("admin-password-123"), role="admin"),
    ])
    session.add_all([
        ParkingLot(id=1, name="Central Lot", address="Central", latitude=11.93, longitude=79.83, capacity=10, sensor_occupied=2, base_rate=20.0, accessible_spaces=1),
        ParkingLot(id=2, name="Beach Lot", address="Beach", latitude=11.94, longitude=79.84, capacity=20, sensor_occupied=5, base_rate=15.0, accessible_spaces=2),
    ])
    session.commit()
    session.close()
    def override_get_db():
        db = TestingSession()
        try:
            yield db
        finally:
            db.close()
    app.dependency_overrides[get_db] = override_get_db
    yield TestingSession
    app.dependency_overrides.clear()
    Base.metadata.drop_all(engine)
    engine.dispose()

@pytest.fixture()
def client(database):
    test_client = TestClient(app)
    yield test_client
    test_client.close()

@pytest.fixture()
def citizen_token(client):
    response = client.post("/api/auth/login", json={"email": "citizen@example.com", "password": "citizen-password-1"})
    assert response.status_code == 200
    return response.json()["token"]

@pytest.fixture()
def officer_token(client):
    response = client.post("/api/auth/login", json={"email": "officer@example.com", "password": "officer-password-1"})
    assert response.status_code == 200
    return response.json()["token"]

@pytest.fixture()
def admin_token(client):
    response = client.post("/api/auth/login", json={"email": "admin@example.com", "password": "admin-password-123"})
    assert response.status_code == 200
    return response.json()["token"]
