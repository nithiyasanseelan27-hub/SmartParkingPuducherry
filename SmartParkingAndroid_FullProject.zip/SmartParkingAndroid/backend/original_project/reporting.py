import re
from collections import Counter
from datetime import timedelta
from statistics import mean
from .database import utcnow
from .models import ViolationReport

SUSPICIOUS_PHRASES = ("ignore previous", "test report", "fake report", "just kidding", "not a real", "made up")
URGENCY_TERMS = ("ambulance", "hospital", "school", "fire", "emergency", "intersection", "blind", "wheelchair", "pedestrian")

def normalize_report_text(text):
    value = str(text or "")
    value = re.sub(r"\s+", " ", value).strip()
    return value

def report_text_quality(text):
    value = normalize_report_text(text)
    tokens = re.findall(r"[A-Za-z0-9]+", value)
    unique = set(token.casefold() for token in tokens)
    return {"length": len(value), "word_count": len(tokens), "unique_word_count": len(unique), "unique_ratio": round(len(unique) / len(tokens), 3) if tokens else 0.0, "has_location_words": bool(re.search(r"street|road|lane|junction|near|opposite|outside|entrance", value, re.I)), "has_urgency_words": any(term in value.casefold() for term in URGENCY_TERMS), "suspicious_phrase": any(term in value.casefold() for term in SUSPICIOUS_PHRASES)}

def explain_priority(category, description, risk_score):
    quality = report_text_quality(description)
    reasons = [f"Base severity for {category}"]
    if quality["has_urgency_words"]:
        reasons.append("Description includes a safety-sensitive location or urgency term")
    if risk_score >= 0.75:
        reasons.append("High risk score reduces automated priority")
    if quality["suspicious_phrase"]:
        reasons.append("Description includes a phrase that may warrant manual review")
    if not quality["has_location_words"]:
        reasons.append("Description may benefit from a clearer location reference")
    return {"reasons": reasons, "text_quality": quality, "manual_review_recommended": risk_score >= 0.6 or quality["suspicious_phrase"]}

def report_backlog(reports, now=None):
    now = now or utcnow()
    pending = [report for report in reports if report.status == "pending"]
    age_hours = [(now - report.created_at).total_seconds() / 3600 for report in pending]
    buckets = {"under_1h": 0, "1_to_6h": 0, "6_to_24h": 0, "1_to_3d": 0, "over_3d": 0}
    for hours in age_hours:
        if hours < 1:
            buckets["under_1h"] += 1
        elif hours < 6:
            buckets["1_to_6h"] += 1
        elif hours < 24:
            buckets["6_to_24h"] += 1
        elif hours < 72:
            buckets["1_to_3d"] += 1
        else:
            buckets["over_3d"] += 1
    return {"pending": len(pending), "average_age_hours": round(mean(age_hours), 2) if age_hours else None, "oldest_age_hours": round(max(age_hours), 2) if age_hours else None, "age_buckets": buckets, "priority_counts": dict(Counter(report.priority for report in pending))}

def review_efficiency(reports):
    reviewed = [report for report in reports if report.reviewed_at and report.created_at]
    durations = [(report.reviewed_at - report.created_at).total_seconds() / 60 for report in reviewed]
    return {"reviewed_count": len(reviewed), "average_minutes": round(mean(durations), 2) if durations else None, "within_1h": sum(duration <= 60 for duration in durations), "within_24h": sum(duration <= 1440 for duration in durations), "over_24h": sum(duration > 1440 for duration in durations)}

def duplicate_report_summary(reports):
    linked = [report for report in reports if report.duplicate_of is not None]
    root_ids = Counter(report.duplicate_of for report in linked)
    return {"reports": len(reports), "linked_duplicates": len(linked), "duplicate_rate": round(len(linked) / len(reports), 3) if reports else None, "most_referenced_reports": [{"report_id": report_id, "duplicate_count": count} for report_id, count in root_ids.most_common(10)]}

def report_category_matrix(reports):
    matrix = {}
    for report in reports:
        category = report.category
        status = report.status
        matrix.setdefault(category, {})
        matrix[category][status] = matrix[category].get(status, 0) + 1
    for category, counts in matrix.items():
        counts["total"] = sum(value for key, value in counts.items() if key != "total")
    return dict(sorted(matrix.items()))

def filter_reports(reports, status=None, category=None, minimum_priority=None, maximum_risk=None, since=None, until=None):
    result = []
    for report in reports:
        if status and report.status != status:
            continue
        if category and report.category != category:
            continue
        if minimum_priority is not None and report.priority < minimum_priority:
            continue
        if maximum_risk is not None and report.risk_score > maximum_risk:
            continue
        if since and report.created_at < since:
            continue
        if until and report.created_at > until:
            continue
        result.append(report)
    return sorted(result, key=lambda item: (-item.priority, item.created_at, item.id))

def calculate_report_sla(reports, target_hours=24, now=None):
    now = now or utcnow()
    resolved = [report for report in reports if report.status in {"verified", "rejected"} and report.reviewed_at]
    durations = [(report.reviewed_at - report.created_at).total_seconds() / 3600 for report in resolved]
    pending = [report for report in reports if report.status == "pending"]
    pending_overdue = sum((now - report.created_at).total_seconds() / 3600 > target_hours for report in pending)
    within_target = sum(duration <= target_hours for duration in durations)
    return {"target_hours": target_hours, "resolved": len(resolved), "resolved_within_target": within_target, "resolved_sla_rate": round(within_target / len(resolved), 3) if resolved else None, "pending": len(pending), "pending_overdue": pending_overdue}

def geographic_grid_key(latitude, longitude, precision=3):
    return f"{round(float(latitude), precision):.{precision}f},{round(float(longitude), precision):.{precision}f}"

def geographic_report_grid(reports, precision=3):
    groups = {}
    for report in reports:
        key = geographic_grid_key(report.latitude, report.longitude, precision)
        groups.setdefault(key, []).append(report)
    result = []
    for key, items in groups.items():
        result.append({"grid": key, "count": len(items), "pending": sum(item.status == "pending" for item in items), "top_category": Counter(item.category for item in items).most_common(1)[0][0]})
    return sorted(result, key=lambda item: (-item["count"], item["grid"]))

def report_risk_bands(reports):
    bands = {"low": 0, "medium": 0, "high": 0}
    for report in reports:
        if report.risk_score < 0.35:
            bands["low"] += 1
        elif report.risk_score < 0.7:
            bands["medium"] += 1
        else:
            bands["high"] += 1
    return bands

def category_trend(reports, days=7, now=None):
    now = now or utcnow()
    first = (now - timedelta(days=days - 1)).date()
    trend = {}
    for offset in range(days):
        trend[(first + timedelta(days=offset)).isoformat()] = Counter()
    for report in reports:
        key = report.created_at.date().isoformat()
        if key in trend:
            trend[key][report.category] += 1
    return {day: dict(counts) for day, counts in trend.items()}
