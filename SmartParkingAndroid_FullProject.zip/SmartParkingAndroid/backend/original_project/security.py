import base64
import hashlib
import hmac
import json
import os
import secrets
import time
from datetime import timedelta
from .config import TOKEN_TTL_SECONDS

_SIGNING_KEY = os.environ.get("PARKING_SIGNING_KEY", "")
if len(_SIGNING_KEY) < 32:
    _SIGNING_KEY = secrets.token_urlsafe(48)
_SIGNING_KEY = _SIGNING_KEY.encode()

def _b64(data):
    return base64.urlsafe_b64encode(data).decode().rstrip("=")

def _unb64(value):
    return base64.urlsafe_b64decode(value + "=" * (-len(value) % 4))

def hash_password(password, salt=None):
    if not isinstance(password, str) or len(password) < 10:
        raise ValueError("Password must contain at least 10 characters")
    salt_bytes = salt or os.urandom(16)
    digest = hashlib.scrypt(password.encode(), salt=salt_bytes, n=2**14, r=8, p=1, dklen=32)
    return f"scrypt${_b64(salt_bytes)}${_b64(digest)}"

def verify_password(password, encoded):
    try:
        algorithm, salt_text, digest_text = encoded.split("$", 2)
        if algorithm != "scrypt":
            return False
        actual = hashlib.scrypt(password.encode(), salt=_unb64(salt_text), n=2**14, r=8, p=1, dklen=32)
        return hmac.compare_digest(actual, _unb64(digest_text))
    except (ValueError, TypeError, AttributeError):
        return False

def issue_token(user_id, role, ttl=None):
    payload = {"sub": int(user_id), "role": role, "jti": secrets.token_hex(16), "exp": int(time.time()) + (ttl or TOKEN_TTL_SECONDS)}
    body = _b64(json.dumps(payload, separators=(",", ":"), sort_keys=True).encode())
    signature = _b64(hmac.new(_SIGNING_KEY, body.encode(), hashlib.sha256).digest())
    return f"{body}.{signature}"

def verify_token(token):
    try:
        body, signature = token.split(".", 1)
        expected = _b64(hmac.new(_SIGNING_KEY, body.encode(), hashlib.sha256).digest())
        if not hmac.compare_digest(signature, expected):
            return None
        payload = json.loads(_unb64(body))
        if int(payload.get("exp", 0)) <= int(time.time()):
            return None
        if not isinstance(payload.get("sub"), int) or payload.get("role") not in {"citizen", "officer", "admin"}:
            return None
        return payload
    except (ValueError, TypeError, KeyError, json.JSONDecodeError):
        return None

def blind_index(value, pepper=None):
    key = pepper or _SIGNING_KEY
    return hmac.new(key, value.strip().casefold().encode(), hashlib.sha256).hexdigest()

def digest_bytes(data):
    return hashlib.sha256(data).hexdigest()

def constant_time_equal(left, right):
    return hmac.compare_digest(str(left), str(right))
