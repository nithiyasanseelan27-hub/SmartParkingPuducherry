from collections import Counter, defaultdict
from datetime import timedelta
from statistics import mean, median, pstdev
from .database import utcnow
from .models import Booking, Challan, OccupancySample, ParkingLot, User, ViolationReport


def summarize_numbers(values):
    clean = [float(value) for value in values if value is not None]
    if not clean:
        return {"count": 0, "sum": 0.0, "mean": None, "median": None, "minimum": None, "maximum": None, "standard_deviation": None}
    return {"count": len(clean), "sum": round(sum(clean), 2), "mean": round(mean(clean), 2), "median": round(median(clean), 2), "minimum": min(clean), "maximum": max(clean), "standard_deviation": round(pstdev(clean), 2)}


def group_counts(rows, attribute):
    counts = Counter(getattr(row, attribute) for row in rows)
    return dict(sorted(counts.items(), key=lambda pair: (-pair[1], str(pair[0]))))


def daily_counts(rows, date_attribute, days=7, now=None):
    now = now or utcnow()
    first_day = (now - timedelta(days=max(0, days - 1))).date()
    counts = defaultdict(int)
    for row in rows:
        value = getattr(row, date_attribute)
        if value is not None and value.date() >= first_day and value.date() <= now.date():
            counts[value.date().isoformat()] += 1
    return { (first_day + timedelta(days=offset)).isoformat(): counts.get((first_day + timedelta(days=offset)).isoformat(), 0) for offset in range(days) }


def occupancy_distribution(samples):
    return summarize_numbers([sample.occupancy_ratio for sample in samples])


def occupancy_percentiles(samples):
    values = sorted(max(0.0, min(1.0, sample.occupancy_ratio)) for sample in samples)
    if not values:
        return {"p25": None, "p50": None, "p75": None, "p90": None}
    def percentile(p):
        position = (len(values) - 1) * p
        lower = int(position)
        upper = min(len(values) - 1, lower + 1)
        fraction = position - lower
        return round(values[lower] * (1 - fraction) + values[upper] * fraction, 3)
    return {"p25": percentile(0.25), "p50": percentile(0.5), "p75": percentile(0.75), "p90": percentile(0.9)}


def lot_performance(db, lot, days=30, now=None):
    now = now or utcnow()
    start = now - timedelta(days=days)
    bookings = db.query(Booking).filter(Booking.lot_id == lot.id, Booking.created_at >= start).all()
    samples = db.query(OccupancySample).filter(OccupancySample.lot_id == lot.id, OccupancySample.sampled_at >= start).all()
    completed = [booking for booking in bookings if booking.status == "completed"]
    active = [booking for booking in bookings if booking.status in {"reserved", "checked_in"}]
    fees = [booking.final_fee for booking in completed]
    duration_hours = [(booking.checked_out_at - booking.checked_in_at).total_seconds() / 3600 for booking in completed if booking.checked_out_at and booking.checked_in_at]
    return {"lot_id": lot.id, "lot_name": lot.name, "period_days": days, "booking_count": len(bookings), "completed_count": len(completed), "active_count": len(active), "completion_rate": round(len(completed) / len(bookings), 3) if bookings else None, "revenue": round(sum(fees), 2), "average_completed_fee": round(mean(fees), 2) if fees else None, "average_stay_hours": round(mean(duration_hours), 2) if duration_hours else None, "occupancy": occupancy_distribution(samples), "occupancy_percentiles": occupancy_percentiles(samples)}


def revenue_by_day(bookings, days=7, now=None):
    now = now or utcnow()
    first_day = (now - timedelta(days=days - 1)).date()
    result = { (first_day + timedelta(days=offset)).isoformat(): 0.0 for offset in range(days) }
    for booking in bookings:
        if booking.status != "completed" or not booking.checked_out_at:
            continue
        key = booking.checked_out_at.date().isoformat()
        if key in result:
            result[key] += booking.final_fee
    return {key: round(value, 2) for key, value in result.items()}


def fine_summary(challans):
    amounts = [challan.amount for challan in challans]
    by_status = defaultdict(float)
    by_category = defaultdict(float)
    for challan in challans:
        by_status[challan.status] += challan.amount
        by_category[challan.category] += challan.amount
    return {"count": len(challans), "amounts": summarize_numbers(amounts), "by_status": {key: round(value, 2) for key, value in sorted(by_status.items())}, "by_category": {key: round(value, 2) for key, value in sorted(by_category.items())}}


def citizen_activity(users, reports, bookings):
    report_counts = Counter(report.reporter_id for report in reports)
    booking_counts = Counter(booking.user_id for booking in bookings)
    result = []
    for user in users:
        if user.role != "citizen":
            continue
        result.append({"user_id": user.id, "name": user.name, "points": user.points, "reports_submitted": report_counts[user.id], "bookings_created": booking_counts[user.id]})
    return sorted(result, key=lambda item: (-item["points"], -item["reports_submitted"], item["user_id"]))


def report_resolution_metrics(reports):
    counts = Counter(report.status for report in reports)
    reviewed = [report for report in reports if report.reviewed_at and report.created_at]
    delays = [(report.reviewed_at - report.created_at).total_seconds() / 3600 for report in reviewed]
    total = len(reports)
    verified = counts["verified"]
    rejected = counts["rejected"]
    return {"total": total, "pending": counts["pending"], "verified": verified, "rejected": rejected, "resolution_rate": round((verified + rejected) / total, 3) if total else None, "acceptance_rate": round(verified / (verified + rejected), 3) if verified + rejected else None, "average_review_hours": round(mean(delays), 2) if delays else None, "review_delay": summarize_numbers(delays)}


def dashboard_extra_metrics(db, days=30):
    now = utcnow()
    start = now - timedelta(days=days)
    lots = db.query(ParkingLot).filter_by(active=True).all()
    reports = db.query(ViolationReport).filter(ViolationReport.created_at >= start).all()
    bookings = db.query(Booking).filter(Booking.created_at >= start).all()
    challans = db.query(Challan).filter(Challan.created_at >= start).all()
    samples = db.query(OccupancySample).filter(OccupancySample.sampled_at >= start).all()
    return {"period_days": days, "lots_active": len(lots), "reports": report_resolution_metrics(reports), "bookings": {"count": len(bookings), "by_status": group_counts(bookings, "status")}, "challans": fine_summary(challans), "occupancy": occupancy_distribution(samples), "occupancy_percentiles": occupancy_percentiles(samples), "reports_per_day": daily_counts(reports, "created_at", min(days, 90), now)}


def category_severity_summary(reports):
    groups = defaultdict(list)
    for report in reports:
        groups[report.category].append(report)
    output = {}
    for category, rows in groups.items():
        output[category] = {"count": len(rows), "average_priority": round(mean(row.priority for row in rows), 2), "average_risk": round(mean(row.risk_score for row in rows), 2), "pending": sum(row.status == "pending" for row in rows), "verified": sum(row.status == "verified" for row in rows), "rejected": sum(row.status == "rejected" for row in rows)}
    return dict(sorted(output.items(), key=lambda pair: (-pair[1]["count"], pair[0])))


def hourly_occupancy(samples):
    values = defaultdict(list)
    for sample in samples:
        local_hour = (sample.sampled_at.hour + 5) % 24
        values[local_hour].append(sample.occupancy_ratio)
    return {hour: round(mean(values[hour]), 3) for hour in range(24) if values.get(hour)}


def weekday_occupancy(samples):
    values = defaultdict(list)
    for sample in samples:
        local_weekday = (sample.sampled_at + timedelta(hours=5, minutes=30)).weekday()
        values[local_weekday].append(sample.occupancy_ratio)
    return {weekday: round(mean(values[weekday]), 3) for weekday in range(7) if values.get(weekday)}


def report_geographic_bounds(reports):
    if not reports:
        return None
    latitudes = [report.latitude for report in reports]
    longitudes = [report.longitude for report in reports]
    return {"south": min(latitudes), "north": max(latitudes), "west": min(longitudes), "east": max(longitudes), "center_latitude": mean(latitudes), "center_longitude": mean(longitudes)}


def report_duplicate_rate(reports):
    if not reports:
        return {"total": 0, "duplicates": 0, "rate": None}
    duplicates = sum(report.duplicate_of is not None for report in reports)
    return {"total": len(reports), "duplicates": duplicates, "rate": round(duplicates / len(reports), 3)}
