from datetime import datetime, timedelta
from decimal import Decimal
import pytest
from app.analytics import category_severity_summary, daily_counts, occupancy_percentiles, report_duplicate_rate, summarize_numbers
from app.exports import csv_response, export_filename, quote_spreadsheet_cell, safe_csv_response, validate_export_columns, validate_export_range
from app.maintenance import compact_notification_message, normalize_notification_batch
from app.parking_rules import BookingRuleError, booking_duration_hours, booking_state_transition, booking_windows_overlap, calculate_dynamic_rate, calculate_overstay_minutes, calculate_parking_fee, clamp_sensor_value, estimate_booking_cost, lot_is_full, normalize_capacity, parking_lot_capacity_status, validate_booking_duration, validate_time_window
from app.payments import DemoPaymentProvider, PaymentError, from_minor_units, payment_reconciliation, payment_status_transition, sign_callback, to_minor_units, validate_payment_reference, verify_callback_signature
from app.reporting import calculate_report_sla, duplicate_report_summary, explain_priority, geographic_grid_key, geographic_report_grid, normalize_report_text, report_category_matrix, report_risk_bands, report_text_quality

@pytest.mark.parametrize(("values", "expected"), [([], 0), ([1], 1), ([1, 2, 3], 3), ([0.2, 0.4], 2)])
def test_numeric_summary_count(values, expected):
    assert summarize_numbers(values)["count"] == expected

def test_numeric_summary_empty_values():
    result = summarize_numbers([])
    assert result["mean"] is None
    assert result["sum"] == 0

def test_numeric_summary_ignores_none():
    assert summarize_numbers([None, 1, 3])["mean"] == 2

def test_daily_counts_returns_all_days():
    now = datetime(2026, 10, 10)
    result = daily_counts([], "created_at", 7, now)
    assert len(result) == 7
    assert sum(result.values()) == 0

def test_occupancy_percentiles_empty():
    assert occupancy_percentiles([])["p50"] is None

def test_duplicate_rate_empty():
    assert report_duplicate_rate([])["rate"] is None

def test_duplicate_rate_no_duplicates():
    class Report:
        duplicate_of = None
    result = report_duplicate_rate([Report(), Report()])
    assert result["rate"] == 0

def test_category_severity_summary_empty():
    assert category_severity_summary([]) == {}

def test_csv_response_header_and_escaping():
    result = csv_response([{"name": "A, B", "amount": 2}], ["name", "amount"])
    assert "\"A, B\"" in result
    assert result.startswith("name,amount")

def test_export_filename_normalizes_name():
    assert export_filename("Police Reports").startswith("police_reports_")

def test_spreadsheet_formula_prefix_is_neutralized():
    assert quote_spreadsheet_cell("=1+1").startswith("'")

def test_spreadsheet_normal_text_is_preserved():
    assert quote_spreadsheet_cell("Normal text") == "Normal text"

def test_safe_csv_neutralizes_formula_cells():
    output = safe_csv_response([{"value": "@SUM(A1:A2)"}], ["value"])
    assert "'@SUM" in output

def test_export_columns_accept_allowed_fields():
    assert validate_export_columns(["id", "status"], {"id", "status"}) == ["id", "status"]

def test_export_columns_reject_unknown_fields():
    with pytest.raises(ValueError):
        validate_export_columns(["password"], {"id", "status"})

def test_export_columns_reject_duplicates():
    with pytest.raises(ValueError):
        validate_export_columns(["id", "id"], {"id"})

def test_export_range_accepts_valid_dates():
    assert validate_export_range(datetime(2026, 1, 1).date(), datetime(2026, 1, 2).date())

def test_export_range_rejects_reversed_dates():
    with pytest.raises(ValueError):
        validate_export_range(datetime(2026, 1, 2).date(), datetime(2026, 1, 1).date())

def test_export_range_rejects_large_range():
    with pytest.raises(ValueError):
        validate_export_range(datetime(2024, 1, 1).date(), datetime(2026, 1, 1).date())

def test_notification_message_compacts_whitespace():
    assert compact_notification_message("  hello  world \n test ") == "hello world test"

def test_notification_message_truncates():
    assert len(compact_notification_message("x" * 300, 20)) == 20

def test_notification_batch_removes_duplicates():
    assert normalize_notification_batch(["hello", "hello", "world"]) == ["hello", "world"]

def test_notification_batch_caps_items():
    result = normalize_notification_batch([str(index) for index in range(200)], 10)
    assert len(result) == 10

def test_booking_duration_accepts_valid_value():
    assert validate_booking_duration(2) == 2

@pytest.mark.parametrize("duration", [0, -1, 24.1, "invalid", None])
def test_booking_duration_rejects_invalid_value(duration):
    with pytest.raises(BookingRuleError):
        validate_booking_duration(duration)

def test_booking_windows_overlap_true():
    start = datetime(2026, 1, 1, 10)
    end = datetime(2026, 1, 1, 12)
    assert booking_windows_overlap(start, end, datetime(2026, 1, 1, 11), datetime(2026, 1, 1, 13))

def test_booking_windows_overlap_false_for_touching_windows():
    start = datetime(2026, 1, 1, 10)
    end = datetime(2026, 1, 1, 12)
    assert not booking_windows_overlap(start, end, end, datetime(2026, 1, 1, 14))

def test_booking_state_transition_valid():
    assert booking_state_transition("reserved", "checkin") == "checked_in"

def test_booking_state_transition_invalid():
    with pytest.raises(BookingRuleError):
        booking_state_transition("completed", "checkin")

def test_parking_fee_without_overstay():
    assert calculate_parking_fee(20, 2, 2) == 40

def test_parking_fee_with_overstay():
    assert calculate_parking_fee(20, 3, 2) == 70

def test_calculate_dynamic_rate_positive():
    assert calculate_dynamic_rate(20, 0.5, 0.5) > 0

def test_calculate_dynamic_rate_caps_ratios():
    assert calculate_dynamic_rate(20, 3, 4) == calculate_dynamic_rate(20, 1, 1)

def test_estimate_booking_cost_includes_tax():
    result = estimate_booking_cost(20, 2, tax_rate=0.1)
    assert result["subtotal"] == 40
    assert result["tax"] == 4
    assert result["total"] == 44

def test_estimate_booking_cost_applies_adjustment():
    assert estimate_booking_cost(10, 2, price_adjustment=1.5)["total"] == 30

def test_lot_is_full_at_capacity():
    class Lot:
        capacity = 5
        sensor_occupied = 3
    assert lot_is_full(Lot(), 2)

def test_lot_is_not_full_below_capacity():
    class Lot:
        capacity = 5
        sensor_occupied = 2
    assert not lot_is_full(Lot(), 2)

def test_clamp_sensor_value_caps_capacity():
    class Lot:
        capacity = 10
    assert clamp_sensor_value(Lot(), 30) == 10

def test_clamp_sensor_value_rejects_negative():
    class Lot:
        capacity = 10
    with pytest.raises(BookingRuleError):
        clamp_sensor_value(Lot(), -1)

def test_normalize_capacity_caps_sensor():
    assert normalize_capacity(10, 15) == (10, 10)

def test_normalize_capacity_rejects_zero():
    with pytest.raises(BookingRuleError):
        normalize_capacity(0, 0)

def test_capacity_status_ratio():
    class Lot:
        capacity = 10
        sensor_occupied = 4
    assert parking_lot_capacity_status(Lot())["ratio"] == 0.4

def test_overstay_minutes_zero_before_end():
    end = datetime(2026, 1, 1, 12)
    assert calculate_overstay_minutes(end, datetime(2026, 1, 1, 11)) == 0

def test_overstay_minutes_positive_after_end():
    end = datetime(2026, 1, 1, 12)
    assert calculate_overstay_minutes(end, datetime(2026, 1, 1, 13)) == 60

def test_booking_duration_hours():
    assert booking_duration_hours(datetime(2026, 1, 1, 10), datetime(2026, 1, 1, 12)) == 2

def test_booking_duration_hours_rejects_reversed():
    with pytest.raises(BookingRuleError):
        booking_duration_hours(datetime(2026, 1, 1, 12), datetime(2026, 1, 1, 10))

def test_to_minor_units_inr():
    assert to_minor_units("123.45", "INR") == 12345

def test_from_minor_units_inr():
    assert from_minor_units(12345, "INR") == Decimal("123.45")

def test_to_minor_units_zero_decimal_currency():
    assert to_minor_units("100", "JPY") == 100

def test_to_minor_units_rejects_invalid_amount():
    with pytest.raises(PaymentError):
        to_minor_units("-1")

def test_payment_callback_signature_round_trip():
    payload = {"reference": "PAY-12345", "amount_minor": 1000, "currency": "INR", "status": "succeeded"}
    signature = sign_callback(payload, "test-secret")
    assert verify_callback_signature(payload, signature, "test-secret")

def test_payment_callback_signature_rejects_change():
    payload = {"reference": "PAY-12345", "amount_minor": 1000, "currency": "INR", "status": "succeeded"}
    signature = sign_callback(payload, "test-secret")
    payload["amount_minor"] = 2000
    assert not verify_callback_signature(payload, signature, "test-secret")

def test_demo_payment_provider_idempotency():
    provider = DemoPaymentProvider("secret")
    first = provider.create_intent(1000, idempotency_key="key-1")
    second = provider.create_intent(1000, idempotency_key="key-1")
    assert first.reference == second.reference

def test_demo_payment_provider_callback_success():
    provider = DemoPaymentProvider("secret")
    intent = provider.create_intent(1000, "INR")
    payload = {"reference": intent.reference, "amount_minor": 1000, "currency": "INR", "status": "succeeded"}
    signature = sign_callback(payload, "secret")
    result = provider.verify_callback(payload, signature)
    assert result.success

def test_demo_payment_provider_rejects_bad_callback():
    provider = DemoPaymentProvider("secret")
    intent = provider.create_intent(1000, "INR")
    payload = {"reference": intent.reference, "amount_minor": 1000, "currency": "INR", "status": "succeeded"}
    with pytest.raises(PaymentError):
        provider.verify_callback(payload, "bad")

def test_demo_payment_provider_rejects_amount_mismatch():
    provider = DemoPaymentProvider("secret")
    intent = provider.create_intent(1000, "INR")
    payload = {"reference": intent.reference, "amount_minor": 1001, "currency": "INR", "status": "succeeded"}
    with pytest.raises(PaymentError):
        provider.verify_callback(payload, sign_callback(payload, "secret"))

def test_demo_payment_provider_refund_requires_success():
    provider = DemoPaymentProvider("secret")
    intent = provider.create_intent(1000, "INR")
    with pytest.raises(PaymentError):
        provider.refund(intent.reference)

def test_demo_payment_provider_refund_success():
    provider = DemoPaymentProvider("secret")
    intent = provider.create_intent(1000, "INR")
    payload = {"reference": intent.reference, "amount_minor": 1000, "currency": "INR", "status": "succeeded"}
    provider.verify_callback(payload, sign_callback(payload, "secret"))
    assert provider.refund(intent.reference).status == "refunded"

def test_payment_status_transition_valid():
    assert payment_status_transition("created", "succeeded") == "succeeded"

def test_payment_status_transition_invalid():
    with pytest.raises(PaymentError):
        payment_status_transition("refunded", "succeeded")

def test_payment_reconciliation_match():
    assert payment_reconciliation(1000, 1000)["matched"]

def test_payment_reconciliation_mismatch():
    assert not payment_reconciliation(1000, 900)["matched"]

def test_payment_reference_trims_spaces():
    assert validate_payment_reference(" PAY-12345 ") == "PAY-12345"

def test_payment_reference_rejects_short_value():
    with pytest.raises(PaymentError):
        validate_payment_reference("abc")

def test_normalize_report_text():
    assert normalize_report_text("  car  blocks\n road ") == "car blocks road"

def test_report_text_quality_counts_words():
    result = report_text_quality("Car blocks the road near school")
    assert result["word_count"] == 6
    assert result["has_urgency_words"]

def test_report_text_quality_detects_suspicious_phrase():
    assert report_text_quality("This is a fake report") ["suspicious_phrase"]

def test_explain_priority_returns_reasons():
    result = explain_priority("blocking_road", "Ambulance blocked near hospital", 0.1)
    assert result["reasons"]
    assert result["text_quality"]["has_urgency_words"]

def test_duplicate_report_summary_empty():
    assert duplicate_report_summary([])["reports"] == 0

def test_report_category_matrix_empty():
    assert report_category_matrix([]) == {}

def test_report_risk_bands_empty():
    assert report_risk_bands([]) == {"low": 0, "medium": 0, "high": 0}

def test_geographic_grid_key_rounds_coordinates():
    assert geographic_grid_key(11.9332, 79.8321) == "11.933,79.832"

def test_geographic_report_grid_empty():
    assert geographic_report_grid([]) == []

def test_report_sla_empty():
    result = calculate_report_sla([])
    assert result["resolved"] == 0
    assert result["resolved_sla_rate"] is None

def test_validate_time_window_accepts_future_window():
    now = datetime(2026, 1, 1, 10)
    assert validate_time_window(now + timedelta(minutes=5), now + timedelta(hours=2), now)

def test_validate_time_window_rejects_end_before_start():
    now = datetime(2026, 1, 1, 10)
    with pytest.raises(BookingRuleError):
        validate_time_window(now + timedelta(hours=2), now + timedelta(hours=1), now)

def test_validate_time_window_rejects_too_far_ahead():
    now = datetime(2026, 1, 1, 10)
    with pytest.raises(BookingRuleError):
        validate_time_window(now + timedelta(hours=30), now + timedelta(hours=31), now)
