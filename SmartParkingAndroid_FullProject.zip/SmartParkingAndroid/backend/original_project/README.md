# Puducherry Smart Parking and Traffic Enforcement

This is a rebuilt and hardened Python implementation based on the project described in `Smart_Parking_Project.pdf`. The PDF's printed source has line-wrap and syntax damage in several listings, so the application in `app/` is a clean reconstruction rather than a byte-for-byte extraction. The original PDF text extraction is preserved at `original_extracted/pdf_text_extraction.txt` for reference.

## Features

- Citizen registration, password hashing, login lockout and bearer-token authentication
- Role-based access for citizens, officers and administrators
- Vehicle registration and Indian plate normalization
- Parking lot management, occupancy sensors, forecasts, dynamic pricing and recommendations
- Time-window booking, check-in, check-out and overstay fees
- Citizen violation reports, evidence size/type checks, classification, duplicate hints and priority scoring
- Police report review, reward points, challan issuance and payment-reference recording
- Plate lookup, notifications, hotspots, dashboard analytics and tamper-evident audit verification
- Request rate limits, payload limits and security headers

## Important limitations

This reconstruction does not claim end-to-end encrypted evidence. Evidence is stored in the application database as base64 data and should only be used with test data until a reviewed encryption/key-management design is implemented. Payment is simulated by recording a payment reference; it does not move money or connect to a payment gateway. The offline AI utilities are heuristics, not trained models. Seeded parking coordinates are approximate and must be verified.

## Run

Python 3.10 or later is recommended.

1. Create and activate a virtual environment.
2. Install dependencies with `python -m pip install -r requirements.txt`.
3. Set `PARKING_ADMIN_PASSWORD` to a strong password and run `python tools/seed_demo.py` to create the admin and demo parking lots.
4. Start with `python -m app.main`.
5. Open `http://127.0.0.1:8000`.

For a one-command setup, run `run.sh` on Linux/macOS or `run.bat` on Windows. Set `PARKING_SIGNING_KEY` to a persistent secret of at least 32 characters before production use. The generated fallback signing key is process-local and will invalidate tokens after restart.

## Test

Run `pytest -q` from this directory. Tests use an isolated temporary SQLite database and do not require the production database.

## API

OpenAPI docs are disabled by default. Set `PARKING_DEBUG=1` for local development to enable `/docs`.

Key routes include `/api/auth/register`, `/api/auth/login`, `/api/vehicles`, `/api/lots`, `/api/bookings`, `/api/reports`, `/api/police/reports`, `/api/police/challans`, `/api/admin/lots`, and `/api/dashboard`.
