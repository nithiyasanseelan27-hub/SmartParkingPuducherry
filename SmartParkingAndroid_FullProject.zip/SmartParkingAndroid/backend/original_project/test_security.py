import pytest
from app.security import blind_index, hash_password, issue_token, verify_password, verify_token

def test_password_hash_uses_scrypt():
    encoded = hash_password("a-long-test-password")
    assert encoded.startswith("scrypt$")

def test_password_hash_salts_are_unique():
    first = hash_password("a-long-test-password")
    second = hash_password("a-long-test-password")
    assert first != second

def test_password_verification_accepts_correct_password():
    encoded = hash_password("a-long-test-password")
    assert verify_password("a-long-test-password", encoded)

def test_password_verification_rejects_wrong_password():
    encoded = hash_password("a-long-test-password")
    assert not verify_password("another-long-password", encoded)

@pytest.mark.parametrize("value", ["", "short", "123456789"])
def test_password_hash_rejects_short_passwords(value):
    with pytest.raises(ValueError):
        hash_password(value)

def test_password_verification_handles_malformed_hash():
    assert not verify_password("anything-long", "invalid")

def test_token_round_trip():
    token = issue_token(42, "citizen")
    payload = verify_token(token)
    assert payload["sub"] == 42
    assert payload["role"] == "citizen"

def test_token_rejects_tampering():
    token = issue_token(42, "citizen")
    body, signature = token.split(".")
    altered = body[:-1] + ("A" if body[-1] != "A" else "B")
    assert verify_token(altered + "." + signature) is None

def test_token_rejects_expired_token():
    assert verify_token(issue_token(42, "citizen", ttl=-1)) is None

def test_token_rejects_unknown_role():
    token = issue_token(42, "citizen")
    body, signature = token.split(".")
    assert verify_token(body + ".wrong") is None

def test_blind_index_is_deterministic():
    assert blind_index("test@example.com", b"x" * 32) == blind_index("test@example.com", b"x" * 32)

def test_blind_index_normalizes_case_and_spaces():
    key = b"x" * 32
    assert blind_index(" Test@Example.com ", key) == blind_index("test@example.com", key)

def test_blind_index_changes_with_key():
    assert blind_index("test@example.com", b"x" * 32) != blind_index("test@example.com", b"y" * 32)
