from datetime import date, datetime
import pytest
from app.validation import ValidationError, normalize_email, normalize_name, normalize_phone, normalize_search_query, validate_boolean, validate_content_type, validate_date_range, validate_enum, validate_http_url, validate_identifier, validate_latitude, validate_longitude, validate_money, validate_nonnegative_integer, validate_pagination, validate_password_policy, validate_positive_integer, validate_sort_order

def test_normalize_email_lowercases():
    assert normalize_email(" User@Example.COM ") == "user@example.com"

def test_normalize_email_rejects_invalid():
    with pytest.raises(ValidationError):
        normalize_email("not-an-email")

def test_normalize_name_collapses_whitespace():
    assert normalize_name("  Test   User ") == "Test User"

def test_normalize_name_rejects_empty():
    with pytest.raises(ValidationError):
        normalize_name("  ")

def test_normalize_phone_allows_formatted_number():
    assert normalize_phone("+91 98765-43210", required=True)

def test_normalize_phone_rejects_letters():
    with pytest.raises(ValidationError):
        normalize_phone("123ABC456", required=True)

def test_password_policy_accepts_long_password():
    assert validate_password_policy("a-secure-password") == "a-secure-password"

def test_password_policy_rejects_whitespace_only():
    with pytest.raises(ValidationError):
        validate_password_policy("           ")

def test_validate_latitude_accepts_boundary():
    assert validate_latitude(90) == 90

def test_validate_latitude_rejects_outside_range():
    with pytest.raises(ValidationError):
        validate_latitude(91)

def test_validate_longitude_accepts_boundary():
    assert validate_longitude(-180) == -180

def test_validate_longitude_rejects_outside_range():
    with pytest.raises(ValidationError):
        validate_longitude(181)

def test_positive_integer_accepts_integer_string():
    assert validate_positive_integer("5") == 5

def test_positive_integer_rejects_fraction():
    with pytest.raises(ValidationError):
        validate_positive_integer(1.5)

def test_positive_integer_rejects_zero():
    with pytest.raises(ValidationError):
        validate_positive_integer(0)

def test_nonnegative_integer_accepts_zero():
    assert validate_nonnegative_integer(0) == 0

def test_nonnegative_integer_rejects_negative():
    with pytest.raises(ValidationError):
        validate_nonnegative_integer(-1)

def test_money_rounds_to_cents():
    assert validate_money("12.345") == 12.35

def test_money_rejects_infinity():
    with pytest.raises(ValidationError):
        validate_money(float("inf"))

def test_date_range_accepts_datetimes():
    result = validate_date_range(datetime(2026, 1, 1), datetime(2026, 1, 2))
    assert result == (date(2026, 1, 1), date(2026, 1, 2))

def test_date_range_rejects_reversed():
    with pytest.raises(ValidationError):
        validate_date_range(date(2026, 1, 2), date(2026, 1, 1))

def test_identifier_accepts_safe_value():
    assert validate_identifier("booking:123") == "booking:123"

def test_identifier_rejects_spaces():
    with pytest.raises(ValidationError):
        validate_identifier("bad identifier")

def test_http_url_accepts_public_https():
    assert validate_http_url("https://example.com") == "https://example.com"

def test_http_url_rejects_ftp():
    with pytest.raises(ValidationError):
        validate_http_url("ftp://example.com")

def test_http_url_rejects_private_ip():
    with pytest.raises(ValidationError):
        validate_http_url("http://192.168.1.1")

def test_content_type_ignores_parameters():
    assert validate_content_type("image/png; charset=binary", {"image/png"}) == "image/png"

def test_content_type_rejects_unknown():
    with pytest.raises(ValidationError):
        validate_content_type("application/exe", {"image/png"})

def test_sort_order_defaults_to_ascending():
    assert validate_sort_order(None) == "asc"

def test_sort_order_rejects_unknown():
    with pytest.raises(ValidationError):
        validate_sort_order("sideways")

def test_pagination_returns_bounded_values():
    assert validate_pagination(20, 10) == {"limit": 20, "offset": 10}

def test_pagination_rejects_excessive_limit():
    with pytest.raises(ValidationError):
        validate_pagination(500, 0)

def test_search_query_compacts_whitespace():
    assert normalize_search_query("  beach   lot ") == "beach lot"

def test_search_query_rejects_too_long():
    with pytest.raises(ValidationError):
        normalize_search_query("x" * 121)

def test_enum_can_casefold():
    assert validate_enum("CITIZEN", {"citizen", "officer"}, casefold=True) == "citizen"

def test_enum_rejects_unknown():
    with pytest.raises(ValidationError):
        validate_enum("root", {"citizen", "officer"})

@pytest.mark.parametrize(("value", "expected"), [(True, True), (False, False), (1, True), (0, False), ("yes", True), ("no", False), ("ON", True), ("off", False)])
def test_boolean_supported_values(value, expected):
    assert validate_boolean(value) is expected

def test_boolean_uses_default_for_none():
    assert validate_boolean(None, default=True)

def test_boolean_rejects_unknown_string():
    with pytest.raises(ValidationError):
        validate_boolean("perhaps")
