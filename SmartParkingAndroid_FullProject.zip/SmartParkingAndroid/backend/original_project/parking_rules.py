from datetime import timedelta
from .database import utcnow
from .models import Booking, ParkingLot

ACTIVE_STATES = {"reserved", "checked_in"}
TERMINAL_STATES = {"completed", "cancelled", "expired"}

class BookingRuleError(ValueError):
    pass

def validate_booking_duration(hours, minimum=0.25, maximum=24.0):
    try:
        duration = float(hours)
    except (TypeError, ValueError):
        raise BookingRuleError("Duration must be numeric")
    if duration < minimum:
        raise BookingRuleError(f"Duration must be at least {minimum} hours")
    if duration > maximum:
        raise BookingRuleError(f"Duration cannot exceed {maximum} hours")
    return duration

def validate_time_window(starts_at, ends_at, now=None, maximum_advance_hours=24):
    now = now or utcnow()
    if ends_at <= starts_at:
        raise BookingRuleError("End time must be later than start time")
    if starts_at < now - timedelta(minutes=15):
        raise BookingRuleError("Bookings cannot start in the past")
    if starts_at > now + timedelta(hours=maximum_advance_hours):
        raise BookingRuleError("Booking start is too far in the future")
    if ends_at - starts_at > timedelta(hours=24):
        raise BookingRuleError("Booking cannot exceed 24 hours")
    return True

def booking_windows_overlap(first_start, first_end, second_start, second_end):
    return first_start < second_end and first_end > second_start

def count_overlapping_bookings(db, lot_id, starts_at, ends_at):
    return db.query(Booking).filter(Booking.lot_id == lot_id, Booking.status.in_(ACTIVE_STATES), Booking.starts_at < ends_at, Booking.ends_at > starts_at).count()

def available_capacity(db, lot, starts_at, ends_at):
    overlap_count = count_overlapping_bookings(db, lot.id, starts_at, ends_at)
    sensor_occupied = max(0, min(lot.capacity, lot.sensor_occupied))
    return max(0, lot.capacity - sensor_occupied - overlap_count)

def assert_capacity(db, lot, starts_at, ends_at):
    if not lot.active:
        raise BookingRuleError("Parking lot is not active")
    free = available_capacity(db, lot, starts_at, ends_at)
    if free <= 0:
        raise BookingRuleError("No spaces available for the requested time")
    return free

def calculate_parking_fee(rate_per_hour, used_hours, booked_hours, overstay_multiplier=1.5, minimum_hours=0.25):
    rate = float(rate_per_hour)
    used = max(float(minimum_hours), float(used_hours))
    booked = max(0.0, float(booked_hours))
    regular_hours = min(used, booked)
    excess_hours = max(0.0, used - booked)
    return round(rate * regular_hours + rate * overstay_multiplier * excess_hours, 2)

def booking_state_transition(current, action):
    transitions = {("reserved", "checkin"): "checked_in", ("reserved", "cancel"): "cancelled", ("checked_in", "checkout"): "completed"}
    result = transitions.get((current, action))
    if result is None:
        raise BookingRuleError(f"Action {action} is not valid for booking state {current}")
    return result

def checkin_is_allowed(booking, now=None, early_minutes=15):
    now = now or utcnow()
    return booking.status == "reserved" and now >= booking.starts_at - timedelta(minutes=early_minutes) and now < booking.ends_at

def should_expire_booking(booking, now=None, grace_minutes=30):
    now = now or utcnow()
    return booking.status == "reserved" and booking.ends_at + timedelta(minutes=grace_minutes) < now

def lot_is_full(lot, active_booking_count=0):
    return max(0, lot.sensor_occupied) + max(0, active_booking_count) >= lot.capacity

def clamp_sensor_value(lot, occupied):
    value = int(occupied)
    if value < 0:
        raise BookingRuleError("Occupied count cannot be negative")
    return min(value, lot.capacity)

def calculate_dynamic_rate(base_rate, occupancy_ratio, forecast_ratio, rush_hour=False, minimum_multiplier=0.8, maximum_multiplier=2.2):
    ratio = max(0.0, min(1.0, 0.6 * occupancy_ratio + 0.4 * forecast_ratio))
    multiplier = 0.8 + 1.4 * ratio ** 2 + (0.1 if rush_hour else 0)
    multiplier = max(minimum_multiplier, min(maximum_multiplier, multiplier))
    return round(float(base_rate) * multiplier, 2)

def lot_can_support_accessible_booking(lot, already_reserved=0):
    return lot.accessible_spaces > max(0, already_reserved)

def summarize_booking_statuses(bookings):
    counts = {"reserved": 0, "checked_in": 0, "completed": 0, "cancelled": 0, "expired": 0, "other": 0}
    for booking in bookings:
        key = booking.status if booking.status in counts else "other"
        counts[key] += 1
    return counts

def find_booking_conflicts(bookings, starts_at, ends_at, vehicle_id=None):
    conflicts = []
    for booking in bookings:
        if booking.status not in ACTIVE_STATES:
            continue
        if vehicle_id is not None and booking.vehicle_id == vehicle_id:
            conflicts.append(booking)
            continue
        if booking_windows_overlap(starts_at, ends_at, booking.starts_at, booking.ends_at):
            conflicts.append(booking)
    return conflicts

def estimate_booking_cost(rate_per_hour, hours, price_adjustment=1.0, tax_rate=0.0, fixed_fee=0.0):
    rate = float(rate_per_hour)
    duration = validate_booking_duration(hours)
    adjustment = max(0.0, float(price_adjustment))
    tax = max(0.0, min(1.0, float(tax_rate)))
    subtotal = rate * duration * adjustment + max(0.0, float(fixed_fee))
    return {"subtotal": round(subtotal, 2), "tax": round(subtotal * tax, 2), "total": round(subtotal * (1 + tax), 2)}

def normalize_capacity(capacity, sensor_occupied):
    cap = int(capacity)
    occupied = int(sensor_occupied)
    if cap <= 0:
        raise BookingRuleError("Capacity must be positive")
    return cap, max(0, min(cap, occupied))

def accessible_capacity_summary(lot):
    total = max(0, int(lot.accessible_spaces))
    return {"total": total, "capacity": lot.capacity, "valid": total <= lot.capacity, "share": round(total / lot.capacity, 3) if lot.capacity else 0.0}

def calculate_overstay_minutes(ends_at, now=None):
    now = now or utcnow()
    return max(0, int((now - ends_at).total_seconds() // 60))

def booking_duration_hours(starts_at, ends_at):
    if ends_at < starts_at:
        raise BookingRuleError("End time cannot precede start time")
    return (ends_at - starts_at).total_seconds() / 3600

def parking_lot_capacity_status(lot, checked_in_count=0):
    occupied = min(lot.capacity, max(0, lot.sensor_occupied) + max(0, checked_in_count))
    free = max(0, lot.capacity - occupied)
    return {"capacity": lot.capacity, "occupied": occupied, "free": free, "ratio": round(occupied / lot.capacity, 3) if lot.capacity else 0.0, "full": free == 0}
