import csv
import io
import json
from datetime import date, datetime
from .models import Booking, Challan, ParkingLot, User, Vehicle, ViolationReport


def csv_response(rows, columns):
    buffer = io.StringIO(newline="")
    writer = csv.DictWriter(buffer, fieldnames=columns, extrasaction="ignore", lineterminator="\n")
    writer.writeheader()
    for row in rows:
        writer.writerow({column: _csv_value(row.get(column)) for column in columns})
    return buffer.getvalue()


def _csv_value(value):
    if isinstance(value, (datetime, date)):
        return value.isoformat()
    if isinstance(value, (dict, list, tuple)):
        return json.dumps(value, ensure_ascii=False, sort_keys=True)
    if value is None:
        return ""
    return str(value)


def users_export(users, include_phone=False):
    fields = ["id", "email", "name", "role", "points", "active", "created_at"]
    if include_phone:
        fields.insert(3, "phone")
    rows = []
    for user in users:
        row = {"id": user.id, "email": user.email, "name": user.name, "phone": user.phone, "role": user.role, "points": user.points, "active": user.active, "created_at": user.created_at}
        rows.append(row)
    return csv_response(rows, fields)


def bookings_export(bookings):
    fields = ["id", "user_id", "lot_id", "vehicle_id", "starts_at", "ends_at", "checked_in_at", "checked_out_at", "rate_per_hour", "estimated_fee", "final_fee", "status", "created_at"]
    rows = []
    for booking in bookings:
        rows.append({field: getattr(booking, field) for field in fields})
    return csv_response(rows, fields)


def reports_export(reports, include_coordinates=False, include_description=False):
    fields = ["id", "reporter_id", "category", "confidence", "priority", "risk_score", "status", "duplicate_of", "evidence_sha256", "created_at", "reviewed_at"]
    if include_coordinates:
        fields.extend(["latitude", "longitude"])
    if include_description:
        fields.append("description")
    rows = []
    for report in reports:
        rows.append({field: getattr(report, field) for field in fields})
    return csv_response(rows, fields)


def challans_export(challans):
    fields = ["id", "vehicle_id", "plate", "report_id", "issued_by", "category", "amount", "status", "payment_reference", "created_at", "paid_at"]
    rows = [{field: getattr(challan, field) for field in fields} for challan in challans]
    return csv_response(rows, fields)


def lots_export(lots):
    fields = ["id", "name", "address", "latitude", "longitude", "capacity", "sensor_occupied", "base_rate", "accessible_spaces", "active", "created_at"]
    rows = [{field: getattr(lot, field) for field in fields} for lot in lots]
    return csv_response(rows, fields)


def build_json_export(entity_type, rows, fields):
    output = []
    for row in rows:
        item = {field: getattr(row, field, None) for field in fields}
        output.append(item)
    return {"entity_type": entity_type, "count": len(output), "records": output}


def validate_export_columns(columns, allowed, maximum=30):
    if not columns:
        raise ValueError("At least one export column is required")
    if len(columns) > maximum:
        raise ValueError("Too many export columns")
    unknown = sorted(set(columns) - set(allowed))
    if unknown:
        raise ValueError("Unsupported export columns: " + ", ".join(unknown))
    if len(set(columns)) != len(columns):
        raise ValueError("Duplicate export columns are not allowed")
    return list(columns)


def quote_spreadsheet_cell(value):
    text = _csv_value(value)
    if text.startswith(("=", "+", "-", "@", "\t", "\r")):
        return "'" + text
    return text


def safe_csv_response(rows, columns):
    safe_rows = []
    for row in rows:
        safe_rows.append({key: quote_spreadsheet_cell(value) for key, value in row.items()})
    return csv_response(safe_rows, columns)


def export_filename(prefix, extension="csv", today=None):
    today = today or date.today()
    clean_prefix = "".join(character.lower() if character.isalnum() else "_" for character in prefix).strip("_") or "export"
    clean_extension = "".join(character for character in extension.lower() if character.isalnum()) or "csv"
    return f"{clean_prefix}_{today.isoformat()}.{clean_extension}"


def validate_export_range(start, end, maximum_days=366):
    if start and end and end < start:
        raise ValueError("End date must not precede start date")
    if start and end and (end - start).days > maximum_days:
        raise ValueError("Export date range is too large")
    return True
