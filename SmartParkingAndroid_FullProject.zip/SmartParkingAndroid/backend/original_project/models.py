from sqlalchemy import Boolean, Column, DateTime, Float, ForeignKey, Index, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import relationship
from .database import Base, utcnow

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True)
    email = Column(String(254), nullable=False, unique=True, index=True)
    name = Column(String(100), nullable=False)
    phone = Column(String(30), nullable=False, default="")
    password_hash = Column(String(300), nullable=False)
    role = Column(String(20), nullable=False, default="citizen", index=True)
    points = Column(Integer, nullable=False, default=0)
    failed_logins = Column(Integer, nullable=False, default=0)
    locked_until = Column(DateTime)
    active = Column(Boolean, nullable=False, default=True)
    created_at = Column(DateTime, nullable=False, default=utcnow)
    vehicles = relationship("Vehicle", back_populates="owner")

class Vehicle(Base):
    __tablename__ = "vehicles"
    id = Column(Integer, primary_key=True)
    owner_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    plate = Column(String(16), nullable=False, unique=True, index=True)
    label = Column(String(80), nullable=False, default="")
    created_at = Column(DateTime, nullable=False, default=utcnow)
    owner = relationship("User", back_populates="vehicles")

class ParkingLot(Base):
    __tablename__ = "parking_lots"
    id = Column(Integer, primary_key=True)
    name = Column(String(120), nullable=False, unique=True)
    address = Column(String(250), nullable=False, default="")
    latitude = Column(Float, nullable=False)
    longitude = Column(Float, nullable=False)
    capacity = Column(Integer, nullable=False)
    sensor_occupied = Column(Integer, nullable=False, default=0)
    base_rate = Column(Float, nullable=False)
    accessible_spaces = Column(Integer, nullable=False, default=0)
    active = Column(Boolean, nullable=False, default=True)
    created_at = Column(DateTime, nullable=False, default=utcnow)

class Booking(Base):
    __tablename__ = "bookings"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    lot_id = Column(Integer, ForeignKey("parking_lots.id"), nullable=False, index=True)
    vehicle_id = Column(Integer, ForeignKey("vehicles.id"), nullable=False, index=True)
    starts_at = Column(DateTime, nullable=False, index=True)
    ends_at = Column(DateTime, nullable=False, index=True)
    checked_in_at = Column(DateTime)
    checked_out_at = Column(DateTime)
    rate_per_hour = Column(Float, nullable=False)
    estimated_fee = Column(Float, nullable=False)
    final_fee = Column(Float, nullable=False, default=0)
    status = Column(String(20), nullable=False, default="reserved", index=True)
    created_at = Column(DateTime, nullable=False, default=utcnow)
    __table_args__ = (Index("ix_booking_lot_window", "lot_id", "starts_at", "ends_at"),)

class OccupancySample(Base):
    __tablename__ = "occupancy_samples"
    id = Column(Integer, primary_key=True)
    lot_id = Column(Integer, ForeignKey("parking_lots.id", ondelete="CASCADE"), nullable=False, index=True)
    occupancy_ratio = Column(Float, nullable=False)
    sampled_at = Column(DateTime, nullable=False, default=utcnow, index=True)

class ViolationReport(Base):
    __tablename__ = "violation_reports"
    id = Column(Integer, primary_key=True)
    reporter_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    description = Column(String(1200), nullable=False)
    category = Column(String(60), nullable=False, index=True)
    confidence = Column(Float, nullable=False)
    priority = Column(Integer, nullable=False, default=1, index=True)
    risk_score = Column(Float, nullable=False, default=0)
    latitude = Column(Float, nullable=False)
    longitude = Column(Float, nullable=False)
    plate = Column(String(16))
    evidence_sha256 = Column(String(64))
    evidence_data = Column(Text)
    duplicate_of = Column(Integer, ForeignKey("violation_reports.id"))
    status = Column(String(20), nullable=False, default="pending", index=True)
    reviewed_by = Column(Integer, ForeignKey("users.id"))
    review_note = Column(String(500), nullable=False, default="")
    created_at = Column(DateTime, nullable=False, default=utcnow, index=True)
    reviewed_at = Column(DateTime)

class Challan(Base):
    __tablename__ = "challans"
    id = Column(Integer, primary_key=True)
    vehicle_id = Column(Integer, ForeignKey("vehicles.id"), index=True)
    plate = Column(String(16), nullable=False, index=True)
    report_id = Column(Integer, ForeignKey("violation_reports.id"))
    issued_by = Column(Integer, ForeignKey("users.id"), nullable=False)
    category = Column(String(60), nullable=False)
    amount = Column(Float, nullable=False)
    status = Column(String(20), nullable=False, default="unpaid", index=True)
    payment_reference = Column(String(100))
    created_at = Column(DateTime, nullable=False, default=utcnow)
    paid_at = Column(DateTime)

class Notification(Base):
    __tablename__ = "notifications"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    message = Column(String(500), nullable=False)
    read_at = Column(DateTime)
    created_at = Column(DateTime, nullable=False, default=utcnow)

class AuditEvent(Base):
    __tablename__ = "audit_events"
    id = Column(Integer, primary_key=True)
    actor_id = Column(Integer)
    actor_role = Column(String(20), nullable=False)
    action = Column(String(80), nullable=False)
    entity_type = Column(String(80), nullable=False, default="")
    entity_id = Column(String(80), nullable=False, default="")
    details_json = Column(Text, nullable=False, default="{}")
    previous_hash = Column(String(64), nullable=False)
    event_hash = Column(String(64), nullable=False, unique=True)
    created_at = Column(DateTime, nullable=False, default=utcnow)
