import pytest
from app.models import Booking, Challan, ParkingLot, Vehicle, ViolationReport
from app.security import issue_token

def headers(token):
    return {"Authorization": f"Bearer {token}"}

def test_health_endpoint(client):
    response = client.get("/api/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"

def test_me_requires_authentication(client):
    response = client.get("/api/me")
    assert response.status_code == 401

def test_me_returns_current_user(client, citizen_token):
    response = client.get("/api/me", headers=headers(citizen_token))
    assert response.status_code == 200
    assert response.json()["email"] == "citizen@example.com"

def test_register_new_account(client):
    response = client.post("/api/auth/register", json={"email": "new@example.com", "name": "New Person", "phone": "123", "password": "new-password-123"})
    assert response.status_code == 201
    assert response.json()["ok"]

def test_register_duplicate_account(client):
    response = client.post("/api/auth/register", json={"email": "CITIZEN@example.com", "name": "Other Name", "phone": "", "password": "new-password-123"})
    assert response.status_code == 409

def test_register_rejects_short_password(client):
    response = client.post("/api/auth/register", json={"email": "new@example.com", "name": "New Person", "phone": "", "password": "short"})
    assert response.status_code == 422

def test_login_wrong_password(client):
    response = client.post("/api/auth/login", json={"email": "citizen@example.com", "password": "wrong-password"})
    assert response.status_code == 401

def test_login_case_insensitive_email(client):
    response = client.post("/api/auth/login", json={"email": "CITIZEN@EXAMPLE.COM", "password": "citizen-password-1"})
    assert response.status_code == 200

def test_citizen_cannot_open_dashboard(client, citizen_token):
    response = client.get("/api/dashboard", headers=headers(citizen_token))
    assert response.status_code == 403

def test_officer_can_open_dashboard(client, officer_token):
    response = client.get("/api/dashboard", headers=headers(officer_token))
    assert response.status_code == 200
    assert "lots" in response.json()

def test_admin_can_add_parking_lot(client, admin_token):
    response = client.post("/api/admin/lots", headers=headers(admin_token), json={"name": "New Garage", "address": "Test Street", "latitude": 11.9, "longitude": 79.8, "capacity": 30, "base_rate": 18, "accessible_spaces": 3})
    assert response.status_code == 201
    assert response.json()["name"] == "New Garage"

def test_admin_cannot_add_accessible_spaces_over_capacity(client, admin_token):
    response = client.post("/api/admin/lots", headers=headers(admin_token), json={"name": "Invalid Garage", "address": "Test Street", "latitude": 11.9, "longitude": 79.8, "capacity": 3, "base_rate": 18, "accessible_spaces": 4})
    assert response.status_code == 422

def test_officer_cannot_add_lot(client, officer_token):
    response = client.post("/api/admin/lots", headers=headers(officer_token), json={"name": "New Garage", "latitude": 11.9, "longitude": 79.8, "capacity": 30, "base_rate": 18})
    assert response.status_code == 403

def test_lots_require_login(client):
    assert client.get("/api/lots").status_code == 401

def test_lots_return_capacity_and_price(client, citizen_token):
    response = client.get("/api/lots", headers=headers(citizen_token))
    assert response.status_code == 200
    lot = response.json()[0]
    assert lot["capacity"] > 0
    assert lot["price_now"] > 0
    assert lot["free"] >= 0

def test_vehicle_add_and_list(client, citizen_token):
    response = client.post("/api/vehicles", headers=headers(citizen_token), json={"plate": "PY01AB1234", "label": "Car"})
    assert response.status_code == 201
    rows = client.get("/api/vehicles", headers=headers(citizen_token)).json()
    assert any(item["plate"] == "PY01AB1234" for item in rows)

def test_vehicle_rejects_invalid_plate(client, citizen_token):
    response = client.post("/api/vehicles", headers=headers(citizen_token), json={"plate": "NOTAPLATE"})
    assert response.status_code == 422

def test_vehicle_duplicate_plate_rejected(client, citizen_token):
    client.post("/api/vehicles", headers=headers(citizen_token), json={"plate": "PY01AB1234"})
    response = client.post("/api/vehicles", headers=headers(citizen_token), json={"plate": "PY01AB1234"})
    assert response.status_code == 409

def test_report_requires_login(client):
    response = client.post("/api/reports", json={"description": "Car blocks a driveway", "latitude": 11.9, "longitude": 79.8})
    assert response.status_code == 401

def test_report_submission(client, citizen_token):
    response = client.post("/api/reports", headers=headers(citizen_token), json={"description": "A vehicle is blocking the hospital entrance", "latitude": 11.93, "longitude": 79.83, "plate": "PY01AB1234"})
    assert response.status_code == 201
    assert response.json()["category"] == "blocking_road"

def test_report_validation_rejects_bad_coordinates(client, citizen_token):
    response = client.post("/api/reports", headers=headers(citizen_token), json={"description": "A car blocks a driveway", "latitude": 999, "longitude": 79.83})
    assert response.status_code == 422

def test_police_can_review_report(client, citizen_token, officer_token):
    created = client.post("/api/reports", headers=headers(citizen_token), json={"description": "Vehicle blocking hospital ambulance entrance", "latitude": 11.93, "longitude": 79.83}).json()
    response = client.post(f"/api/police/reports/{created['id']}/review", headers=headers(officer_token), json={"verdict": "verified", "note": "Confirmed by officer"})
    assert response.status_code == 200
    assert response.json()["status"] == "verified"

def test_citizen_cannot_review_report(client, citizen_token):
    response = client.post("/api/police/reports/1/review", headers=headers(citizen_token), json={"verdict": "verified"})
    assert response.status_code == 403

def test_invalid_review_verdict_rejected(client, citizen_token, officer_token):
    created = client.post("/api/reports", headers=headers(citizen_token), json={"description": "Vehicle blocking hospital ambulance entrance", "latitude": 11.93, "longitude": 79.83}).json()
    response = client.post(f"/api/police/reports/{created['id']}/review", headers=headers(officer_token), json={"verdict": "maybe"})
    assert response.status_code == 422

def test_police_challan_issue_and_citizen_list(client, citizen_token, officer_token):
    client.post("/api/vehicles", headers=headers(citizen_token), json={"plate": "PY01AB1234"})
    created = client.post("/api/police/challans", headers=headers(officer_token), json={"plate": "PY01AB1234", "category": "no_parking_zone"})
    assert created.status_code == 201
    rows = client.get("/api/challans/mine", headers=headers(citizen_token)).json()
    assert len(rows) == 1
    assert rows[0]["amount"] == 500

def test_challan_payment_requires_vehicle_owner(client, citizen_token, officer_token):
    created = client.post("/api/police/challans", headers=headers(officer_token), json={"plate": "PY01AB1234", "category": "no_parking_zone"}).json()
    response = client.post(f"/api/challans/{created['id']}/pay", headers=headers(citizen_token), json={"payment_reference": "PAYMENT-12345"})
    assert response.status_code == 404

def test_challan_payment_records_reference(client, citizen_token, officer_token):
    client.post("/api/vehicles", headers=headers(citizen_token), json={"plate": "PY01AB1234"})
    created = client.post("/api/police/challans", headers=headers(officer_token), json={"plate": "PY01AB1234", "category": "no_parking_zone"}).json()
    response = client.post(f"/api/challans/{created['id']}/pay", headers=headers(citizen_token), json={"payment_reference": "PAYMENT-12345"})
    assert response.status_code == 200
    assert response.json()["status"] == "paid"

def test_police_plate_lookup(client, citizen_token, officer_token):
    client.post("/api/vehicles", headers=headers(citizen_token), json={"plate": "PY01AB1234"})
    response = client.post("/api/police/lookup", headers=headers(officer_token), json={"plate": "PY01AB1234"})
    assert response.status_code == 200
    assert response.json()["registered"] is True

def test_sensor_update_caps_at_capacity(client, officer_token):
    response = client.post("/api/police/lots/1/sensor", headers=headers(officer_token), json={"occupied": 999})
    assert response.status_code == 200
    assert response.json()["occupied"] == 10

def test_sensor_update_missing_lot(client, officer_token):
    response = client.post("/api/police/lots/999/sensor", headers=headers(officer_token), json={"occupied": 2})
    assert response.status_code == 404

def test_audit_chain_starts_intact(client, officer_token):
    response = client.get("/api/police/audit/verify", headers=headers(officer_token))
    assert response.status_code == 200
    assert response.json()["intact"] is True

def test_notifications_require_login(client):
    assert client.get("/api/notifications").status_code == 401

def test_notification_endpoint_returns_list(client, citizen_token):
    response = client.get("/api/notifications", headers=headers(citizen_token))
    assert response.status_code == 200
    assert isinstance(response.json(), list)

def test_logout_revokes_token(client):
    token = client.post("/api/auth/login", json={"email": "citizen@example.com", "password": "citizen-password-1"}).json()["token"]
    response = client.post("/api/auth/logout", headers=headers(token))
    assert response.status_code == 200
    assert client.get("/api/me", headers=headers(token)).status_code == 401

def test_debug_docs_not_required(client):
    assert client.get("/api/health").status_code == 200
