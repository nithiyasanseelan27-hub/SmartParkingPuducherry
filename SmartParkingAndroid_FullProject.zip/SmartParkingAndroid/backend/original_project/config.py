import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATABASE_URL = os.environ.get("PARKING_DATABASE_URL", f"sqlite:///{ROOT / 'parking.db'}")
APP_NAME = os.environ.get("PARKING_APP_NAME", "Puducherry Smart Parking")
HOST = os.environ.get("PARKING_HOST", "127.0.0.1")
PORT = int(os.environ.get("PARKING_PORT", "8000"))
TOKEN_TTL_SECONDS = int(os.environ.get("PARKING_TOKEN_TTL", "3600"))
LOGIN_FAILURE_LIMIT = int(os.environ.get("PARKING_LOGIN_FAILURE_LIMIT", "5"))
LOGIN_LOCK_MINUTES = int(os.environ.get("PARKING_LOGIN_LOCK_MINUTES", "15"))
REPORT_DAILY_LIMIT = int(os.environ.get("PARKING_REPORT_DAILY_LIMIT", "10"))
MAX_EVIDENCE_BYTES = int(os.environ.get("PARKING_MAX_EVIDENCE_BYTES", str(3_000_000)))
REQUEST_SIZE_LIMIT = int(os.environ.get("PARKING_REQUEST_SIZE_LIMIT", str(5_000_000)))
DEBUG = os.environ.get("PARKING_DEBUG", "0") == "1"
