import hashlib
import math
import re
from collections import Counter, defaultdict
from datetime import timedelta

PLATE_PATTERN = re.compile(r"\b([A-Z]{2})[\s-]?(\d{1,2})[\s-]?([A-Z]{1,3})[\s-]?(\d{4})\b")
CATEGORIES = {
    "fire_hydrant_or_emergency": {"hydrant": 4, "ambulance": 3, "fire": 2, "hospital": 2, "emergency": 3},
    "disabled_bay_misuse": {"disabled": 4, "handicap": 3, "wheelchair": 3, "accessible bay": 3},
    "blocking_road": {"blocking": 3, "block the road": 3, "obstruct": 3, "traffic": 1, "jam": 2},
    "footpath_encroachment": {"footpath": 3, "pavement": 3, "sidewalk": 3, "pedestrian": 2},
    "double_parking": {"double parking": 4, "second row": 3, "beside another car": 2},
    "no_parking_zone": {"no parking": 3, "restricted zone": 3, "no-parking": 3},
    "gate_or_driveway_block": {"gate": 2, "driveway": 3, "entrance": 2},
    "abandoned_vehicle": {"abandoned": 4, "flat tyre": 2, "unused for months": 3},
    "illegal_parking": {"illegal": 2, "wrongly parked": 2, "parking": 1},
}
SEVERITY = {"fire_hydrant_or_emergency": 5, "disabled_bay_misuse": 4, "blocking_road": 4, "footpath_encroachment": 3, "double_parking": 3, "no_parking_zone": 3, "gate_or_driveway_block": 2, "abandoned_vehicle": 2, "illegal_parking": 2}

def normalize_plate(value):
    match = PLATE_PATTERN.search((value or "").upper())
    if not match:
        return None
    return f"{match[1]}{int(match[2]):02d}{match[3]}{match[4]}"

def classify_violation(description):
    text = (description or "").casefold()
    scores = {category: sum(weight for phrase, weight in terms.items() if phrase in text) for category, terms in CATEGORIES.items()}
    total = sum(scores.values())
    if total == 0:
        return "illegal_parking", 0.3
    category = max(scores, key=scores.get)
    confidence = min(0.99, scores[category] / total * (0.5 + min(total, 8) / 16))
    return category, round(confidence, 2)

def priority_score(category, description, risk_score=0.0):
    text = (description or "").casefold()
    urgency = int(bool(re.search(r"ambulance|urgent|school|accident|emergency|child", text)))
    penalty = int(risk_score >= 0.75)
    return max(1, min(5, SEVERITY.get(category, 2) + urgency - penalty))

def fake_report_risk(previous_reports, rejected_reports, has_evidence, description_length, is_duplicate):
    rejection_ratio = rejected_reports / previous_reports if previous_reports else 0.0
    score = 0.12 + 0.45 * rejection_ratio + (0.18 if not has_evidence else 0.0) + (0.15 if description_length < 20 else 0.0) + (0.25 if is_duplicate else 0.0)
    return round(max(0.0, min(1.0, score)), 2)

def simhash(text):
    vector = [0] * 64
    for token in re.findall(r"[a-z0-9]+", (text or "").casefold()):
        digest = int.from_bytes(hashlib.blake2b(token.encode(), digest_size=8).digest(), "big")
        for bit in range(64):
            vector[bit] += 1 if digest & (1 << bit) else -1
    value = sum(1 << bit for bit, score in enumerate(vector) if score > 0)
    return f"{value:016x}"

def hamming_distance(left, right):
    try:
        return (int(left, 16) ^ int(right, 16)).bit_count()
    except (ValueError, TypeError):
        return 64

def distance_meters(lat1, lng1, lat2, lng2):
    radius = 6_371_000
    p1 = math.radians(lat1)
    p2 = math.radians(lat2)
    dp = math.radians(lat2 - lat1)
    dl = math.radians(lng2 - lng1)
    value = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * radius * math.asin(min(1.0, math.sqrt(value)))

def find_duplicate(description, latitude, longitude, plate, reports, radius_m=120):
    signature = simhash(description)
    for report in reports:
        if distance_meters(latitude, longitude, report.latitude, report.longitude) > radius_m:
            continue
        if plate and report.plate and plate == report.plate:
            return report.id
        if hamming_distance(signature, simhash(report.description)) <= 8:
            return report.id
    return None

def occupancy_forecast(samples, when, now, current_ratio=None):
    if not samples:
        return float(current_ratio if current_ratio is not None else 0.5)
    local_when = when + timedelta(hours=5, minutes=30)
    target = (local_when.weekday(), local_when.hour)
    groups = defaultdict(list)
    for sample in samples:
        local = sample.sampled_at + timedelta(hours=5, minutes=30)
        groups[(local.weekday(), local.hour)].append(sample.occupancy_ratio)
    if groups.get(target):
        baseline = sum(groups[target]) / len(groups[target])
    else:
        baseline = sum(item.occupancy_ratio for item in samples) / len(samples)
    if current_ratio is None:
        return max(0.0, min(1.0, baseline))
    hours = max(0.0, (when - now).total_seconds() / 3600)
    weight = math.exp(-hours / 2)
    return max(0.0, min(1.0, weight * current_ratio + (1 - weight) * baseline))

def dynamic_price(base_rate, current_ratio, forecast_ratio, local_hour):
    demand = 0.6 * current_ratio + 0.4 * forecast_ratio
    multiplier = 0.8 + 1.4 * demand ** 2 + (0.1 if 17 <= local_hour <= 20 else 0.0)
    return round(base_rate * max(0.8, min(2.2, multiplier)), 2)

def recommend_lots(lots, latitude, longitude, state_provider):
    candidates = []
    for lot in lots:
        state = state_provider(lot)
        distance = distance_meters(latitude, longitude, lot.latitude, lot.longitude)
        price = state["price_now"]
        candidates.append((lot, state, distance, price))
    max_distance = max((item[2] for item in candidates), default=1.0) or 1.0
    max_price = max((item[3] for item in candidates), default=1.0) or 1.0
    results = []
    for lot, state, distance, price in candidates:
        score = 0.0 if state["free"] <= 0 else 0.4 * (1 - distance / max_distance) + 0.4 * (1 - state["forecast_1h"]) + 0.2 * (1 - price / max_price)
        results.append({**state, "distance_m": int(distance), "score": round(score, 3)})
    return sorted(results, key=lambda item: (item["score"] <= 0, -item["score"], item["distance_m"]))

def detect_hotspots(points, radius_m=200, minimum_points=3):
    if len(points) < minimum_points:
        return []
    remaining = set(range(len(points)))
    clusters = []
    while remaining:
        seed = remaining.pop()
        cluster = {seed}
        frontier = [seed]
        while frontier:
            current = frontier.pop()
            nearby = {index for index in remaining if distance_meters(points[current][0], points[current][1], points[index][0], points[index][1]) <= radius_m}
            if len(nearby) + len(cluster) >= minimum_points:
                remaining.difference_update(nearby)
                cluster.update(nearby)
                frontier.extend(nearby)
        if len(cluster) >= minimum_points:
            categories = Counter(points[index][2] for index in cluster)
            clusters.append({"latitude": sum(points[i][0] for i in cluster) / len(cluster), "longitude": sum(points[i][1] for i in cluster) / len(cluster), "count": len(cluster), "top_category": categories.most_common(1)[0][0], "severity": min(5, 1 + len(cluster) // 3)})
    return sorted(clusters, key=lambda item: -item["count"])

def occupancy_anomaly(actual, expected, threshold=0.35):
    return abs(actual - expected) > threshold

def overstay_risk(minutes_left, occupancy_ratio):
    score = 0.1
    if minutes_left < 15:
        score += 0.5
    elif minutes_left < 45:
        score += 0.2
    if occupancy_ratio > 0.8:
        score += 0.3
    return round(min(1.0, score), 2)
