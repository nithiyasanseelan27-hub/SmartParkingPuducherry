# Smart Parking Android + Full Source Project

This package combines the Android WebView build project with the contents of the supplied `Smart Parking.zip`.

## Included

- `app/` — Android app wrapper and bundled `smartpark.html` interface (`app/src/main/assets/index.html`).
- `.github/workflows/build-apk.yml` — GitHub Actions workflow to build a debug APK in the cloud.
- `backend/original_project/` — all 42 entries from the supplied original ZIP, including the FastAPI/Python modules, tests, database, front-end archives, and supporting files.
- `backend/unpacked_archives/` — extracted copies of nested ZIP archives found in the original project, where possible.

## Build the Android APK using GitHub from an Android phone

1. Create a repository on GitHub.
2. Upload the contents of this project ZIP to the repository root, preserving the `.github` folder.
3. Open the repository's **Actions** tab and select **Build Smart Parking APK**.
4. Run the workflow and wait for it to finish.
5. Download the `SmartParking-debug-apk` artifact from the completed run, extract it, and install `app-debug.apk` on the phone.

## Important limitations

- This ZIP is source/build material, **not a compiled APK**.
- The APK currently wraps the standalone HTML interface. The Python/FastAPI backend is included in the project source, but is **not executed inside the Android APK** and is **not automatically deployed online**.
- Backend-dependent features require deploying the backend to a server and configuring the Android interface to use its API address. Including backend files in this ZIP does not by itself connect those features.
- Payment code must be configured and reviewed with a real provider before handling real payments.
- The GitHub workflow builds a debug APK for testing, not a Play Store-signed release.
